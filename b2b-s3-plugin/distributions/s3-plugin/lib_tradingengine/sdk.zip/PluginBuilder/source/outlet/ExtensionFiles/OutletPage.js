function autosize(theIframe)
{	
	var newheight;
	if (navigator.appName != "Microsoft Internet Explorer" &&
		!window.opera && !document.mimeType && document.all && document.getElementById){
		newheight=theIframe.contentWindow.document.body.offsetHeight;
	}else if(document.getElementById){
		newheight=theIframe.contentWindow.document.body.scrollHeight;
	}
	theIframe.style.height= (newheight + 32) + "px";
}