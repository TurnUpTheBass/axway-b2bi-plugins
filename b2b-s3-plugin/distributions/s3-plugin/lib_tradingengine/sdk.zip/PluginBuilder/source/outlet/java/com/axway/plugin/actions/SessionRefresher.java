// Copyright (c) 2007 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.axway.plugin.actions;

import org.apache.cocoon.environment.Redirector;
import org.apache.cocoon.environment.SourceResolver;
import org.apache.cocoon.environment.Request;
import org.apache.cocoon.environment.ObjectModelHelper;
import org.apache.cocoon.environment.Session;
import org.apache.cocoon.environment.Cookie;
import org.apache.cocoon.environment.http.HttpCookie;

import java.util.Map;
import java.util.HashMap;

import com.cyclonecommerce.ui.core.User;
import com.cyclonecommerce.ui.core.UIPackage;
import com.cyclonecommerce.ui.users.actions.AbstractUserAction;

public class SessionRefresher extends AbstractUserAction
{
	public static final String COOKIE_NAME = "pluginCookie";

	public Map act(Redirector redirector, SourceResolver sourceResolver, Map map, String s, org.apache.avalon.framework.parameters.Parameters parameters)
			throws Exception
	{
		Request request = ObjectModelHelper.getRequest(map);
		Session session = request.getSession();
		User user = User.getUser(session);
		if (user != null)
		{
			User.refreshSession(user);
			updateCookieExpireTime((com.cyclonecommerce.ui.users.User)user, map);
			return new HashMap();
		}
		else
		{
			removeCookieExpireTime(map);
			return null;
		}

	}

	private void updateCookieExpireTime(com.cyclonecommerce.ui.users.User user, Map map)
	{
		Cookie cookie = new HttpCookie(COOKIE_NAME, ObjectModelHelper.getRequest(map).getSession().getId());
		cookie.setMaxAge((int)(user.getSessionExpireTime() / 1000) + 1);//max one second after CI session expired
		cookie.setPath(UIPackage.getInstance().getBaseUIContext());
		ObjectModelHelper.getResponse(map).addCookie(cookie);
	}

	private void removeCookieExpireTime(Map map)
	{
		Cookie cookie = new HttpCookie(COOKIE_NAME, null);
		cookie.setMaxAge(0);//set cookie as expired
		cookie.setPath(UIPackage.getInstance().getBaseUIContext());
		ObjectModelHelper.getResponse(map).addCookie(cookie);
	}
}
