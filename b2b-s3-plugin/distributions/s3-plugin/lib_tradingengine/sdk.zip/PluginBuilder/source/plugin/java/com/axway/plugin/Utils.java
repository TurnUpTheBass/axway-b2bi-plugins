// Copyright (c) 2007 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.axway.plugin;

import java.util.Iterator;

import com.cyclonecommerce.cachet.administration.Group;

public class Utils
{
	public static boolean isUserAllowed(com.cyclonecommerce.cachet.administration.User theUser, String permission)
	{
		for(Iterator it = theUser.getGroups().iterator(); it.hasNext(); )
		{
			Group theGroup = (Group)it.next();
			if(theGroup.isAdmin() || theGroup.hasResource(permission))
			{
				return true;
			}
		}
		return false;
	}
}
