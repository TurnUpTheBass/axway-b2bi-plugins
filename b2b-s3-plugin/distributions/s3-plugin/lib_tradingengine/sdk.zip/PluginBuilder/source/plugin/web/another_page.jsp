<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Another plugin page</title>
	<%@ include file="header.jspf" %>
</head>
<body >
	<p>Back to the plugin <a href="index.jsp?ciUserId=<%=userId%>">index</a></p>
</body>
</html>
