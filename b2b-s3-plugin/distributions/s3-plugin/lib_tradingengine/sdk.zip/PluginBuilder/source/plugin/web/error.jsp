<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ERROR</title>
</head>
<body>
<%
	// error messages when plugin is accessed outside CI
	out.write("<p style='color:red;'>Error: The plugin must be accessed from within an Interchange session.</p>");	
%>
</body>
</html>