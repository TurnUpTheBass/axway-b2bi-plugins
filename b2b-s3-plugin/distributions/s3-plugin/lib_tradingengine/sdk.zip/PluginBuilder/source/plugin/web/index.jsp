<%@page import="com.cyclonecommerce.cachet.administration.User"%>
<%@page import="com.axway.plugin.Utils"%>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>CSOS EDI Reporting</title>
	<%@ include file="header.jspf" %>

</head>

<body>

	<%-- This is an example of how to access Interchange Java code. --%>
	<p>The name of the logged on user is: <em><%= user.getName() %></em></p>

	<%-- This is an example of how to access the plugin's Java code. --%>
	<%
	String[] permissions = {
		"ui:reports.execute",
		"ui:reports.manage",
		"ui:exportPrivateKeys",
		"ui:tasks.manage",
		"ui:messages.search",
		"ui:messages.annotate",
		"ui:messages.delete",
		"ui:messages.manageGlobalConfig",
		"ui:messages.resubmit",
		"ui:messages.searches.manage",
		"ui:viewPayloadsAndBackups",
		"ui:alerts.manage",
		"ui:sysmgmt.read",
		"ui:sysmgmt.manageSecurity",
		"ui:sysmgmt.manageCluster",
		"ui:viewTE",
		"ui:managePartners",
		"ui:manageRemoteCerts",
	};
	%>
	<p>Here are some permissions of the current user:</p>
	<ul>
	<%
	for (String permission : permissions) {
		boolean hasPermission = Utils.isUserAllowed(user, permission);
		%>
		<li><tt><%= permission %></tt>: <em><%= hasPermission %></em></li>
		<%
	}
	%>
	</ul>

	<%-- This is an example of how a multi-page plugin works. --%>
	<p>Here's a link to <a href="another_page.jsp?ciUserId=<%=userId%>">another plugin page</a></p>

</body>
</html>
