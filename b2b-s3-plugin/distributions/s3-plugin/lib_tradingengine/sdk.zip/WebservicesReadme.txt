Copyright (c) 2007-202 Axway Inc. All Rights Reserved.
Please refer to the file "LICENSE" for further important copyright
and licensing information.  Please also refer to the documentation
for additional copyright notices.

****************** Sample1: Receiving and Sending meaages over webservice ******************

Custom Deployment of Services, Handlers and Modules:
----------------------------------------------------
1) Axis2 requires a module.xml inside a jar with a .mar extension to define a handler.
   In this example, the module.xml can be found under
   java-src/examples/webservices/tradingenginenodeservices/Axis2TestModule/META-INF.
   The "testmodule" referenced therein implements the org.apache.axis2.modules.Module,
   and is used for any additional tasks needed to initialize the module and shutdown the
   module. (Refer to java-src/.../Axis2TestModule/TestModule.java).
2) The user should reference the module which has the handler chain inside the services.xml
   found under java-src/examples/webservices/tradingenginenodeservices/Axis2TestServices/META-INF


---------------------------

Building and Running the Sample:
--------------------------------
The following instructions assume you will be trading between two Gateway Interchange systems.
In the following instructions, steps 1 and 2 only need to be executed on one system while the
remaining steps must be executed on both the sending and receiving systems unless otherwise directed.
1) Following the instructions in sdk/GettingStarted.htm, edit sdk/build.cmd or sdk/build.sh (as
   appropriate for your environment) and set the appropriate values for the CYC_HOME and JAVA_HOME variables.
2) From the sdk directory run build.cmd or build.sh, again as appropriate for your environment.
3) Copy the generated testhandler.aar file from the sdk/lib directory to Interchange's Axis2 services
   directory (conf/axis2_repository/services).
4) Copy the generated testhandler.mar file from the sdk/lib directory to Interchange's Axis2 modules
   directory (conf/axis2_repository/modules).
5) Modify the conf/axis2.xml file as follows (you may want to make a backup copy first):
   Add a phase for the new testmodule under the InFlow and OutFlow phase orders. Specifically, add
      <phase name="testmodulePhase"/>
   just after the Security phase in the InFlow phase order and just before the Security phase in
   the OutFlow phase order. The incoming/outgoing message passes through each phase, including
   testmodulePhase, and the respective handler will be invoked to process the message.
6) Start the Gateway Interchange servers.
7) On the sending system, log in to the Interchange UI and on the Message attributes tab for the
   application pickup exchange that will be used, add a fixed message attribute for the Integration ID
   attribute. You can give the attribute any value you want.
8) Generate an XML document to the configured application pickup exchange.
9) When the message is delivered, find the received message on the receiving system in the message tracker.
   The Integration ID attribute will show up on the Message attributes tab in the Message details page.

NOTE: If upgraded to a new build, manually copy the custom .aar and .mar files to the new installs.

****************** Sample2: Building response for the requesting webservice message ******************

Custom Deployment of Services:
----------------------------------------------------
1) The user should define a service that builds a response for the requesting webservice. In this sample,
   the service ExchangeResponseService found under
   java-src/examples/webservices/tradingenginenodeservices/Axis2ResponseServices declares a method
   responseMessage that builds that response. This method is referred as operation inside services.xml found under
   java-src/examples/webservices/tradingenginenodeservices/Axis2ResponseServices/META-INF

Building and Running the Sample:
--------------------------------
The following instructions assume you will be trading between two Gateway Interchange systems.
In the following instructions, steps 1 and 2 only need to be executed on one system while the
remaining steps must be executed on both the sending and receiving systems unless otherwise directed.
1) Following the instructions in sdk/GettingStarted.htm, edit sdk/build.cmd or sdk/build.sh (as
   appropriate for your environment) and set the appropriate values for the CYC_HOME and JAVA_HOME variables.
2) From the sdk directory run build.cmd or build.sh, again as appropriate for your environment.
3) Copy the generated ExchangeResponseService.aar file from the sdk/lib directory to Interchange's Axis2 services
   directory (conf/axis2_repository/services).
4) Start the Gateway Interchange servers.
7) On the Receiving system, log in to the Interchange UI and on the Message attributes tab for the
   webservice trading delivery exchange that will be used, add a fixed message attribute for the AxisToEndpointReference
   attribute. If this attribute is not present, Use Add attribute to add this attribute first.
   Then select this attribute and give the value: http://localhost/axis2/services/ExchangeResponseService/responseMessage .
8) On the Sending system, log in to the Interchange UI and on the collaboration settings for webservices message protocol,
   set the SOAP action to responseMessage.
9) Generate an XML document to the configured application pickup exchange.
10)When the message is delivered, find the received message and sent response on the receiving system in the message tracker.
11)Find the sent message and received response on the sending system in the message tracker.

NOTE: If upgraded to a new build, manually copy the custom .aar and .mar files to the new installs.
