@echo off
setlocal

REM
REM This script builds the API Examples file: apiexamples.jar using Ant.
REM Ant is a Java-based build tool developed by the Apache Jakarta project.
REM See http://jakarta.apache.org/ant for more info.
REM
REM You must define the two variables CYC_HOME and JAVA_HOME before running.
REM


REM
REM Set CYC_HOME to point to your Interchange installation.
REM For example:  c:/Axway/Interchange
REM
REM
REM If the script is executed from the Interchage/sdk folder
REM SET CYC_HOME=..\

SET CYC_HOME=CHANGE ME!


REM
REM Set JAVA_HOME to point to your Java SDK installation.
REM For example:  c:/j2sdk1.5
REM
REM If the script is executed from the Interchage/sdk folder
REM SET JAVA_HOME=..\..\jre
REM SET JAVA_HOME=CHANGE ME!


if "%CYC_HOME%"=="" goto BadCycHome

if "%JAVA_HOME%"=="" goto BadJavaHome
if not exist "%JAVA_HOME%/bin/java.exe" goto BadJavaHome

@echo on
"%JAVA_HOME%\bin\java" -classpath "%JAVA_HOME%"\lib\tools.jar;"%JAVA_HOME%"\jre\lib\rt.jar;.\lib\ant\ant.jar;.\lib\ant\ant-launcher.jar -Dci.home.dir=%CYC_HOME% org.apache.tools.ant.Main -buildfile build.xml %*

@echo off

@endlocal

exit /b 0


:BadCycHome
echo .
echo ******************************** ERROR ********************************
echo You must set your CYC_HOME environment variable to point
echo to the Interchange installation directory.
echo .
exit /b 1


:BadJavaHome
echo .
echo ******************************** ERROR ********************************
echo You must set your JAVA_HOME environment variable to point
echo to the Java SDK directory.
echo .
exit /b 2
