#!/bin/sh

#
# This script builds the API Examples file: apiexamples.jar using Ant.
# Ant is a Java-based build tool developed by the Apache Jakarta project.
# See http://jakarta.apache.org/ant for more info.
#
# You must define the two variables CYC_HOME and JAVA_HOME before running. 
#
# Set CYC_HOME to point to your Interchange installation.
# For example:  "/opt/Axway/Interchange"
#
# If the script is executed from the Interchage/sdk folder
#CYC_HOME=../

CYC_HOME="CHANGE ME!"

#
# Set JAVA_HOME to point to your Java SDK installation.
# For example:  "/opt/java2"
#
# If the script is executed from the Interchage/sdk folder
#JAVA_HOME=../../jre

JAVA_HOME="CHANGE ME!"


if  [ ! -n "$CYC_HOME" -o ! -f "$CYC_HOME/conf/license.xml" ]  ; then
	echo ""
	echo "******************************** ERROR ********************************"
	echo "You must set your CYC_HOME environment variable to point to the Interchange installation directory"
	echo ""
	exit 1
fi


if  [ ! -n "$JAVA_HOME" -o ! -f "$JAVA_HOME/bin/javac" ]  ; then
	echo ""
	echo "******************************** ERROR ********************************"
	echo "You must set your JAVA_HOME environment variable to point to the Java SDK directory"
	echo ""
	exit 2
fi


$JAVA_HOME/bin/java -classpath $JAVA_HOME/lib/tools.jar:$JAVA_HOME/jre/lib/rt.jar:./lib/ant/ant.jar:./lib/ant/ant-launcher.jar -Dci.home.dir=$CYC_HOME org.apache.tools.ant.Main -buildfile build.xml $1 $2 $3

exit 0

