using System;
using System.IO;
using System.Text;

/// <summary>
/// Implements the CPA API WebService Client
/// </summary>
class TestClient
{
	private string url;
	private string username;
	private string password;
	private string item;

	/// <summary>
	/// The main entry point for the application.
	/// args[0]: hostname
	/// args[1]: port
	/// args[2]: username
	/// args[3]: password
	/// args[4]: action (import or remove)
	/// args[5]: item (CPA file  or CPA ID)
	/// </summary>
	[STAThread]
	static void Main(string[] args)
	{
		try
		{
			if (args.Length != 6)
			{
				usage();
				return;
			}

			if (args.GetValue(4).Equals("remove"))
				new TestClient(args).removeCpa();
			else if (args.GetValue(4).Equals("import"))
				new TestClient(args).importCpa();
			else
				usage();
		}
		catch (Exception e)
		{
			Console.WriteLine(e.GetBaseException().ToString());
			Console.WriteLine(e.StackTrace);
		}
	}

	public TestClient(string[] args)
	{
		string hostname = args[0];
		string port = args[1];
		url = "http://" + hostname +  ":" + port + "/cyclone/services/CPAAPI";
		username = args[2];
		password = args[3];
		item = args[5];
	}

	private void removeCpa()
	{
		CpaApiTest.localhost.CPAAPIService cpaApi = new CpaApiTest.localhost.CPAAPIService();
		cpaApi.Url = url;
		Console.WriteLine("Calling webservice");
		cpaApi.removeCPA(item, username, password);
		Console.WriteLine("Back from webservice");
	}

	private void importCpa()
	{
		StreamReader reader = new StreamReader(item, true);
		String cpa = reader.ReadToEnd();
		
		CpaApiTest.localhost.CPAAPIService cpaApi = new CpaApiTest.localhost.CPAAPIService();
		cpaApi.Url = url;
		Console.WriteLine("Calling webservice");
		cpaApi.importCPA(base64Encode(cpa), username, password);
		Console.WriteLine("Back from webservice");
	}

	public byte[] base64Encode(string data)
	{
		try
		{
			byte[] encData_byte = new byte[data.Length];
			encData_byte = System.Text.Encoding.UTF8.GetBytes(data);    
			string encodedData = Convert.ToBase64String(encData_byte);
			return System.Text.Encoding.UTF8.GetBytes(encodedData);
		}
		catch(Exception e)
		{
			throw new Exception("Error in base64Encode" + e.Message);
		}
	}

	private static void usage()
	{
		Console.WriteLine("usage: TestClient <hostname> <port> <username> <password> [import <CPA file>|remove <CPA ID>");
	}
}
