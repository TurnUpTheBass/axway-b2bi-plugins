// Copyright (c) 2006 Cyclone Commerce, Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
using System;
using MessageQueryService_SDK.MessageQueryServiceClient;
using MessageQueryService_SDK.SessionServiceClient;

/// <summary>
/// Simple SOAP Client for the Interchange MessageQueryService WebService. Demonstrates how to create a user session,
/// query Interchange for some messages, and clean up the session.
/// </summary>
public class MessageQueryClient
{
	private const string SESSION_SERVICE_PATH = "/cyclone/services/SessionService";
	private const string MESSAGE_QUERY_SERVICE_PATH = "/cyclone/services/MessageQueryService";

	// Message Status
	private const int IN_PROCESS = 0;
	private const int FAILED = 1;
	private const int DELIVERED = 2;
	private const int DELIVERED_NEGATIVE_RESPONSE = 3;
	private const int WAITING_FOR_ACK = 4;
	private const int RESUBMITTED = 5;
	private const int RESUBMITTING = 6;
	private const int IGNORED = 7;
	private const int ALL_EXCEPT_IGNORED = 8;

	// Sorting Options
	private const int SORT_DELIVERED_DATE = 0;
	private const int SORT_ORIGINATION_DATE = 1;
	private const int SORT_PROCESSING_STATUS = 2;
	private const int SORT_DOCUMENT_ID = 3;

	// Message Direction
	private const int INBOUND = 0;
	private const int OUTBOUND = 1;
	private const int INTERNAL = 2;
	private const int EXTERNAL = 3;

	// Message Type
	private const int REQUEST =  1;
	private const int RECEIPT = 2;

	private string url;
	private string username;
	private string password;
	private byte[] sessionCookie;

	 /// <summary>
	 /// Constructor
	 /// </summary>
	 /// <param name="url">URL to the Interchange UI port - should not include path part of deployed webservices. example http://localhost:6080 </param>
	 /// <param name="username"></param>
	 /// <param name="password"></param>
	public MessageQueryClient(string url, string username, string password)
	{
		if (url == null || url.Length == 0) throw new System.NotSupportedException("url cannot be null");
		if (username == null || username.Length == 0) throw new System.NotSupportedException("username cannot be null");
		if (password == null || password.Length == 0) throw new System.NotSupportedException("password cannot be null");

		this.url = url;
		this.username = username;
		this.password = password;
	}

	/// <summary>
	/// Opens a session in Interchange. Note that the session must be closed when resubmit operations are completed.
	/// Otherwise the session will remain open until the default session timeout (30 minutes) closes the session.
	/// </summary>
	public void createSession()
	{
		SessionServiceService sessionService = new SessionServiceService();
		sessionService.Url = url + SESSION_SERVICE_PATH;
		sessionCookie = sessionService.login(username, password);
	}

	/// <summary>
	/// Close the session in Interchange.
	/// </summary>
	public void closeSession()
	{
		if (sessionCookie == null)
			return;

		SessionServiceService sessionService = new SessionServiceService();
		sessionService.Url = url + SESSION_SERVICE_PATH;
		sessionService.logout(sessionCookie);
		sessionCookie = null;
	}

	/// <summary>
	/// Invokes the message query service to return messages which match the specified message ID. Prints metadata
	/// from each message to the console.
	/// </summary>
	/// <param name="messageId">Message ID to use in the query. Should not be null or empty.</param>
	public void getMessagesByMessageId(string messageId)
	{
		MessageQueryInfo queryInfo = new MessageQueryInfo();
		queryInfo.messageId = messageId;
		doQuery(queryInfo);
	}

	/// <summary>
	/// Invokes the message query service to return messages which are in the Rejected state. Prints metadata
	/// from each message to the console.
	/// </summary>
	public void getRejectedMessages()
	{
		MessageQueryInfo queryInfo = new MessageQueryInfo();
		queryInfo.messageStatusType = FAILED;
		queryInfo.excludeMessageType = RECEIPT; // Exclude receipts.
		doQuery(queryInfo);
	}

	/// <summary>
	/// Invokes the message query service to return messages which are in the Delivered state. Prints metadata
	/// from each message to the console.
	/// </summary>
	public void getDeliveredMessages()
	{
		MessageQueryInfo queryInfo = new MessageQueryInfo();
		queryInfo.messageStatusType = DELIVERED;
		queryInfo.excludeMessageType = RECEIPT ; // Exclude receipts.
		doQuery(queryInfo);
	}

	/// <summary>
	/// Invokes the message query service to return messages which match based on the criteria in MessageQueryInfo.
	/// Prints metadata from each message to the console.
	/// </summary>
	protected void doQuery(MessageQueryInfo queryInfo)
	{
		MessageQueryServiceService queryService = new MessageQueryServiceService();
		queryService.Url = url + MESSAGE_QUERY_SERVICE_PATH;

		int maxResults = 10;
		int serverMaxResults = queryService.getMaxPageSize(sessionCookie);
		if (maxResults > serverMaxResults)
			maxResults = serverMaxResults;

		int page = 1;
		MessageQueryRequest request = new MessageQueryRequest();
		request.fromPage = page;
		request.maxResults = maxResults;
		request.queryInfo = queryInfo;

		MessageQueryResponse response = queryService.getMessages(sessionCookie, request);
		int pageCount = response.pageCount;
		int totalNumberOfMessages = 0;
		while (page <= pageCount)
		{
			RemoteMessage[] messages = response.messages;
			int numMessages = messages.Length;
			totalNumberOfMessages += numMessages;
			for (int i = 0; i < numMessages; i++)
				printMessageInfo(messages[i]);

			page++;
			if (page <= pageCount)
			{
				request.fromPage = page;
				response = queryService.getMessages(sessionCookie, request);
			}
		}

		Console.WriteLine("#################################");
		Console.WriteLine("Total number of messages retrieved = " + totalNumberOfMessages);
	}

	/// <summary>
	/// Prints message info to the console.
	/// </summary>
	protected void printMessageInfo(RemoteMessage message)
	{
		Console.WriteLine("#################################");
		Console.WriteLine("CoreId: " + message.coreId);
		Console.WriteLine("MessageId: " + message.messageId);
		Console.WriteLine("ContentMimeType: " + message.contentMimeType);
		Console.WriteLine("ReceiverRoutingId: " + message.receiverRoutingId);
		Console.WriteLine("SenderRoutingId: " + message.senderRoutingId);
		MetadataAttribute[] metadata = message.metaDataAttributes;
		int attributeCount = metadata.Length;
		for (int i = 0; i < attributeCount; i ++)
			Console.WriteLine(metadata[i].name + " = " + metadata[i].value);
	}

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main(string[] args)
	{
		if (args.Length != 4)
		{
			Console.WriteLine("usage: MessageQueryServiceClient base-url username password [-rejected|-delivered|messageID]");
			return;
		}

		string baseUrl = args[0];
		string username = args[1];
		string password = args[2];
		MessageQueryClient messageQueryServiceClient = new MessageQueryClient(baseUrl, username, password);

		try
		{
			messageQueryServiceClient.createSession();
			if (args[3].Equals("-rejected"))
				messageQueryServiceClient.getRejectedMessages();
			else if (args[3].Equals("-delivered"))
				messageQueryServiceClient.getDeliveredMessages();
			else
				messageQueryServiceClient.getMessagesByMessageId(args[3]);
		}
		finally
		{
			// An open session should always be closed!
			messageQueryServiceClient.closeSession();
		}
	}
}
