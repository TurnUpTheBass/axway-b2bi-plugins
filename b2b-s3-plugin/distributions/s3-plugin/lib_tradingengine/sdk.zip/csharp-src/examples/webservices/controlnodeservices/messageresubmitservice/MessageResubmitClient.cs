using System;
using MessageResubmitService.MessageResubmitServiceService;
using MessageResubmitService.SessionServiceService;


/// <summary>
/// Simple SOAP Client for the Interchange MessageResubmitService WebService. Demonstrates how to create a user session,
/// resubmit one or more messages to Interchange, and clean up the session.
/// </summary>
class MessageResubmitClient
{
	private const string SESSION_SERVICE_PATH = "/cyclone/services/SessionService";
	private const string MESSAGE_RESUBMIT_SERVICE_PATH = "/cyclone/services/MessageResubmitService";

	private string url;
	private string username;
	private string password;
	private byte[] sessionCookie;

	/// <summary>
	/// Constructor
	/// </summary>
	/// <param name="url">URL to the Interchange UI port - should not include path part of deployed webservices. example http://localhost:6080 </param>
	/// <param name="username"></param>
	/// <param name="password"></param>
	public MessageResubmitClient(string url, string username, string password)
	{
		if (url == null || url.Length == 0) throw new System.NotSupportedException("url cannot be null");
		if (username == null || username.Length == 0) throw new System.NotSupportedException("username cannot be null");
		if (password == null || password.Length == 0) throw new System.NotSupportedException("password cannot be null");

		this.url = url;
		this.username = username;
		this.password = password;
	}

	/// <summary>
	/// Opens a session in Interchange. Note that the session must be closed when resubmit operations are completed.
	/// Otherwise the session will remain open until the default session timeout (30 minutes) closes the session.
	/// </summary>
	public void createSession()
	{
		SessionServiceService sessionService = new SessionServiceService();
		sessionService.Url = url + SESSION_SERVICE_PATH;
		sessionCookie = sessionService.login(username, password);
	}

	/// <summary>
	/// Close the session in Interchange.
	/// </summary>
	public void closeSession()
	{
		if (sessionCookie == null)
			return;

		SessionServiceService sessionService = new SessionServiceService();
		sessionService.Url = url + SESSION_SERVICE_PATH;
		sessionService.logout(sessionCookie);
		sessionCookie = null;
	}

	/// <summary>
	/// Calls the Interchange Resubmit Webservice to resubmit Messages identified by the passed in core IDs.
	/// </summary>
	/// <param name="coreIds">coreId value of the Interchange messages to resubmit.</param>
	public void resubmit(String[] coreIds)
	{
		MessageResubmitServiceService resubmitService = new MessageResubmitServiceService();
		resubmitService.Url = url + MESSAGE_RESUBMIT_SERVICE_PATH;
		if (coreIds.Length == 1)
			resubmitService.resubmitMessage(sessionCookie, coreIds[0]);
		else
			resubmitService.resubmitMultipleMessages(sessionCookie, coreIds);
	}

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main(string[] args)
	{
		if (args.Length < 4)
		{
			Console.WriteLine("usage: MessageResubmitClient base-url username password coreId(s)");
			return;
		}

		string baseUrl = args[0];
		string username = args[1];
		string password = args[2];
		MessageResubmitClient messageResubmitClient = new MessageResubmitClient(baseUrl, username, password);

		try
		{
			messageResubmitClient.createSession();
			messageResubmitClient.resubmit(getCoreIds(args));
		}
		finally
		{
			// An open session should always be closed!
			messageResubmitClient.closeSession();
		}
	}	

	/**
	 * Parse the core IDs out of the argument array.
	 */
	private static string[] getCoreIds(string[] args)
	{
		string[] coreIds = new string[args.Length - 3];
		for (int i = 0; i < args.Length - 3; i++)
			coreIds[i] = args[i + 3];
		return coreIds;
	}
}

