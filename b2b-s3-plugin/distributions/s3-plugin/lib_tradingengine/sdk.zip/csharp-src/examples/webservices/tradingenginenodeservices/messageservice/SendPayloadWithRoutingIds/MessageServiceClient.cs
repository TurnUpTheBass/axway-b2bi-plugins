using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Xml;

namespace MessageServiceClient
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class MessageServiceClient
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			if (args.Length != 2)
			{
				Console.WriteLine("Usage: MessageServiceURL PayloadURL");
			}
			else
			{
				try
				{
					MessageServiceService msgService = new MessageServiceService(args[0]);
					Payload payload = new Payload();
					StreamReader reader = new StreamReader(args[1]);
					ASCIIEncoding ae = new ASCIIEncoding();
					payload.content = ae.GetBytes(reader.ReadToEnd());
					RoutingId sender = new RoutingId();
					sender.routingId = "CommunityA";
					sender.type = "string";

					RoutingId receiver = new RoutingId();
					receiver.routingId = "CommunityA";
					receiver.type = "string";
					MessageDeliveryStatus status = msgService.sendPayloadWithRoutingIds(payload, sender, receiver);
					Console.WriteLine("Sent MessageId: " + status.messageId.messageId + " MessageDeliveryStatus = " + status.messageStatusDescription);
				}
				catch (Exception e)
				{
					Console.WriteLine(e.GetBaseException().ToString());
					Console.WriteLine(e.StackTrace);
				}
			}
		}
	}
}
