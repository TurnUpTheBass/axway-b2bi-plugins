using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Xml;

namespace MessageServiceClient
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class MessageServiceClient
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			if (args.Length != 2)
			{
				Console.WriteLine("Usage: MessageServiceURL PayloadURL");
			}
			else
			{
				try
				{
					MessageServiceService msgService = new MessageServiceService(args[0]);
					Message message = new Message();
					message.payload = new Payload();
					StreamReader reader = new StreamReader(args[1]);
					ASCIIEncoding ae = new ASCIIEncoding();
					message.payload.content = ae.GetBytes(reader.ReadToEnd());
					message.messageMetadata = new Metadata();
					message.messageMetadata.metadataItems = new MetadataItem[10];
					message.messageMetadata.metadataItems[0] = new MetadataItem("SenderRoutingId", "CommunityA");
					message.messageMetadata.metadataItems[1] = new MetadataItem("SenderRoutingIdType", "string");
					message.messageMetadata.metadataItems[2] = new MetadataItem("ReceiverRoutingId", "PartnerB");
					message.messageMetadata.metadataItems[3] = new MetadataItem("ReceiverRoutingIdType", "string");
					message.messageMetadata.metadataItems[4] = new MetadataItem("ebXML_FromRole", "Seller");
					message.messageMetadata.metadataItems[5] = new MetadataItem("ebXML_ToRole", "Buyer");
					message.messageMetadata.metadataItems[6] = new MetadataItem("ebXML_CPAId", "CommunityA-PartnerB-CPA");
					message.messageMetadata.metadataItems[7] = new MetadataItem("ebXML_Service", "FileTransfer");
					message.messageMetadata.metadataItems[8] = new MetadataItem("ebXML_Action", "purchase");
					message.messageMetadata.metadataItems[9] = new MetadataItem("ebXML_MessageId", "ID123456789@ebxml.org");
					MessageId msgId = msgService.submitMessage(message);
					MessageDeliveryStatus status = msgService.getSubmittedMessageStatus(msgId);
					Console.WriteLine("Submitted MessageId: " + status.messageId.messageId + " MessageDeliveryStatus = " + status.messageStatusDescription);
				}
				catch (Exception e)
				{
					Console.WriteLine(e.GetBaseException().ToString());
					Console.WriteLine(e.StackTrace);
				}
			}
		}
	}
}
