/**
 * ClusterControllerServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.ClusterControllerService;

import com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException;

public class ClusterControllerServiceSoapBindingStub extends org.apache.axis.client.Stub implements com.cyclonecommerce.cyclone.services.ClusterControllerService.ClusterControllerService_PortType {
	private java.util.Vector cachedSerClasses = new java.util.Vector();
	private java.util.Vector cachedSerQNames = new java.util.Vector();
	private java.util.Vector cachedSerFactories = new java.util.Vector();
	private java.util.Vector cachedDeserFactories = new java.util.Vector();

	static org.apache.axis.description.OperationDesc [] _operations;

	static {
		_operations = new org.apache.axis.description.OperationDesc[10];
		_initOperationDesc1();
	}

	private static void _initOperationDesc1(){
		org.apache.axis.description.OperationDesc oper;
		org.apache.axis.description.ParameterDesc param;
		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("addNode");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "hostName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "nodeType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "addNodeReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault1"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"),
					  true
					 ));
		_operations[0] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("stopNode");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "nodeName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault1"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"),
					  true
					 ));
		_operations[1] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("removeNode");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "nodeName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault1"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"),
					  true
					 ));
		_operations[2] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("startNode");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "nodeName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault1"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"),
					  true
					 ));
		_operations[3] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("restartNode");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "nodeName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault1"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"),
					  true
					 ));
		_operations[4] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("startNodes");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault1"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"),
					  true
					 ));
		_operations[5] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("stopNodes");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault1"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"),
					  true
					 ));
		_operations[6] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("restartNodes");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault1"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"),
					  true
					 ));
		_operations[7] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("stopCluster");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault1"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"),
					  true
					 ));
		_operations[8] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("restartCluster");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault1"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "fault"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"),
					  true
					 ));
		_operations[9] = oper;

	}

	public ClusterControllerServiceSoapBindingStub() throws org.apache.axis.AxisFault {
		 this(null);
	}

	public ClusterControllerServiceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
		 this(service);
		 super.cachedEndpoint = endpointURL;
	}

	public ClusterControllerServiceSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
		if (service == null) {
			super.service = new org.apache.axis.client.Service();
		} else {
			super.service = service;
		}
		((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
			java.lang.Class cls;
			javax.xml.namespace.QName qName;
			javax.xml.namespace.QName qName2;
			java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
			java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
			java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
			java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
			java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
			java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
			java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
			java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
			java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
			java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
			qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException");
			cachedSerQNames.add(qName);
			cls = com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

			qName = new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException");
			cachedSerQNames.add(qName);
			cls = InvalidSessionException.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

	}

	protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
		try {
			org.apache.axis.client.Call _call = super._createCall();
			if (super.maintainSessionSet) {
				_call.setMaintainSession(super.maintainSession);
			}
			if (super.cachedUsername != null) {
				_call.setUsername(super.cachedUsername);
			}
			if (super.cachedPassword != null) {
				_call.setPassword(super.cachedPassword);
			}
			if (super.cachedEndpoint != null) {
				_call.setTargetEndpointAddress(super.cachedEndpoint);
			}
			if (super.cachedTimeout != null) {
				_call.setTimeout(super.cachedTimeout);
			}
			if (super.cachedPortName != null) {
				_call.setPortName(super.cachedPortName);
			}
			java.util.Enumeration keys = super.cachedProperties.keys();
			while (keys.hasMoreElements()) {
				java.lang.String key = (java.lang.String) keys.nextElement();
				_call.setProperty(key, super.cachedProperties.get(key));
			}
			// All the type mapping information is registered
			// when the first call is made.
			// The type mapping information is actually registered in
			// the TypeMappingRegistry of the service, which
			// is the reason why registration is only needed for the first call.
			synchronized (this) {
				if (firstCall()) {
					// must set encoding style before registering serializers
					_call.setEncodingStyle(null);
					for (int i = 0; i < cachedSerFactories.size(); ++i) {
						java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
						javax.xml.namespace.QName qName =
								(javax.xml.namespace.QName) cachedSerQNames.get(i);
						java.lang.Object x = cachedSerFactories.get(i);
						if (x instanceof Class) {
							java.lang.Class sf = (java.lang.Class)
								 cachedSerFactories.get(i);
							java.lang.Class df = (java.lang.Class)
								 cachedDeserFactories.get(i);
							_call.registerTypeMapping(cls, qName, sf, df, false);
						}
						else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
							org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
								 cachedSerFactories.get(i);
							org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
								 cachedDeserFactories.get(i);
							_call.registerTypeMapping(cls, qName, sf, df, false);
						}
					}
				}
			}
			return _call;
		}
		catch (java.lang.Throwable _t) {
			throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
		}
	}

	public java.lang.String addNode(byte[] cookie, java.lang.String hostName, java.lang.String nodeType) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[0]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("addNode");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "addNode"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, hostName, nodeType});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (java.lang.String) _resp;
			} catch (java.lang.Exception _exception) {
				return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public void stopNode(byte[] cookie, java.lang.String nodeName) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[1]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("stopNode");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "stopNode"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, nodeName});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public void removeNode(byte[] cookie, java.lang.String nodeName) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[2]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("removeNode");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "removeNode"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, nodeName});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public void startNode(byte[] cookie, java.lang.String nodeName) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[3]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("startNode");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "startNode"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, nodeName});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public void restartNode(byte[] cookie, java.lang.String nodeName) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[4]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("restartNode");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "restartNode"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, nodeName});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public void startNodes(byte[] cookie) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[5]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("startNodes");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "startNodes"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public void stopNodes(byte[] cookie) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[6]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("stopNodes");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "stopNodes"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public void restartNodes(byte[] cookie) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[7]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("restartNodes");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "restartNodes"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public void stopCluster(byte[] cookie) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[8]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("stopCluster");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "stopCluster"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public void restartCluster(byte[] cookie) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[9]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("restartCluster");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "restartCluster"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

}
