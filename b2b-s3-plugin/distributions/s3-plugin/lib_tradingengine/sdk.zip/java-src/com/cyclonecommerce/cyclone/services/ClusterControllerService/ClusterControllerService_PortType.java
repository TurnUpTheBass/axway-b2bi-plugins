/**
 * ClusterControllerService_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.ClusterControllerService;

import java.rmi.RemoteException;

public interface ClusterControllerService_PortType extends java.rmi.Remote
{
	public java.lang.String addNode(byte[] cookie, java.lang.String hostName, java.lang.String nodeType) throws RemoteException;

	public void stopNode(byte[] cookie, java.lang.String nodeName) throws RemoteException;

	public void removeNode(byte[] cookie, java.lang.String nodeName) throws RemoteException;

	public void startNode(byte[] cookie, java.lang.String nodeName) throws RemoteException;

	public void restartNode(byte[] cookie, java.lang.String nodeName) throws RemoteException;

	public void startNodes(byte[] cookie) throws RemoteException;

	public void stopNodes(byte[] cookie) throws RemoteException;

	public void restartNodes(byte[] cookie) throws RemoteException;

	public void stopCluster(byte[] cookie) throws RemoteException;

	public void restartCluster(byte[] cookie) throws RemoteException;
}
