/**
 * ClusterInfoServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.ClusterInfoNodeService;

import com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException;

public class ClusterInfoServiceSoapBindingStub
        extends org.apache.axis.client.Stub
        implements com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterInfoService_PortType {
	private java.util.Vector cachedSerClasses = new java.util.Vector();
	private java.util.Vector cachedSerQNames = new java.util.Vector();
	private java.util.Vector cachedSerFactories = new java.util.Vector();
	private java.util.Vector cachedDeserFactories = new java.util.Vector();

	static org.apache.axis.description.OperationDesc [] _operations;

	static {
		_operations = new org.apache.axis.description.OperationDesc[16];
		_initOperationDesc1();
		_initOperationDesc2();
	}

	private static void _initOperationDesc1(){
		org.apache.axis.description.OperationDesc oper;
		org.apache.axis.description.ParameterDesc param;
		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getNodeType");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getNodeTypeReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[0] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getMachineNames");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getMachineNamesReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[1] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getConfiguredNodeNamesForMachine");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getConfiguredNodeNamesForMachineReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[2] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getMachineName");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getMachineNameReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[3] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getNodeStartDate");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
		oper.setReturnClass(java.util.Calendar.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getNodeStartDateReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[4] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getNodeStatus");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "Status"));
		oper.setReturnClass(com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getNodeStatusReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[5] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getMachineStatus");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "Status"));
		oper.setReturnClass(com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getMachineStatusReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[6] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getConfiguredNodes");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "ConfiguredNode"));
		oper.setReturnClass(com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getConfiguredNodesReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[7] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getConfiguredNodesForType");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "ConfiguredNode"));
		oper.setReturnClass(com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getConfiguredNodesForTypeReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[8] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getActiveServiceNodeNames");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getActiveServiceNodeNamesReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[9] = oper;

	}

	private static void _initOperationDesc2(){
		org.apache.axis.description.OperationDesc oper;
		org.apache.axis.description.ParameterDesc param;
		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getNodeStatuses");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "NodeStatus"));
		oper.setReturnClass(com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.NodeStatus[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getNodeStatusesReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[10] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getConfiguredNode");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "ConfiguredNode"));
		oper.setReturnClass(com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getConfiguredNodeReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault1"),
					  "com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "ClusterServiceException"),
					  true
					 ));
		_operations[11] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getControlNodeNames");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getControlNodeNamesReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[12] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getConfiguredNodeNames");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getConfiguredNodeNamesReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[13] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getControlNodeHostNames");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getControlNodeHostNamesReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[14] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getClusterStatus");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "Status"));
		oper.setReturnClass(com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getClusterStatusReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "fault"),
					  "InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		_operations[15] = oper;

	}

	public ClusterInfoServiceSoapBindingStub() throws org.apache.axis.AxisFault {
		 this(null);
	}

	public ClusterInfoServiceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
		 this(service);
		 super.cachedEndpoint = endpointURL;
	}

	public ClusterInfoServiceSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
		if (service == null) {
			super.service = new org.apache.axis.client.Service();
		} else {
			super.service = service;
		}
		((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
			java.lang.Class cls;
			javax.xml.namespace.QName qName;
			javax.xml.namespace.QName qName2;
			java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
			java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
			java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
			java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
			java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
			java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
			java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
			java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
			java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
			java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
			qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "ClusterServiceException");
			cachedSerQNames.add(qName);
			cls = com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

			qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "ConfiguredNode");
			cachedSerQNames.add(qName);
			cls = com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

			qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "NodeStatus");
			cachedSerQNames.add(qName);
			cls = com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.NodeStatus.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

			qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "Status");
			cachedSerQNames.add(qName);
			cls = com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

			qName = new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException");
			cachedSerQNames.add(qName);
			cls = InvalidSessionException.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

	}

	protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
		try {
			org.apache.axis.client.Call _call = super._createCall();
			if (super.maintainSessionSet) {
				_call.setMaintainSession(super.maintainSession);
			}
			if (super.cachedUsername != null) {
				_call.setUsername(super.cachedUsername);
			}
			if (super.cachedPassword != null) {
				_call.setPassword(super.cachedPassword);
			}
			if (super.cachedEndpoint != null) {
				_call.setTargetEndpointAddress(super.cachedEndpoint);
			}
			if (super.cachedTimeout != null) {
				_call.setTimeout(super.cachedTimeout);
			}
			if (super.cachedPortName != null) {
				_call.setPortName(super.cachedPortName);
			}
			java.util.Enumeration keys = super.cachedProperties.keys();
			while (keys.hasMoreElements()) {
				java.lang.String key = (java.lang.String) keys.nextElement();
				_call.setProperty(key, super.cachedProperties.get(key));
			}
			// All the type mapping information is registered
			// when the first call is made.
			// The type mapping information is actually registered in
			// the TypeMappingRegistry of the service, which
			// is the reason why registration is only needed for the first call.
			synchronized (this) {
				if (firstCall()) {
					// must set encoding style before registering serializers
					_call.setEncodingStyle(null);
					for (int i = 0; i < cachedSerFactories.size(); ++i) {
						java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
						javax.xml.namespace.QName qName =
								(javax.xml.namespace.QName) cachedSerQNames.get(i);
						java.lang.Object x = cachedSerFactories.get(i);
						if (x instanceof Class) {
							java.lang.Class sf = (java.lang.Class)
								 cachedSerFactories.get(i);
							java.lang.Class df = (java.lang.Class)
								 cachedDeserFactories.get(i);
							_call.registerTypeMapping(cls, qName, sf, df, false);
						}
						else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
							org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
								 cachedSerFactories.get(i);
							org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
								 cachedDeserFactories.get(i);
							_call.registerTypeMapping(cls, qName, sf, df, false);
						}
					}
				}
			}
			return _call;
		}
		catch (java.lang.Throwable _t) {
			throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
		}
	}

	public java.lang.String getNodeType(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[0]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getNodeType");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getNodeType"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (java.lang.String) _resp;
			} catch (java.lang.Exception _exception) {
				return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public java.lang.String[] getMachineNames(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[1]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getMachineNames");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getMachineNames"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (java.lang.String[]) _resp;
			} catch (java.lang.Exception _exception) {
				return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public java.lang.String[] getConfiguredNodeNamesForMachine(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[2]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getConfiguredNodeNamesForMachine");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getConfiguredNodeNamesForMachine"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (java.lang.String[]) _resp;
			} catch (java.lang.Exception _exception) {
				return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public java.lang.String getMachineName(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[3]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getMachineName");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getMachineName"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (java.lang.String) _resp;
			} catch (java.lang.Exception _exception) {
				return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public java.util.Calendar getNodeStartDate(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[4]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getNodeStartDate");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getNodeStartDate"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (java.util.Calendar) _resp;
			} catch (java.lang.Exception _exception) {
				return (java.util.Calendar) org.apache.axis.utils.JavaUtils.convert(_resp, java.util.Calendar.class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status getNodeStatus(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[5]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getNodeStatus");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getNodeStatus"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status) _resp;
			} catch (java.lang.Exception _exception) {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status) org.apache.axis.utils.JavaUtils.convert(_resp, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status.class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status getMachineStatus(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[6]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getMachineStatus");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getMachineStatus"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status) _resp;
			} catch (java.lang.Exception _exception) {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status) org.apache.axis.utils.JavaUtils.convert(_resp, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status.class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[] getConfiguredNodes(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[7]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getConfiguredNodes");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getConfiguredNodes"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[]) _resp;
			} catch (java.lang.Exception _exception) {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[].class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[] getConfiguredNodesForType(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[8]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getConfiguredNodesForType");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getConfiguredNodesForType"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[]) _resp;
			} catch (java.lang.Exception _exception) {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[].class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public java.lang.String[] getActiveServiceNodeNames(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[9]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getActiveServiceNodeNames");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getActiveServiceNodeNames"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (java.lang.String[]) _resp;
			} catch (java.lang.Exception _exception) {
				return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.NodeStatus[] getNodeStatuses(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[10]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getNodeStatuses");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getNodeStatuses"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.NodeStatus[]) _resp;
			} catch (java.lang.Exception _exception) {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.NodeStatus[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.NodeStatus[].class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode getConfiguredNode(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[11]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getConfiguredNode");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getConfiguredNode"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode) _resp;
			} catch (java.lang.Exception _exception) {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode) org.apache.axis.utils.JavaUtils.convert(_resp, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode.class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) {
			  throw (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterServiceException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public java.lang.String[] getControlNodeNames(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[12]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getControlNodeNames");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getControlNodeNames"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (java.lang.String[]) _resp;
			} catch (java.lang.Exception _exception) {
				return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public java.lang.String[] getConfiguredNodeNames(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[13]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getConfiguredNodeNames");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getConfiguredNodeNames"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (java.lang.String[]) _resp;
			} catch (java.lang.Exception _exception) {
				return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public java.lang.String[] getControlNodeHostNames(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[14]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getControlNodeHostNames");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getControlNodeHostNames"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (java.lang.String[]) _resp;
			} catch (java.lang.Exception _exception) {
				return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status getClusterStatus(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException {
		if (super.cachedEndpoint == null) {
			throw new org.apache.axis.NoEndPointException();
		}
		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[15]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getClusterStatus");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterInfoService", "getClusterStatus"));

		setRequestHeaders(_call);
		setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

		if (_resp instanceof java.rmi.RemoteException) {
			throw (java.rmi.RemoteException)_resp;
		}
		else {
			extractAttachments(_call);
			try {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status) _resp;
			} catch (java.lang.Exception _exception) {
				return (com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status) org.apache.axis.utils.JavaUtils.convert(_resp, com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status.class);
			}
		}
  } catch (org.apache.axis.AxisFault axisFaultException) {
	if (axisFaultException.detail != null) {
		if (axisFaultException.detail instanceof java.rmi.RemoteException) {
			  throw (java.rmi.RemoteException) axisFaultException.detail;
		 }
		if (axisFaultException.detail instanceof InvalidSessionException) {
			  throw (InvalidSessionException) axisFaultException.detail;
		 }
   }
  throw axisFaultException;
}
	}

}
