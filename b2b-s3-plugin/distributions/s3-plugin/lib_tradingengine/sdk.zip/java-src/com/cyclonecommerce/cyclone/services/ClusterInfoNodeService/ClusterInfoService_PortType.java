/**
 * ClusterInfoService_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.ClusterInfoNodeService;

import com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException;

public interface ClusterInfoService_PortType extends java.rmi.Remote {
	public java.lang.String getNodeType(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException;
	public java.lang.String[] getMachineNames(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException;
	public java.lang.String[] getConfiguredNodeNamesForMachine(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException;
	public java.lang.String getMachineName(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException;
	public java.util.Calendar getNodeStartDate(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException;
	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status getNodeStatus(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException;
	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status getMachineStatus(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException;
	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[] getConfiguredNodes(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException;
	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode[] getConfiguredNodesForType(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException;
	public java.lang.String[] getActiveServiceNodeNames(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException;
	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.NodeStatus[] getNodeStatuses(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException;
	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode getConfiguredNode(byte[] in0, java.lang.String in1) throws java.rmi.RemoteException, InvalidSessionException, com.cyclonecommerce.clustercontroller.controlnode.webservice.ClusterServiceException;
	public java.lang.String[] getControlNodeNames(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException;
	public java.lang.String[] getConfiguredNodeNames(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException;
	public java.lang.String[] getControlNodeHostNames(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException;
	public com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status getClusterStatus(byte[] in0) throws java.rmi.RemoteException, InvalidSessionException;
}
