/**
 * ClusterServiceException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.ClusterInfoNodeService;

import org.w3c.dom.Element;

import javax.xml.namespace.QName;

public class ClusterServiceException  extends org.apache.axis.AxisFault  implements java.io.Serializable {
	public ClusterServiceException(String code, String faultString, String actor, Element[] details)
	{
		super(code, faultString, actor, details);
	}

	public ClusterServiceException(QName code, String faultString, String actor, Element[] details)
	{
		super(code, faultString, actor, details);
	}

	public ClusterServiceException(QName code, QName[] subcodes, String faultString, String actor, String node, Element[] details)
	{
		super(code, subcodes, faultString, actor, node, details);
	}

	protected ClusterServiceException(Exception target)
	{
		super(target);
	}

	public ClusterServiceException(String message)
	{
		super(message);
	}

	public ClusterServiceException(String message, Throwable t)
	{
		super(message, t);
	}

	public ClusterServiceException() {
	}

	private java.lang.Object __equalsCalc = null;
	public synchronized boolean equals(java.lang.Object obj) {
		if (!(obj instanceof ClusterServiceException)) return false;
		ClusterServiceException other = (ClusterServiceException) obj;
		if (obj == null) return false;
		if (this == obj) return true;
		if (__equalsCalc != null) {
			return (__equalsCalc == obj);
		}
		__equalsCalc = obj;
		boolean _equals;
		_equals = true;
		__equalsCalc = null;
		return _equals;
	}

	private boolean __hashCodeCalc = false;
	public synchronized int hashCode() {
		if (__hashCodeCalc) {
			return 0;
		}
		__hashCodeCalc = true;
		int _hashCode = 1;
		__hashCodeCalc = false;
		return _hashCode;
	}

	// Type metadata
	private static org.apache.axis.description.TypeDesc typeDesc =
		new org.apache.axis.description.TypeDesc(ClusterServiceException.class, true);

	static {
		typeDesc.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/ClusterControllerService", "ClusterServiceException"));
	}

	/**
	 * Return type metadata object
	 */
	public static org.apache.axis.description.TypeDesc getTypeDesc() {
		return typeDesc;
	}

	/**
	 * Get Custom Serializer
	 */
	public static org.apache.axis.encoding.Serializer getSerializer(
		   java.lang.String mechType,
		   java.lang.Class _javaType,
		   javax.xml.namespace.QName _xmlType) {
		return
		  new  org.apache.axis.encoding.ser.BeanSerializer(
			_javaType, _xmlType, typeDesc);
	}

	/**
	 * Get Custom Deserializer
	 */
	public static org.apache.axis.encoding.Deserializer getDeserializer(
		   java.lang.String mechType,
		   java.lang.Class _javaType,
		   javax.xml.namespace.QName _xmlType) {
		return
		  new  org.apache.axis.encoding.ser.BeanDeserializer(
			_javaType, _xmlType, typeDesc);
	}


	/**
	 * Writes the exception data to the faultDetails
	 */
	public void writeDetails(javax.xml.namespace.QName qname, org.apache.axis.encoding.SerializationContext context) throws java.io.IOException {
		context.serialize(qname, null, this);
	}
}
