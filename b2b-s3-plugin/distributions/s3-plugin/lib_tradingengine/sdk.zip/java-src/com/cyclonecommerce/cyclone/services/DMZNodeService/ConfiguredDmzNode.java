// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

/**
 * ConfiguredDmzNode.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */
package com.cyclonecommerce.cyclone.services.DMZNodeService;

public class ConfiguredDmzNode implements java.io.Serializable
{
	private String hostName;
	private Integer port;
	private Integer controlPort;
	private Integer minPort;
	private Integer maxPort;
	private Integer nbDataConnection;
	private String zone;

	public ConfiguredDmzNode()
	{
	}

	public ConfiguredDmzNode(
			java.lang.String hostName,
			java.lang.Integer port,
			java.lang.Integer controlPort,
			java.lang.Integer minPort,
			java.lang.Integer maxPort,
			java.lang.Integer nbDataConnection,
			java.lang.String zone)
	{
		this.hostName = hostName;
		this.port = port;
		this.controlPort = controlPort;
		this.minPort = minPort;
		this.maxPort = maxPort;
		this.nbDataConnection = nbDataConnection;
		this.zone = zone;
	}

	/**
	 * Gets the hostName value for this ConfiguredDmzNode.
	 *
	 * @return hostName
	 */
	public synchronized java.lang.String getHostName()
	{
		return hostName;
	}

	/**
	 * Sets the hostName value for this ConfiguredDmzNode.
	 *
	 * @param hostName
	 */
	public synchronized void setHostName(java.lang.String hostName)
	{
		this.hostName = hostName;
	}

	/**
	 * Gets the port value for this ConfiguredDmzNode.
	 *
	 * @return port
	 */
	public synchronized java.lang.Integer getPort()
	{
		return port;
	}

	/**
	 * Sets the port value for this ConfiguredDmzNode.
	 *
	 * @param port
	 */
    public synchronized void setPort(java.lang.Integer port)
	{
		this.port = port;
	}

	/**
	 * Gets the controlPort value for this ConfiguredDmzNode.
	 *
	 * @return controlPort
	 */
	public synchronized java.lang.Integer getControlPort()
	{
		return controlPort;
	}

	/**
	 * Sets the controlPort value for this ConfiguredDmzNode.
	 *
	 * @param controlPort
	 */
	public synchronized void setControlPort(java.lang.Integer controlPort)
	{
		this.controlPort = controlPort;
	}

	/**
	 * Gets the minPort value for this ConfiguredDmzNode.
	 *
	 * @return minPort
	 */
	public synchronized java.lang.Integer getMinPort()
	{
		return minPort;
	}

	/**
	 * Sets the minPort value for this ConfiguredDmzNode.
	 *
	 * @param minPort
	 */
	public synchronized void setMinPort(java.lang.Integer minPort)
	{
		this.minPort = minPort;
	}

	/**
	 * Gets the maxPort value for this ConfiguredDmzNode.
	 *
	 * @return maxPort
	 */
	public synchronized java.lang.Integer getMaxPort()
	{
		return maxPort;
	}

	/**
	 * Sets the maxPort value for this ConfiguredDmzNode.
	 *
	 * @param maxPort
	 */
	public synchronized void setMaxPort(java.lang.Integer maxPort)
	{
		this.maxPort = maxPort;
	}

	/**
	 * Gets the nbDataConnection value for this ConfiguredDmzNode.
	 *
	 * @return nbDataConnection
	 */
	public synchronized java.lang.Integer getNbDataConnection()
	{
		return nbDataConnection;
	}

	/**
	 * Sets the nbDataConnection value for this ConfiguredDmzNode.
	 *
	 * @param nbDataConnection
	 */
	public synchronized void setNbDataConnection(java.lang.Integer nbDataConnection)
	{
		this.nbDataConnection = nbDataConnection;
	}

	/**
	 * Gets the zone value for this ConfiguredDmzNode.
	 *
	 * @return zone
	 */
	public synchronized java.lang.String getZone()
	{
		return zone;
	}

	/**
	 * Sets the zone value for this ConfiguredDmzNode.
	 *
	 * @param zone
	 */
	public synchronized void setZone(java.lang.String zone)
	{
		this.zone = zone;
	}

	private java.lang.Object __equalsCalc = null;
	public synchronized boolean equals(java.lang.Object obj)
	{
		if (!(obj instanceof ConfiguredDmzNode))
			return false;

		ConfiguredDmzNode other = (ConfiguredDmzNode) obj;

		if (this == obj)
			return true;

		if (__equalsCalc != null)
			return (__equalsCalc == obj);

		__equalsCalc = obj;
		boolean _equals;
		_equals = true &&
			((this.hostName==null && other.getHostName()==null) ||
			 (this.hostName!=null &&
			  this.hostName.equals(other.getHostName()))) &&
			((this.port==null && other.getPort()==null) ||
			 (this.port!=null &&
			  this.port.equals(other.getPort()))) &&
			((this.controlPort==null && other.getControlPort()==null) ||
			 (this.controlPort!=null &&
			  this.controlPort.equals(other.getControlPort()))) &&
			((this.minPort==null && other.getMinPort()==null) ||
			 (this.minPort!=null &&
			  this.minPort.equals(other.getMinPort()))) &&
			((this.maxPort==null && other.getMaxPort()==null) ||
			 (this.maxPort!=null &&
			  this.maxPort.equals(other.getMaxPort()))) &&
			((this.nbDataConnection==null && other.getNbDataConnection()==null) ||
			 (this.nbDataConnection!=null &&
			  this.nbDataConnection.equals(other.getNbDataConnection()))) &&
			((this.zone==null && other.getZone()==null) ||
			 (this.zone!=null &&
			  this.zone.equals(other.getZone())));

		__equalsCalc = null;
		return _equals;
	}

	private boolean __hashCodeCalc = false;
	public synchronized int hashCode()
	{
		if (__hashCodeCalc)
			return 0;

		__hashCodeCalc = true;
		int _hashCode = 1;

		if (getHostName() != null)
			_hashCode += getHostName().hashCode();

		if (getPort() != null)
			_hashCode += getPort().hashCode();

		if (getControlPort() != null)
			_hashCode += getControlPort().hashCode();

		if (getMinPort() != null)
			_hashCode += getMinPort().hashCode();

		if (getMaxPort() != null)
			_hashCode += getMaxPort().hashCode();

		if (getNbDataConnection() != null)
			_hashCode += getNbDataConnection().hashCode();

		if (getZone() != null)
			_hashCode += getZone().hashCode();

		__hashCodeCalc = false;

		return _hashCode;
	}

	// Type metadata
	private static org.apache.axis.description.TypeDesc typeDesc =
		new org.apache.axis.description.TypeDesc(ConfiguredDmzNode.class, true);

	static
	{
		typeDesc.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "ConfiguredDmzNode"));
		org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
		elemField.setFieldName("hostName");
		elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "hostName"));
		elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		elemField.setNillable(true);
		typeDesc.addFieldDesc(elemField);
		elemField = new org.apache.axis.description.ElementDesc();
		elemField.setFieldName("port");
		elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "port"));
		elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
		elemField.setNillable(true);
		typeDesc.addFieldDesc(elemField);
		elemField = new org.apache.axis.description.ElementDesc();
		elemField.setFieldName("controlPort");
		elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "controlPort"));
		elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
		elemField.setNillable(true);
		typeDesc.addFieldDesc(elemField);
		elemField = new org.apache.axis.description.ElementDesc();
		elemField.setFieldName("minPort");
		elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "minPort"));
		elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
		elemField.setNillable(true);
		typeDesc.addFieldDesc(elemField);
		elemField = new org.apache.axis.description.ElementDesc();
		elemField.setFieldName("maxPort");
		elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "maxPort"));
		elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
		elemField.setNillable(true);
		typeDesc.addFieldDesc(elemField);
		elemField = new org.apache.axis.description.ElementDesc();
		elemField.setFieldName("nbDataConnection");
		elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "nbDataConnection"));
		elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
		elemField.setNillable(true);
		typeDesc.addFieldDesc(elemField);
		elemField = new org.apache.axis.description.ElementDesc();
		elemField.setFieldName("zone");
		elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "zone"));
		elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		elemField.setNillable(false);
		typeDesc.addFieldDesc(elemField);
	}

	/**
	 * Return type metadata object
	 */
	public static org.apache.axis.description.TypeDesc getTypeDesc()
	{
		return typeDesc;
	}

	/**
	 * Get Custom Serializer
	 */
	public static org.apache.axis.encoding.Serializer getSerializer(
			java.lang.String mechType,
			java.lang.Class _javaType,
			javax.xml.namespace.QName _xmlType)
	{
		return new org.apache.axis.encoding.ser.BeanSerializer(_javaType, _xmlType, typeDesc);
	}

	/**
	 * Get Custom Deserializer
	 */
	public static org.apache.axis.encoding.Deserializer getDeserializer(
			java.lang.String mechType,
			java.lang.Class _javaType,
			javax.xml.namespace.QName _xmlType)
	{
		return new org.apache.axis.encoding.ser.BeanDeserializer(_javaType, _xmlType, typeDesc);
	}
}
