// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

/**
 * DmzNodeServiceException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */
package com.cyclonecommerce.cyclone.services.DMZNodeService;

import org.w3c.dom.Element;

import javax.xml.namespace.QName;

public class DmzNodeServiceException
		extends org.apache.axis.AxisFault
		implements java.io.Serializable
{
	@SuppressWarnings({"UnusedDeclaration"})
	public DmzNodeServiceException(String code, String faultString, String actor, Element[] details)
	{
		super(code, faultString, actor, details);
	}

	@SuppressWarnings({"UnusedDeclaration"})
	public DmzNodeServiceException(QName code, String faultString, String actor, Element[] details)
	{
		super(code, faultString, actor, details);
	}

	@SuppressWarnings({"UnusedDeclaration"})
	public DmzNodeServiceException(QName code, QName[] subcodes, String faultString, String actor, String node, Element[] details)
	{
		super(code, subcodes, faultString, actor, node, details);
	}

	@SuppressWarnings({"UnusedDeclaration"})
	protected DmzNodeServiceException(Exception target)
	{
		super(target);
	}

	@SuppressWarnings({"UnusedDeclaration"})
	public DmzNodeServiceException(String message)
	{
		super(message);
	}

	@SuppressWarnings({"UnusedDeclaration"})
	public DmzNodeServiceException(String message, Throwable t)
	{
		super(message, t);
	}

	@SuppressWarnings({"UnusedDeclaration"})
	public DmzNodeServiceException()
	{
	}

	private java.lang.Object __equalsCalc = null;

	public synchronized boolean equals(java.lang.Object obj)
	{
		if (!(obj instanceof DmzNodeServiceException))
			return false;

		if (this == obj)
			return true;
		if (__equalsCalc != null)
			return (__equalsCalc == obj);

		__equalsCalc = obj;
		boolean _equals;
		_equals = true;
		__equalsCalc = null;
		return _equals;
	}

	private boolean __hashCodeCalc = false;
	public synchronized int hashCode()
	{
		if (__hashCodeCalc)
			return 0;

		__hashCodeCalc = true;
		int _hashCode = 1;
		__hashCodeCalc = false;
		return _hashCode;
	}

	// Type metadata
	private static org.apache.axis.description.TypeDesc typeDesc =
			new org.apache.axis.description.TypeDesc(DmzNodeServiceException.class, true);

	static
	{
		typeDesc.setXmlType(new QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "DmzNodeServiceException"));
	}

	/**
	 * Return type metadata object
	 */
	public static org.apache.axis.description.TypeDesc getTypeDesc()
	{
		return typeDesc;
	}

	/**
	 * Get Custom Serializer
	 */
	public static org.apache.axis.encoding.Serializer getSerializer(
			java.lang.String mechType,
			java.lang.Class _javaType,
			QName _xmlType)
	{
		return new  org.apache.axis.encoding.ser.BeanSerializer(_javaType, _xmlType, typeDesc);
	}

	/**
	 * Get Custom Deserializer
	 */
	public static org.apache.axis.encoding.Deserializer getDeserializer(
			java.lang.String mechType,
			java.lang.Class _javaType,
			QName _xmlType)
	{
		return new  org.apache.axis.encoding.ser.BeanDeserializer(_javaType, _xmlType, typeDesc);
	}

	/**
	 * Writes the exception data to the faultDetails
	 */
	public void writeDetails(QName qname, org.apache.axis.encoding.SerializationContext context)
			throws java.io.IOException
	{
		context.serialize(qname, null, this);
	}
}