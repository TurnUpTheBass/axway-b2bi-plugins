// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

/**
 * DmzNodeServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */
package com.cyclonecommerce.cyclone.services.DMZNodeService;

public interface DmzNodeServiceService extends javax.xml.rpc.Service
{
	public java.lang.String getDmzNodeServiceAddress();

	public com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeService_PortType getDmzNodeService()
			throws javax.xml.rpc.ServiceException;

	public com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeService_PortType getDmzNodeService(java.net.URL portAddress)
			throws javax.xml.rpc.ServiceException;
}
