// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

/**
 * DmzNodeServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */
package com.cyclonecommerce.cyclone.services.DMZNodeService;

public class DmzNodeServiceServiceLocator
		extends org.apache.axis.client.Service
		implements com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceService
{
	public DmzNodeServiceServiceLocator()
	{
	}

	public DmzNodeServiceServiceLocator(org.apache.axis.EngineConfiguration config)
	{
		super(config);
	}

	public DmzNodeServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName)
			throws javax.xml.rpc.ServiceException
	{
		super(wsdlLoc, sName);
	}

	// Use to get a proxy class for DmzNodeService
	private java.lang.String DmzNodeService_address = "http://localhost:6080/cyclone/services/DmzNodeService";

	public java.lang.String getDmzNodeServiceAddress()
	{
		return DmzNodeService_address;
	}

	// The WSDD service name defaults to the port name.
	private java.lang.String DmzNodeServiceWSDDServiceName = "DmzNodeService";

	public java.lang.String getDmzNodeServiceWSDDServiceName()
	{
		return DmzNodeServiceWSDDServiceName;
	}

	public void setDmzNodeServiceWSDDServiceName(java.lang.String name)
	{
		DmzNodeServiceWSDDServiceName = name;
	}

	public com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeService_PortType getDmzNodeService()
			throws javax.xml.rpc.ServiceException
	{
		java.net.URL endpoint;
		try
		{
			endpoint = new java.net.URL(DmzNodeService_address);
		}
		catch (java.net.MalformedURLException e)
		{
			throw new javax.xml.rpc.ServiceException(e);
		}
		return getDmzNodeService(endpoint);
	}

	public com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeService_PortType getDmzNodeService(java.net.URL portAddress)
			throws javax.xml.rpc.ServiceException
	{
		try
		{
			com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceSoapBindingStub _stub =
					new com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceSoapBindingStub(portAddress, this);

			_stub.setPortName(getDmzNodeServiceWSDDServiceName());
			return _stub;
		}
		catch (org.apache.axis.AxisFault e)
		{
			return null;
		}
	}

	public void setDmzNodeServiceEndpointAddress(java.lang.String address)
	{
		DmzNodeService_address = address;
	}

	/**
	 * For the given interface, get the stub implementation.
	 * If this service has no port for the given interface,
	 * then ServiceException is thrown.
	 */
	public java.rmi.Remote getPort(Class serviceEndpointInterface)
			throws javax.xml.rpc.ServiceException
	{
		try
		{
			if (com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeService_PortType.class.isAssignableFrom(serviceEndpointInterface))
			{
				com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceSoapBindingStub _stub =
						new com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceSoapBindingStub(
								new java.net.URL(DmzNodeService_address), this);

				_stub.setPortName(getDmzNodeServiceWSDDServiceName());
				return _stub;
			}
		}
		catch (java.lang.Throwable t)
		{
			throw new javax.xml.rpc.ServiceException(t);
		}
		throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " +
				(serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
	}

	/**
	 * For the given interface, get the stub implementation.
	 * If this service has no port for the given interface,
	 * then ServiceException is thrown.
	 */
	public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface)
			throws javax.xml.rpc.ServiceException
	{
		if (portName == null)
			return getPort(serviceEndpointInterface);

		java.lang.String inputPortName = portName.getLocalPart();
		if ("DmzNodeService".equals(inputPortName))
			return getDmzNodeService();
		else
		{
			java.rmi.Remote _stub = getPort(serviceEndpointInterface);
			((org.apache.axis.client.Stub) _stub).setPortName(portName);
			return _stub;
		}
	}

	public javax.xml.namespace.QName getServiceName()
	{
		return new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "DmzNodeServiceService");
	}

	private java.util.HashSet ports = null;

	public java.util.Iterator getPorts()
	{
		if (ports == null)
		{
			ports = new java.util.HashSet();
			ports.add(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "DmzNodeService"));
		}
		return ports.iterator();
	}

	/**
	 * Set the endpoint address for the specified port name.
	 */
	public void setEndpointAddress(java.lang.String portName, java.lang.String address)
			throws javax.xml.rpc.ServiceException
	{
		if ("DmzNodeService".equals(portName))
			setDmzNodeServiceEndpointAddress(address);
		else // Unknown Port Name
			throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
	}

	/**
	 * Set the endpoint address for the specified port name.
	 */
	public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address)
			throws javax.xml.rpc.ServiceException
	{
		setEndpointAddress(portName.getLocalPart(), address);
	}
}
