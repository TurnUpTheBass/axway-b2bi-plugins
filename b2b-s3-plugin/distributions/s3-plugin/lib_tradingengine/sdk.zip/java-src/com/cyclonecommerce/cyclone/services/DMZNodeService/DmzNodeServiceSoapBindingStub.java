// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

/**
 * DmzNodeServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */
package com.cyclonecommerce.cyclone.services.DMZNodeService;

public class DmzNodeServiceSoapBindingStub
		extends org.apache.axis.client.Stub
		implements com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeService_PortType
{
	private java.util.Vector cachedSerClasses = new java.util.Vector();
	private java.util.Vector cachedSerQNames = new java.util.Vector();
	private java.util.Vector cachedSerFactories = new java.util.Vector();
	private java.util.Vector cachedDeserFactories = new java.util.Vector();

	static org.apache.axis.description.OperationDesc [] _operations;

	static
	{
		_operations = new org.apache.axis.description.OperationDesc[10];
		_initOperationDesc1();
	}

	private static void _initOperationDesc1()
	{
		org.apache.axis.description.OperationDesc oper;
		org.apache.axis.description.ParameterDesc param;
		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("keyExists");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
		oper.setReturnClass(boolean.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "keyExistsReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
				new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault1"),
				"com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
				new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
				true
		));
		_operations[0] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("setPassword");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "password"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault1"),
						"com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
						new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
						true
					));
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault"),
						"com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException",
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "DmzNodeServiceException"),
						true
					));
		_operations[1] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("addZone");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "name"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "description"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "addZoneReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault1"),
						"com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
						new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
						true
					));
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault"),
						"com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException",
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "DmzNodeServiceException"),
						true
					));
		_operations[2] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("addNode");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "hostName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "port"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "minRangePort"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "maxRangePort"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "controlPort"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "nbDataConnections"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "dmzZone"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "addNodeReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault1"),
						"com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
						new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
						true
					));
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault"),
						"com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException",
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "DmzNodeServiceException"),
						true
					));
		_operations[3] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("removeZone");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "zoneName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault1"),
						"com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
						new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
						true
					));
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault"),
						"com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException",
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "DmzNodeServiceException"),
						true
					));
		_operations[4] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("removeNode");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "hostName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault1"),
						"com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
						new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
						true
					));
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault"),
						"com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException",
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "DmzNodeServiceException"),
						true
					));
		_operations[5] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getZoneNames");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "getZoneNamesReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault1"),
						"com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
						new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
						true
					));
		_operations[6] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getConfiguredDmzNodes");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "ConfiguredDmzNode"));
		oper.setReturnClass(com.cyclonecommerce.cyclone.services.DMZNodeService.ConfiguredDmzNode[].class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "getConfiguredDmzNodesReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault1"),
						"com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
						new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
						true
					));
		_operations[7] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("getDmzNodeStatus");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "hostName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "Status"));
		oper.setReturnClass(com.cyclonecommerce.cyclone.services.DMZNodeService.Status.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "getDmzNodeStatusReturn"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);
		oper.addFault(new org.apache.axis.description.FaultDesc(
						new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault1"),
						"com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
						new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
						true
					));
		_operations[8] = oper;

		oper = new org.apache.axis.description.OperationDesc();
		oper.setName("exportAgent");
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
		oper.addParameter(param);
		param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "hostName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
		oper.addParameter(param);
		oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		oper.setReturnClass(java.lang.String.class);
		oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "exportAgentFileName"));
		oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
		oper.setUse(org.apache.axis.constants.Use.LITERAL);

		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault1"),
					  "com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
					  new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException"),
					  true
					 ));
		oper.addFault(new org.apache.axis.description.FaultDesc(
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "fault"),
					  "com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException",
					  new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "DmzNodeServiceException"),
					  true
					 ));
		_operations[9] = oper;
	}

	public DmzNodeServiceSoapBindingStub()
			throws org.apache.axis.AxisFault
	{
		 this(null);
	}

	public DmzNodeServiceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service)
			throws org.apache.axis.AxisFault
	{
		 this(service);
		 super.cachedEndpoint = endpointURL;
	}

	public DmzNodeServiceSoapBindingStub(javax.xml.rpc.Service service)
			throws org.apache.axis.AxisFault
	{
		if (service == null)
			super.service = new org.apache.axis.client.Service();
		else
			super.service = service;

		((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
			java.lang.Class cls;
			javax.xml.namespace.QName qName;
			javax.xml.namespace.QName qName2;
			java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
			java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
			java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
			java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
			java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
			java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
			java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
			java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
			java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
			java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
			qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "ConfiguredDmzNode");
			cachedSerQNames.add(qName);
			cls = com.cyclonecommerce.cyclone.services.DMZNodeService.ConfiguredDmzNode.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

			qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "DmzNodeServiceException");
			cachedSerQNames.add(qName);
			cls = com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

			qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "Status");
			cachedSerQNames.add(qName);
			cls = com.cyclonecommerce.cyclone.services.DMZNodeService.Status.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

			qName = new javax.xml.namespace.QName("http://webservice.security.cachet.cyclonecommerce.com", "InvalidSessionException");
			cachedSerQNames.add(qName);
			cls = com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException.class;
			cachedSerClasses.add(cls);
			cachedSerFactories.add(beansf);
			cachedDeserFactories.add(beandf);

	}

	protected org.apache.axis.client.Call createCall()
			throws java.rmi.RemoteException
	{
		try
		{
			org.apache.axis.client.Call _call = super._createCall();
			if (super.maintainSessionSet)
				_call.setMaintainSession(super.maintainSession);
			if (super.cachedUsername != null)
				_call.setUsername(super.cachedUsername);
			if (super.cachedPassword != null)
				_call.setPassword(super.cachedPassword);
			if (super.cachedEndpoint != null)
				_call.setTargetEndpointAddress(super.cachedEndpoint);
			if (super.cachedTimeout != null)
				_call.setTimeout(super.cachedTimeout);
			if (super.cachedPortName != null)
				_call.setPortName(super.cachedPortName);

			java.util.Enumeration keys = super.cachedProperties.keys();
			while (keys.hasMoreElements())
			{
				java.lang.String key = (java.lang.String) keys.nextElement();
				_call.setProperty(key, super.cachedProperties.get(key));
			}
			// All the type mapping information is registered
			// when the first call is made.
			// The type mapping information is actually registered in
			// the TypeMappingRegistry of the service, which
			// is the reason why registration is only needed for the first call.
			synchronized (this)
			{
				if (firstCall())
				{
					// must set encoding style before registering serializers
					_call.setEncodingStyle(null);
					for (int i = 0; i < cachedSerFactories.size(); ++i)
					{
						java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
						javax.xml.namespace.QName qName =
								(javax.xml.namespace.QName) cachedSerQNames.get(i);
						java.lang.Object x = cachedSerFactories.get(i);
						if (x instanceof Class)
						{
							java.lang.Class sf = (java.lang.Class)
								 cachedSerFactories.get(i);
							java.lang.Class df = (java.lang.Class)
								 cachedDeserFactories.get(i);
							_call.registerTypeMapping(cls, qName, sf, df, false);
						}
						else if (x instanceof javax.xml.rpc.encoding.SerializerFactory)
						{
							org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
								 cachedSerFactories.get(i);
							org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
								 cachedDeserFactories.get(i);
							_call.registerTypeMapping(cls, qName, sf, df, false);
						}
					}
				}
			}
			return _call;
		}
		catch (java.lang.Throwable _t)
		{
			throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
		}
	}

	public boolean keyExists(byte[] cookie)
			throws java.rmi.RemoteException
	{
		if (super.cachedEndpoint == null)
			throw new org.apache.axis.NoEndPointException();

		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[0]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("keyExists");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "keyExists"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try
		{
			java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie});
			if (_resp instanceof java.rmi.RemoteException)
			{
				throw (java.rmi.RemoteException)_resp;
			}
			else {
				extractAttachments(_call);
			}
			try
			{
				return ((java.lang.Boolean) _resp).booleanValue();
			}
			catch (java.lang.Exception _exception)
			{
				return ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_resp, boolean.class)).booleanValue();
			}
		}
		catch (org.apache.axis.AxisFault axisFaultException)
		{
			if (axisFaultException.detail != null) {
				if (axisFaultException.detail instanceof java.rmi.RemoteException)
					throw (java.rmi.RemoteException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException)
					throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
			}
			throw axisFaultException;
		}
	}

	public void setPassword(byte[] cookie, java.lang.String password)
			throws java.rmi.RemoteException
	{
		if (super.cachedEndpoint == null)
			throw new org.apache.axis.NoEndPointException();

		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[1]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("setPassword");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "setPassword"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try
		{
			java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, password});

			if (_resp instanceof java.rmi.RemoteException)
				throw (java.rmi.RemoteException)_resp;

			extractAttachments(_call);
		}
		catch (org.apache.axis.AxisFault axisFaultException)
		{
			if (axisFaultException.detail != null) {
				if (axisFaultException.detail instanceof java.rmi.RemoteException)
					throw (java.rmi.RemoteException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException)
					throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException)
					throw (com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException) axisFaultException.detail;
			}
			throw axisFaultException;
		}
	}

	public java.lang.String addZone(byte[] cookie, java.lang.String name, java.lang.String description)
			throws java.rmi.RemoteException
	{
		if (super.cachedEndpoint == null)
			throw new org.apache.axis.NoEndPointException();

		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[2]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("addZone");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "addZone"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try
		{
			java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, name, description});

			if (_resp instanceof java.rmi.RemoteException)
				throw (java.rmi.RemoteException)_resp;
			else
			{
				extractAttachments(_call);
				try
				{
					return (java.lang.String) _resp;
				}
				catch (java.lang.Exception _exception)
				{
					return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
				}
			}
  		}
		catch (org.apache.axis.AxisFault axisFaultException)
		{
			if (axisFaultException.detail != null)
			{
				if (axisFaultException.detail instanceof java.rmi.RemoteException)
					throw (java.rmi.RemoteException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException)
					throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException)
					throw (com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException) axisFaultException.detail;
			}
			throw axisFaultException;
		}
	}

	public java.lang.String addNode(byte[] cookie,
									java.lang.String hostName,
									int port,
									int minRangePort,
									int maxRangePort,
									int controlPort,
									int nbDataConnections,
									java.lang.String dmzZone)
			throws java.rmi.RemoteException
	{
		if (super.cachedEndpoint == null)
			throw new org.apache.axis.NoEndPointException();

		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[3]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("addNode");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "addNode"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try
		{
			java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie,
																		hostName,
																		java.lang.Integer.valueOf(port),
																		java.lang.Integer.valueOf(minRangePort),
																		java.lang.Integer.valueOf(maxRangePort),
																		java.lang.Integer.valueOf(controlPort),
																		java.lang.Integer.valueOf(nbDataConnections),
																		dmzZone});

			if (_resp instanceof java.rmi.RemoteException)
				throw (java.rmi.RemoteException)_resp;
			else
			{
				extractAttachments(_call);
				try
				{
					return (java.lang.String) _resp;
				}
				catch (java.lang.Exception _exception)
				{
					return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
				}
			}
		}
		catch (org.apache.axis.AxisFault axisFaultException)
		{
			if (axisFaultException.detail != null)
			{
				if (axisFaultException.detail instanceof java.rmi.RemoteException)
					throw (java.rmi.RemoteException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException)
					throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException)
					throw (com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException) axisFaultException.detail;
			}
			throw axisFaultException;
		}
	}

	public void removeZone(byte[] cookie, java.lang.String zoneName)
			throws java.rmi.RemoteException
	{
		if (super.cachedEndpoint == null)
			throw new org.apache.axis.NoEndPointException();

		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[4]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("removeZone");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "removeZone"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try
		{
			java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, zoneName});

			if (_resp instanceof java.rmi.RemoteException)
				throw (java.rmi.RemoteException)_resp;

			extractAttachments(_call);
  		}
		catch (org.apache.axis.AxisFault axisFaultException)
		{
			if (axisFaultException.detail != null)
			{
				if (axisFaultException.detail instanceof java.rmi.RemoteException)
					throw (java.rmi.RemoteException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException)
					throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException)
					throw (com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException) axisFaultException.detail;
			}
			throw axisFaultException;
		}
	}

	public void removeNode(byte[] cookie, java.lang.String hostName)
			throws java.rmi.RemoteException
	{
		if (super.cachedEndpoint == null)
			throw new org.apache.axis.NoEndPointException();

		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[5]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("removeNode");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "removeNode"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try
		{
			java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, hostName});

			if (_resp instanceof java.rmi.RemoteException)
				throw (java.rmi.RemoteException)_resp;

			extractAttachments(_call);
		}
		catch (org.apache.axis.AxisFault axisFaultException)
		{
			if (axisFaultException.detail != null)
			{
				if (axisFaultException.detail instanceof java.rmi.RemoteException)
					throw (java.rmi.RemoteException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException)
					throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException)
					throw (com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException) axisFaultException.detail;
			}
			throw axisFaultException;
		}
	}

	public java.lang.String[] getZoneNames(byte[] cookie)
			throws java.rmi.RemoteException
	{
		if (super.cachedEndpoint == null)
			throw new org.apache.axis.NoEndPointException();

		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[6]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getZoneNames");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "getZoneNames"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try
		{
			java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie});

			if (_resp instanceof java.rmi.RemoteException)
				throw (java.rmi.RemoteException)_resp;
			else {
				extractAttachments(_call);
				try
				{
					return (java.lang.String[]) _resp;
				}
				catch (java.lang.Exception _exception)
				{
					return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
				}
			}
		}
		catch (org.apache.axis.AxisFault axisFaultException)
		{
			if (axisFaultException.detail != null)
			{
				if (axisFaultException.detail instanceof java.rmi.RemoteException)
					throw (java.rmi.RemoteException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException)
					throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
			}
			throw axisFaultException;
		}
	}

	public com.cyclonecommerce.cyclone.services.DMZNodeService.ConfiguredDmzNode[] getConfiguredDmzNodes(byte[] cookie)
			throws java.rmi.RemoteException
	{
		if (super.cachedEndpoint == null)
			throw new org.apache.axis.NoEndPointException();

		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[7]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getConfiguredDmzNodes");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "getConfiguredDmzNodes"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try
		{
			java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie});

			if (_resp instanceof java.rmi.RemoteException)
				throw (java.rmi.RemoteException)_resp;
			else
			{
				extractAttachments(_call);
				try
				{
					return (com.cyclonecommerce.cyclone.services.DMZNodeService.ConfiguredDmzNode[]) _resp;
				}
				catch (java.lang.Exception _exception)
				{
					return (com.cyclonecommerce.cyclone.services.DMZNodeService.ConfiguredDmzNode[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.cyclonecommerce.cyclone.services.DMZNodeService.ConfiguredDmzNode[].class);
				}
			}
		}
		catch (org.apache.axis.AxisFault axisFaultException)
		{
			if (axisFaultException.detail != null)
			{
				if (axisFaultException.detail instanceof java.rmi.RemoteException)
					throw (java.rmi.RemoteException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException)
					throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
			}
			throw axisFaultException;
		}
	}

	public com.cyclonecommerce.cyclone.services.DMZNodeService.Status getDmzNodeStatus(byte[] cookie, java.lang.String hostName)
			throws java.rmi.RemoteException
	{
		if (super.cachedEndpoint == null)
			throw new org.apache.axis.NoEndPointException();

		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[8]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("getDmzNodeStatus");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "getDmzNodeStatus"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try
		{
			java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, hostName});

			if (_resp instanceof java.rmi.RemoteException)
				throw (java.rmi.RemoteException)_resp;
			else
			{
				extractAttachments(_call);
				try
				{
					return (com.cyclonecommerce.cyclone.services.DMZNodeService.Status) _resp;
				}
				catch (java.lang.Exception _exception)
				{
					return (com.cyclonecommerce.cyclone.services.DMZNodeService.Status) org.apache.axis.utils.JavaUtils.convert(_resp, com.cyclonecommerce.cyclone.services.DMZNodeService.Status.class);
				}
			}
		}
		catch (org.apache.axis.AxisFault axisFaultException)
		{
			if (axisFaultException.detail != null)
			{
				if (axisFaultException.detail instanceof java.rmi.RemoteException)
					throw (java.rmi.RemoteException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException)
					throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
			}
			throw axisFaultException;
		}
	}
	public java.lang.String exportAgent(byte[] cookie, java.lang.String hostName)
			throws java.rmi.RemoteException
	{
		if (super.cachedEndpoint == null)
			throw new org.apache.axis.NoEndPointException();

		org.apache.axis.client.Call _call = createCall();
		_call.setOperation(_operations[9]);
		_call.setUseSOAPAction(true);
		_call.setSOAPActionURI("exportAgent");
		_call.setEncodingStyle(null);
		_call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
		_call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
		_call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
		_call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/DmzNodeService", "exportAgent"));

		setRequestHeaders(_call);
		setAttachments(_call);
		try
		{
			java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, hostName});

			if (_resp instanceof java.rmi.RemoteException)
				throw (java.rmi.RemoteException)_resp;
			else
			{
				extractAttachments(_call);
				try
				{
					return (java.lang.String) _resp;
				}
				catch (java.lang.Exception _exception)
				{
					return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
				}
			}
		}
		catch (org.apache.axis.AxisFault axisFaultException)
		{
			if (axisFaultException.detail != null)
			{
				if (axisFaultException.detail instanceof java.rmi.RemoteException)
					throw (java.rmi.RemoteException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException)
					throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
				if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException)
					throw (com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceException) axisFaultException.detail;
			}
			throw axisFaultException;
		}
	}
}
