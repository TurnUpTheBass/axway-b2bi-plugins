// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

/**
 * DmzNodeService_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */
package com.cyclonecommerce.cyclone.services.DMZNodeService;

public interface DmzNodeService_PortType extends java.rmi.Remote
{
	public boolean keyExists(byte[] cookie) throws java.rmi.RemoteException;

	public void setPassword(byte[] cookie, java.lang.String password)
			throws java.rmi.RemoteException;

	public java.lang.String addZone(byte[] cookie,
									java.lang.String name,
									java.lang.String description)
			throws java.rmi.RemoteException;

	public java.lang.String addNode(byte[] cookie,
									java.lang.String hostName,
									int port,
									int minRangePort,
									int maxRangePort,
									int controlPort,
									int nbDataConnections,
									java.lang.String dmzZone)
			throws java.rmi.RemoteException;

	public void removeZone(byte[] cookie, java.lang.String zoneName) throws java.rmi.RemoteException;

	public void removeNode(byte[] cookie, java.lang.String hostName) throws java.rmi.RemoteException;

	public java.lang.String[] getZoneNames(byte[] cookie) throws java.rmi.RemoteException;

	public com.cyclonecommerce.cyclone.services.DMZNodeService.ConfiguredDmzNode[] getConfiguredDmzNodes(byte[] cookie)
			throws java.rmi.RemoteException;

	public com.cyclonecommerce.cyclone.services.DMZNodeService.Status getDmzNodeStatus(byte[] cookie,
																java.lang.String hostName)
			throws java.rmi.RemoteException;

	public java.lang.String exportAgent(byte[] cookie, java.lang.String hostName)
			throws java.rmi.RemoteException;
}
