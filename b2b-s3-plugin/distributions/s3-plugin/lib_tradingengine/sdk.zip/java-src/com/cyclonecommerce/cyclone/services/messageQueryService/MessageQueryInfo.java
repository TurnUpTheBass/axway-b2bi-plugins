/**
 * MessageQueryInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageQueryService;


/**
 * Criteria to use when querying for Interchange messages. One or
 *                         more criteria values can be specified. The
 * criteria that are specified get
 *                         ANDed together to determine which Interchange
 * messages to return.
 */
public class MessageQueryInfo  implements java.io.Serializable {
    /** mime-type of Interchange messages to return. Null to
 *                                 return Interchange Messages of any
 * type. */
    private java.lang.String contentMimeType;
    /** Interchange message coreId of Interchange message to
 *                                 return. Null to return Interchange
 * Messages with any
 *                             coreId. */
    private java.lang.String coreId;
    /** Indicates date range of Interchange Messages that are in
 *                                 the Delivered Message State. Null
 * to return Interchange Messages
 *                                 with any Delivered date. */
    private com.cyclonecommerce.cyclone.services.messageQueryService.DateRange deliveredDate;
    /** Document class of Interchange messages to return. Null to
 *                                 return Interchange Messages of any
 * Document class. */
    private java.lang.String documentClass;
    /** Document Id of the Interchange messages to return. Null
 *                                 to return Interchange Messages with
 * any Document Id. */
    private java.lang.String documentId;
    /** mime-type of Interchange messages to exclude. Null to not
 *                                 exlude any mime-types. */
    private java.lang.String excludeContentMimeType;
    /** MessageType of Interchange messages to exclude - 0 =
 *                                 REQUEST Message, 1 = RECEIPT Message.
 * -1 or null to not exclude any
 *                                 mime-types. */
    private java.lang.Integer excludeMessageType;
    /** Message direction of messages to return - 0 = INBOUND, 1
 *                                 = OUTBOUND, 2 = INTERNAL, 3 = EXTERNAL */
    private java.lang.Integer messageDirection;
    /** Business Protocol Message Id of Interchange messages to
 *                                 return. Null to return Interchange
 * messages with any Business
 *                                 Protocol Message Id. */
    private java.lang.String messageId;
    /** Status of Interchange messages to return - IN_PROCESS =
 *                                 0, FAILED = 1, DELIVERED = 2, DELIVERED_NEGATIVE_RESPONSE
 * = 3,
 *                                 WAITING_FOR_ACK = 4, RESUBMITTED =
 * 5, RESUBMITTING = 6, IGNORED = 7,
 *                                 ALL_EXCEPT_IGNORED = 8 */
    private java.lang.Integer messageStatusType;
    /** MessageType of Interchange messages to return - 0 =
 *                                 REQUEST Message, 1 = RECEIPT Message.
 * -1 or null to return
 *                                 Interchange messages of any type. */
    private java.lang.Integer messageType;
    /** Interchange message metadata attribute to match. Null to
 *                                 not require matcing of any metadata
 * attributes. */
    private com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute metaDataAttribute;
    /** Origination date range of Interchange messages to return.
 *                                 Null to return Interchanges messages
 * with any Origination date
 *                                 range. */
    private com.cyclonecommerce.cyclone.services.messageQueryService.DateRange originationDate;
    /** List of receiver party names of Interchange messages to
 *                                 return. Null to return Interchange
 * messages with any receiver party
 *                                 name. */
    private java.lang.String[] receiverPartyNames;
    /** List of receiver party RoutingIds of Interchange messages
 *                                 to return. Null to return Interchange
 * messages with any receiver
 *                                 party RoutingIds. */
    private java.lang.String[] receiverRoutingIds;
    /** refToCoreId of Interchange messages to return. Null to
 *                                 return Interchange messages with any
 * refToCoreId. */
    private java.lang.String refToCoreId;
    /** List of sender party names of Interchange messages to
 *                                 return. Null to return Interchange
 * messages with any sender party
 *                                 name. */
    private java.lang.String[] senderPartyNames;
    /** List of sender party RoutingIds of Interchange messages
 *                                 to return. Null to return Interchange
 * messages with any sender party
 *                                 RoutingIds. */
    private java.lang.String[] senderRoutingIds;
    /** Specifies sort order of returned Interchange messages.
 *                                 Null to use the default order. */
    private com.cyclonecommerce.cyclone.services.messageQueryService.SortOptions sortOption;
    /** Transition date range of Interchange messages to return.
 *                                 Null to return Interchanges messages
 * with any Transition date range.
 *                                 The transition date is the date of
 * the transition into the
 *                                 Interchange message current state.
 * The type of the current state
 *                                 does not matter. */
    private com.cyclonecommerce.cyclone.services.messageQueryService.DateRange transitionDate;

    public MessageQueryInfo() {
    }

    public MessageQueryInfo(
           java.lang.String contentMimeType,
           java.lang.String coreId,
           com.cyclonecommerce.cyclone.services.messageQueryService.DateRange deliveredDate,
           java.lang.String documentClass,
           java.lang.String documentId,
           java.lang.String excludeContentMimeType,
           java.lang.Integer excludeMessageType,
           java.lang.Integer messageDirection,
           java.lang.String messageId,
           java.lang.Integer messageStatusType,
           java.lang.Integer messageType,
           com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute metaDataAttribute,
           com.cyclonecommerce.cyclone.services.messageQueryService.DateRange originationDate,
           java.lang.String[] receiverPartyNames,
           java.lang.String[] receiverRoutingIds,
           java.lang.String refToCoreId,
           java.lang.String[] senderPartyNames,
           java.lang.String[] senderRoutingIds,
           com.cyclonecommerce.cyclone.services.messageQueryService.SortOptions sortOption,
           com.cyclonecommerce.cyclone.services.messageQueryService.DateRange transitionDate) {
           this.contentMimeType = contentMimeType;
           this.coreId = coreId;
           this.deliveredDate = deliveredDate;
           this.documentClass = documentClass;
           this.documentId = documentId;
           this.excludeContentMimeType = excludeContentMimeType;
           this.excludeMessageType = excludeMessageType;
           this.messageDirection = messageDirection;
           this.messageId = messageId;
           this.messageStatusType = messageStatusType;
           this.messageType = messageType;
           this.metaDataAttribute = metaDataAttribute;
           this.originationDate = originationDate;
           this.receiverPartyNames = receiverPartyNames;
           this.receiverRoutingIds = receiverRoutingIds;
           this.refToCoreId = refToCoreId;
           this.senderPartyNames = senderPartyNames;
           this.senderRoutingIds = senderRoutingIds;
           this.sortOption = sortOption;
           this.transitionDate = transitionDate;
    }


    /**
     * Gets the contentMimeType value for this MessageQueryInfo.
     *
     * @return contentMimeType mime-type of Interchange messages to return. Null to
 *                                 return Interchange Messages of any
 * type.
     */
    public java.lang.String getContentMimeType() {
        return contentMimeType;
    }


    /**
     * Sets the contentMimeType value for this MessageQueryInfo.
     *
     * @param contentMimeType mime-type of Interchange messages to return. Null to
 *                                 return Interchange Messages of any
 * type.
     */
    public void setContentMimeType(java.lang.String contentMimeType) {
        this.contentMimeType = contentMimeType;
    }


    /**
     * Gets the coreId value for this MessageQueryInfo.
     *
     * @return coreId Interchange message coreId of Interchange message to
 *                                 return. Null to return Interchange
 * Messages with any
 *                             coreId.
     */
    public java.lang.String getCoreId() {
        return coreId;
    }


    /**
     * Sets the coreId value for this MessageQueryInfo.
     *
     * @param coreId Interchange message coreId of Interchange message to
 *                                 return. Null to return Interchange
 * Messages with any
 *                             coreId.
     */
    public void setCoreId(java.lang.String coreId) {
        this.coreId = coreId;
    }


    /**
     * Gets the deliveredDate value for this MessageQueryInfo.
     *
     * @return deliveredDate Indicates date range of Interchange Messages that are in
 *                                 the Delivered Message State. Null
 * to return Interchange Messages
 *                                 with any Delivered date.
     */
    public com.cyclonecommerce.cyclone.services.messageQueryService.DateRange getDeliveredDate() {
        return deliveredDate;
    }


    /**
     * Sets the deliveredDate value for this MessageQueryInfo.
     *
     * @param deliveredDate Indicates date range of Interchange Messages that are in
 *                                 the Delivered Message State. Null
 * to return Interchange Messages
 *                                 with any Delivered date.
     */
    public void setDeliveredDate(com.cyclonecommerce.cyclone.services.messageQueryService.DateRange deliveredDate) {
        this.deliveredDate = deliveredDate;
    }


    /**
     * Gets the documentClass value for this MessageQueryInfo.
     *
     * @return documentClass Document class of Interchange messages to return. Null to
 *                                 return Interchange Messages of any
 * Document class.
     */
    public java.lang.String getDocumentClass() {
        return documentClass;
    }


    /**
     * Sets the documentClass value for this MessageQueryInfo.
     *
     * @param documentClass Document class of Interchange messages to return. Null to
 *                                 return Interchange Messages of any
 * Document class.
     */
    public void setDocumentClass(java.lang.String documentClass) {
        this.documentClass = documentClass;
    }


    /**
     * Gets the documentId value for this MessageQueryInfo.
     *
     * @return documentId Document Id of the Interchange messages to return. Null
 *                                 to return Interchange Messages with
 * any Document Id.
     */
    public java.lang.String getDocumentId() {
        return documentId;
    }


    /**
     * Sets the documentId value for this MessageQueryInfo.
     *
     * @param documentId Document Id of the Interchange messages to return. Null
 *                                 to return Interchange Messages with
 * any Document Id.
     */
    public void setDocumentId(java.lang.String documentId) {
        this.documentId = documentId;
    }


    /**
     * Gets the excludeContentMimeType value for this MessageQueryInfo.
     *
     * @return excludeContentMimeType mime-type of Interchange messages to exclude. Null to not
 *                                 exlude any mime-types.
     */
    public java.lang.String getExcludeContentMimeType() {
        return excludeContentMimeType;
    }


    /**
     * Sets the excludeContentMimeType value for this MessageQueryInfo.
     *
     * @param excludeContentMimeType mime-type of Interchange messages to exclude. Null to not
 *                                 exlude any mime-types.
     */
    public void setExcludeContentMimeType(java.lang.String excludeContentMimeType) {
        this.excludeContentMimeType = excludeContentMimeType;
    }


    /**
     * Gets the excludeMessageType value for this MessageQueryInfo.
     *
     * @return excludeMessageType MessageType of Interchange messages to exclude - 0 =
 *                                 REQUEST Message, 1 = RECEIPT Message.
 * -1 or null to not exclude any
 *                                 mime-types.
     */
    public java.lang.Integer getExcludeMessageType() {
        return excludeMessageType;
    }


    /**
     * Sets the excludeMessageType value for this MessageQueryInfo.
     *
     * @param excludeMessageType MessageType of Interchange messages to exclude - 0 =
 *                                 REQUEST Message, 1 = RECEIPT Message.
 * -1 or null to not exclude any
 *                                 mime-types.
     */
    public void setExcludeMessageType(java.lang.Integer excludeMessageType) {
        this.excludeMessageType = excludeMessageType;
    }


    /**
     * Gets the messageDirection value for this MessageQueryInfo.
     *
     * @return messageDirection Message direction of messages to return - 0 = INBOUND, 1
 *                                 = OUTBOUND, 2 = INTERNAL, 3 = EXTERNAL
     */
    public java.lang.Integer getMessageDirection() {
        return messageDirection;
    }


    /**
     * Sets the messageDirection value for this MessageQueryInfo.
     *
     * @param messageDirection Message direction of messages to return - 0 = INBOUND, 1
 *                                 = OUTBOUND, 2 = INTERNAL, 3 = EXTERNAL
     */
    public void setMessageDirection(java.lang.Integer messageDirection) {
        this.messageDirection = messageDirection;
    }


    /**
     * Gets the messageId value for this MessageQueryInfo.
     *
     * @return messageId Business Protocol Message Id of Interchange messages to
 *                                 return. Null to return Interchange
 * messages with any Business
 *                                 Protocol Message Id.
     */
    public java.lang.String getMessageId() {
        return messageId;
    }


    /**
     * Sets the messageId value for this MessageQueryInfo.
     *
     * @param messageId Business Protocol Message Id of Interchange messages to
 *                                 return. Null to return Interchange
 * messages with any Business
 *                                 Protocol Message Id.
     */
    public void setMessageId(java.lang.String messageId) {
        this.messageId = messageId;
    }


    /**
     * Gets the messageStatusType value for this MessageQueryInfo.
     *
     * @return messageStatusType Status of Interchange messages to return - IN_PROCESS =
 *                                 0, FAILED = 1, DELIVERED = 2, DELIVERED_NEGATIVE_RESPONSE
 * = 3,
 *                                 WAITING_FOR_ACK = 4, RESUBMITTED =
 * 5, RESUBMITTING = 6, IGNORED = 7,
 *                                 ALL_EXCEPT_IGNORED = 8
     */
    public java.lang.Integer getMessageStatusType() {
        return messageStatusType;
    }


    /**
     * Sets the messageStatusType value for this MessageQueryInfo.
     *
     * @param messageStatusType Status of Interchange messages to return - IN_PROCESS =
 *                                 0, FAILED = 1, DELIVERED = 2, DELIVERED_NEGATIVE_RESPONSE
 * = 3,
 *                                 WAITING_FOR_ACK = 4, RESUBMITTED =
 * 5, RESUBMITTING = 6, IGNORED = 7,
 *                                 ALL_EXCEPT_IGNORED = 8
     */
    public void setMessageStatusType(java.lang.Integer messageStatusType) {
        this.messageStatusType = messageStatusType;
    }


    /**
     * Gets the messageType value for this MessageQueryInfo.
     *
     * @return messageType MessageType of Interchange messages to return - 0 =
 *                                 REQUEST Message, 1 = RECEIPT Message.
 * -1 or null to return
 *                                 Interchange messages of any type.
     */
    public java.lang.Integer getMessageType() {
        return messageType;
    }


    /**
     * Sets the messageType value for this MessageQueryInfo.
     *
     * @param messageType MessageType of Interchange messages to return - 0 =
 *                                 REQUEST Message, 1 = RECEIPT Message.
 * -1 or null to return
 *                                 Interchange messages of any type.
     */
    public void setMessageType(java.lang.Integer messageType) {
        this.messageType = messageType;
    }


    /**
     * Gets the metaDataAttribute value for this MessageQueryInfo.
     *
     * @return metaDataAttribute Interchange message metadata attribute to match. Null to
 *                                 not require matcing of any metadata
 * attributes.
     */
    public com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute getMetaDataAttribute() {
        return metaDataAttribute;
    }


    /**
     * Sets the metaDataAttribute value for this MessageQueryInfo.
     *
     * @param metaDataAttribute Interchange message metadata attribute to match. Null to
 *                                 not require matcing of any metadata
 * attributes.
     */
    public void setMetaDataAttribute(com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute metaDataAttribute) {
        this.metaDataAttribute = metaDataAttribute;
    }


    /**
     * Gets the originationDate value for this MessageQueryInfo.
     *
     * @return originationDate Origination date range of Interchange messages to return.
 *                                 Null to return Interchanges messages
 * with any Origination date
 *                                 range.
     */
    public com.cyclonecommerce.cyclone.services.messageQueryService.DateRange getOriginationDate() {
        return originationDate;
    }


    /**
     * Sets the originationDate value for this MessageQueryInfo.
     *
     * @param originationDate Origination date range of Interchange messages to return.
 *                                 Null to return Interchanges messages
 * with any Origination date
 *                                 range.
     */
    public void setOriginationDate(com.cyclonecommerce.cyclone.services.messageQueryService.DateRange originationDate) {
        this.originationDate = originationDate;
    }


    /**
     * Gets the receiverPartyNames value for this MessageQueryInfo.
     *
     * @return receiverPartyNames List of receiver party names of Interchange messages to
 *                                 return. Null to return Interchange
 * messages with any receiver party
 *                                 name.
     */
    public java.lang.String[] getReceiverPartyNames() {
        return receiverPartyNames;
    }


    /**
     * Sets the receiverPartyNames value for this MessageQueryInfo.
     *
     * @param receiverPartyNames List of receiver party names of Interchange messages to
 *                                 return. Null to return Interchange
 * messages with any receiver party
 *                                 name.
     */
    public void setReceiverPartyNames(java.lang.String[] receiverPartyNames) {
        this.receiverPartyNames = receiverPartyNames;
    }


    /**
     * Gets the receiverRoutingIds value for this MessageQueryInfo.
     *
     * @return receiverRoutingIds List of receiver party RoutingIds of Interchange messages
 *                                 to return. Null to return Interchange
 * messages with any receiver
 *                                 party RoutingIds.
     */
    public java.lang.String[] getReceiverRoutingIds() {
        return receiverRoutingIds;
    }


    /**
     * Sets the receiverRoutingIds value for this MessageQueryInfo.
     *
     * @param receiverRoutingIds List of receiver party RoutingIds of Interchange messages
 *                                 to return. Null to return Interchange
 * messages with any receiver
 *                                 party RoutingIds.
     */
    public void setReceiverRoutingIds(java.lang.String[] receiverRoutingIds) {
        this.receiverRoutingIds = receiverRoutingIds;
    }


    /**
     * Gets the refToCoreId value for this MessageQueryInfo.
     *
     * @return refToCoreId refToCoreId of Interchange messages to return. Null to
 *                                 return Interchange messages with any
 * refToCoreId.
     */
    public java.lang.String getRefToCoreId() {
        return refToCoreId;
    }


    /**
     * Sets the refToCoreId value for this MessageQueryInfo.
     *
     * @param refToCoreId refToCoreId of Interchange messages to return. Null to
 *                                 return Interchange messages with any
 * refToCoreId.
     */
    public void setRefToCoreId(java.lang.String refToCoreId) {
        this.refToCoreId = refToCoreId;
    }


    /**
     * Gets the senderPartyNames value for this MessageQueryInfo.
     *
     * @return senderPartyNames List of sender party names of Interchange messages to
 *                                 return. Null to return Interchange
 * messages with any sender party
 *                                 name.
     */
    public java.lang.String[] getSenderPartyNames() {
        return senderPartyNames;
    }


    /**
     * Sets the senderPartyNames value for this MessageQueryInfo.
     *
     * @param senderPartyNames List of sender party names of Interchange messages to
 *                                 return. Null to return Interchange
 * messages with any sender party
 *                                 name.
     */
    public void setSenderPartyNames(java.lang.String[] senderPartyNames) {
        this.senderPartyNames = senderPartyNames;
    }


    /**
     * Gets the senderRoutingIds value for this MessageQueryInfo.
     *
     * @return senderRoutingIds List of sender party RoutingIds of Interchange messages
 *                                 to return. Null to return Interchange
 * messages with any sender party
 *                                 RoutingIds.
     */
    public java.lang.String[] getSenderRoutingIds() {
        return senderRoutingIds;
    }


    /**
     * Sets the senderRoutingIds value for this MessageQueryInfo.
     *
     * @param senderRoutingIds List of sender party RoutingIds of Interchange messages
 *                                 to return. Null to return Interchange
 * messages with any sender party
 *                                 RoutingIds.
     */
    public void setSenderRoutingIds(java.lang.String[] senderRoutingIds) {
        this.senderRoutingIds = senderRoutingIds;
    }


    /**
     * Gets the sortOption value for this MessageQueryInfo.
     *
     * @return sortOption Specifies sort order of returned Interchange messages.
 *                                 Null to use the default order.
     */
    public com.cyclonecommerce.cyclone.services.messageQueryService.SortOptions getSortOption() {
        return sortOption;
    }


    /**
     * Sets the sortOption value for this MessageQueryInfo.
     *
     * @param sortOption Specifies sort order of returned Interchange messages.
 *                                 Null to use the default order.
     */
    public void setSortOption(com.cyclonecommerce.cyclone.services.messageQueryService.SortOptions sortOption) {
        this.sortOption = sortOption;
    }


    /**
     * Gets the transitionDate value for this MessageQueryInfo.
     *
     * @return transitionDate Transition date range of Interchange messages to return.
 *                                 Null to return Interchanges messages
 * with any Transition date range.
 *                                 The transition date is the date of
 * the transition into the
 *                                 Interchange message current state.
 * The type of the current state
 *                                 does not matter.
     */
    public com.cyclonecommerce.cyclone.services.messageQueryService.DateRange getTransitionDate() {
        return transitionDate;
    }


    /**
     * Sets the transitionDate value for this MessageQueryInfo.
     *
     * @param transitionDate Transition date range of Interchange messages to return.
 *                                 Null to return Interchanges messages
 * with any Transition date range.
 *                                 The transition date is the date of
 * the transition into the
 *                                 Interchange message current state.
 * The type of the current state
 *                                 does not matter.
     */
    public void setTransitionDate(com.cyclonecommerce.cyclone.services.messageQueryService.DateRange transitionDate) {
        this.transitionDate = transitionDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MessageQueryInfo)) return false;
        MessageQueryInfo other = (MessageQueryInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.contentMimeType==null && other.getContentMimeType()==null) ||
             (this.contentMimeType!=null &&
              this.contentMimeType.equals(other.getContentMimeType()))) &&
            ((this.coreId==null && other.getCoreId()==null) ||
             (this.coreId!=null &&
              this.coreId.equals(other.getCoreId()))) &&
            ((this.deliveredDate==null && other.getDeliveredDate()==null) ||
             (this.deliveredDate!=null &&
              this.deliveredDate.equals(other.getDeliveredDate()))) &&
            ((this.documentClass==null && other.getDocumentClass()==null) ||
             (this.documentClass!=null &&
              this.documentClass.equals(other.getDocumentClass()))) &&
            ((this.documentId==null && other.getDocumentId()==null) ||
             (this.documentId!=null &&
              this.documentId.equals(other.getDocumentId()))) &&
            ((this.excludeContentMimeType==null && other.getExcludeContentMimeType()==null) ||
             (this.excludeContentMimeType!=null &&
              this.excludeContentMimeType.equals(other.getExcludeContentMimeType()))) &&
            ((this.excludeMessageType==null && other.getExcludeMessageType()==null) ||
             (this.excludeMessageType!=null &&
              this.excludeMessageType.equals(other.getExcludeMessageType()))) &&
            ((this.messageDirection==null && other.getMessageDirection()==null) ||
             (this.messageDirection!=null &&
              this.messageDirection.equals(other.getMessageDirection()))) &&
            ((this.messageId==null && other.getMessageId()==null) ||
             (this.messageId!=null &&
              this.messageId.equals(other.getMessageId()))) &&
            ((this.messageStatusType==null && other.getMessageStatusType()==null) ||
             (this.messageStatusType!=null &&
              this.messageStatusType.equals(other.getMessageStatusType()))) &&
            ((this.messageType==null && other.getMessageType()==null) ||
             (this.messageType!=null &&
              this.messageType.equals(other.getMessageType()))) &&
            ((this.metaDataAttribute==null && other.getMetaDataAttribute()==null) ||
             (this.metaDataAttribute!=null &&
              this.metaDataAttribute.equals(other.getMetaDataAttribute()))) &&
            ((this.originationDate==null && other.getOriginationDate()==null) ||
             (this.originationDate!=null &&
              this.originationDate.equals(other.getOriginationDate()))) &&
            ((this.receiverPartyNames==null && other.getReceiverPartyNames()==null) ||
             (this.receiverPartyNames!=null &&
              java.util.Arrays.equals(this.receiverPartyNames, other.getReceiverPartyNames()))) &&
            ((this.receiverRoutingIds ==null && other.getReceiverRoutingIds()==null) ||
             (this.receiverRoutingIds !=null &&
              java.util.Arrays.equals(this.receiverRoutingIds, other.getReceiverRoutingIds()))) &&
            ((this.refToCoreId==null && other.getRefToCoreId()==null) ||
             (this.refToCoreId!=null &&
              this.refToCoreId.equals(other.getRefToCoreId()))) &&
            ((this.senderPartyNames==null && other.getSenderPartyNames()==null) ||
             (this.senderPartyNames!=null &&
              java.util.Arrays.equals(this.senderPartyNames, other.getSenderPartyNames()))) &&
            ((this.senderRoutingIds==null && other.getSenderRoutingIds()==null) ||
             (this.senderRoutingIds!=null &&
              java.util.Arrays.equals(this.senderRoutingIds, other.getSenderRoutingIds()))) &&
            ((this.sortOption==null && other.getSortOption()==null) ||
             (this.sortOption!=null &&
              this.sortOption.equals(other.getSortOption()))) &&
            ((this.transitionDate==null && other.getTransitionDate()==null) ||
             (this.transitionDate!=null &&
              this.transitionDate.equals(other.getTransitionDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getContentMimeType() != null) {
            _hashCode += getContentMimeType().hashCode();
        }
        if (getCoreId() != null) {
            _hashCode += getCoreId().hashCode();
        }
        if (getDeliveredDate() != null) {
            _hashCode += getDeliveredDate().hashCode();
        }
        if (getDocumentClass() != null) {
            _hashCode += getDocumentClass().hashCode();
        }
        if (getDocumentId() != null) {
            _hashCode += getDocumentId().hashCode();
        }
        if (getExcludeContentMimeType() != null) {
            _hashCode += getExcludeContentMimeType().hashCode();
        }
        if (getExcludeMessageType() != null) {
            _hashCode += getExcludeMessageType().hashCode();
        }
        if (getMessageDirection() != null) {
            _hashCode += getMessageDirection().hashCode();
        }
        if (getMessageId() != null) {
            _hashCode += getMessageId().hashCode();
        }
        if (getMessageStatusType() != null) {
            _hashCode += getMessageStatusType().hashCode();
        }
        if (getMessageType() != null) {
            _hashCode += getMessageType().hashCode();
        }
        if (getMetaDataAttribute() != null) {
            _hashCode += getMetaDataAttribute().hashCode();
        }
        if (getOriginationDate() != null) {
            _hashCode += getOriginationDate().hashCode();
        }
        if (getReceiverPartyNames() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getReceiverPartyNames());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getReceiverPartyNames(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getReceiverRoutingIds() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getReceiverRoutingIds());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getReceiverRoutingIds(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRefToCoreId() != null) {
            _hashCode += getRefToCoreId().hashCode();
        }
        if (getSenderPartyNames() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSenderPartyNames());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSenderPartyNames(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSenderRoutingIds() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSenderRoutingIds());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSenderRoutingIds(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSortOption() != null) {
            _hashCode += getSortOption().hashCode();
        }
        if (getTransitionDate() != null) {
            _hashCode += getTransitionDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MessageQueryInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MessageQueryInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contentMimeType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "contentMimeType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("coreId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "coreId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deliveredDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "deliveredDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "DateRange"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentClass");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "documentClass"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "documentId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("excludeContentMimeType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "excludeContentMimeType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("excludeMessageType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "excludeMessageType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageDirection");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "messageDirection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "messageId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageStatusType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "messageStatusType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "messageType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metaDataAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "metaDataAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MetadataAttribute"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("originationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "originationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "DateRange"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receiverPartyNames");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "receiverPartyNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receiverRoutingIds");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "receiverRoutingIds"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refToCoreId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "refToCoreId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senderPartyNames");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "senderPartyNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senderRoutingIds");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "senderRoutingIds"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sortOption");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "sortOption"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "SortOptions"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transitionDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "transitionDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "DateRange"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
