/**
 * MessageQueryRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageQueryService;

public class MessageQueryRequest  implements java.io.Serializable {
    /** Page number to return Interchange messages
 *                             from. */
    private int fromPage;
    /** Maximum number of Interchange messages to
 *                             return. */
    private int maxResults;
    /** Query criteria. */
    private com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryInfo queryInfo;

    public MessageQueryRequest() {
    }

    public MessageQueryRequest(
           int fromPage,
           int maxResults,
           com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryInfo queryInfo) {
           this.fromPage = fromPage;
           this.maxResults = maxResults;
           this.queryInfo = queryInfo;
    }


    /**
     * Gets the fromPage value for this MessageQueryRequest.
     * 
     * @return fromPage Page number to return Interchange messages
 *                             from.
     */
    public int getFromPage() {
        return fromPage;
    }


    /**
     * Sets the fromPage value for this MessageQueryRequest.
     * 
     * @param fromPage Page number to return Interchange messages
 *                             from.
     */
    public void setFromPage(int fromPage) {
        this.fromPage = fromPage;
    }


    /**
     * Gets the maxResults value for this MessageQueryRequest.
     * 
     * @return maxResults Maximum number of Interchange messages to
 *                             return.
     */
    public int getMaxResults() {
        return maxResults;
    }


    /**
     * Sets the maxResults value for this MessageQueryRequest.
     * 
     * @param maxResults Maximum number of Interchange messages to
 *                             return.
     */
    public void setMaxResults(int maxResults) {
        this.maxResults = maxResults;
    }


    /**
     * Gets the queryInfo value for this MessageQueryRequest.
     * 
     * @return queryInfo Query criteria.
     */
    public com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryInfo getQueryInfo() {
        return queryInfo;
    }


    /**
     * Sets the queryInfo value for this MessageQueryRequest.
     * 
     * @param queryInfo Query criteria.
     */
    public void setQueryInfo(com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryInfo queryInfo) {
        this.queryInfo = queryInfo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MessageQueryRequest)) return false;
        MessageQueryRequest other = (MessageQueryRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.fromPage == other.getFromPage() &&
            this.maxResults == other.getMaxResults() &&
            ((this.queryInfo==null && other.getQueryInfo()==null) || 
             (this.queryInfo!=null &&
              this.queryInfo.equals(other.getQueryInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getFromPage();
        _hashCode += getMaxResults();
        if (getQueryInfo() != null) {
            _hashCode += getQueryInfo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MessageQueryRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MessageQueryRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromPage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "fromPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxResults");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "maxResults"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "queryInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MessageQueryInfo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
