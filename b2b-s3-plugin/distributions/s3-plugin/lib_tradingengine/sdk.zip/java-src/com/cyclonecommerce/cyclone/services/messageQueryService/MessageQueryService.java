/**
 * MessageQueryService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageQueryService;

public interface MessageQueryService extends java.rmi.Remote {

    /**
     * Retreive the maximum number of messages that will be returned
     * in a
     *                 single call to get Messages.
     */
    public int getMaxPageSize(byte[] cookie) throws java.rmi.RemoteException, com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException;

    /**
     * Execute query to retreive Interchange Messages.
     */
    public com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryResponse getMessages(byte[] cookie, com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryRequest request) throws java.rmi.RemoteException, com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException, com.cyclonecommerce.cyclone.services.messageQueryService.InvalidQueryException;
}
