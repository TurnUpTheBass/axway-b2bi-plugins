/**
 * MessageQueryServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageQueryService;

public interface MessageQueryServiceService extends javax.xml.rpc.Service {

/**
 * Interchange Webservice for querying Interchange Messages.
 */
    public java.lang.String getMessageQueryServiceAddress();

    public com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryService getMessageQueryService() throws javax.xml.rpc.ServiceException;

    public com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryService getMessageQueryService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
