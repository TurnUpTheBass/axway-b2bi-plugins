/**
 * MessageQueryServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageQueryService;

public class MessageQueryServiceServiceLocator extends org.apache.axis.client.Service implements com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryServiceService {

/**
 * Interchange Webservice for querying Interchange Messages.
 */

    public MessageQueryServiceServiceLocator() {
    }


    public MessageQueryServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public MessageQueryServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for MessageQueryService
    private java.lang.String MessageQueryService_address = "http://localhost:6080/cyclone/services/MessageQueryService";

    public java.lang.String getMessageQueryServiceAddress() {
        return MessageQueryService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String MessageQueryServiceWSDDServiceName = "MessageQueryService";

    public java.lang.String getMessageQueryServiceWSDDServiceName() {
        return MessageQueryServiceWSDDServiceName;
    }

    public void setMessageQueryServiceWSDDServiceName(java.lang.String name) {
        MessageQueryServiceWSDDServiceName = name;
    }

    public com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryService getMessageQueryService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(MessageQueryService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getMessageQueryService(endpoint);
    }

    public com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryService getMessageQueryService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryServiceSoapBindingStub _stub = new com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getMessageQueryServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setMessageQueryServiceEndpointAddress(java.lang.String address) {
        MessageQueryService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryService.class.isAssignableFrom(serviceEndpointInterface)) {
                com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryServiceSoapBindingStub _stub = new com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryServiceSoapBindingStub(new java.net.URL(MessageQueryService_address), this);
                _stub.setPortName(getMessageQueryServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("MessageQueryService".equals(inputPortName)) {
            return getMessageQueryService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MessageQueryServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MessageQueryService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        if ("MessageQueryService".equals(portName)) {
            setMessageQueryServiceEndpointAddress(address);
        }
        else { // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
