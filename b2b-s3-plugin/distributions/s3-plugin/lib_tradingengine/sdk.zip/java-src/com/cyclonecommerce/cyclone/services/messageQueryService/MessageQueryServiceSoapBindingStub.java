/**
 * MessageQueryServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageQueryService;

public class MessageQueryServiceSoapBindingStub extends org.apache.axis.client.Stub implements com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryService {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[2];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getMaxPageSize");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(int.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "getMaxPageSizeReturn"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "fault"),
                      "com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
                      new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/sessionService", "InvalidSessionException"), 
                      true
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getMessages");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "cookie"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MessageQueryRequest"), com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MessageQueryResponse"));
        oper.setReturnClass(com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "getMessagesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "fault"),
                      "com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException",
                      new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/sessionService", "InvalidSessionException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "fault1"),
                      "com.cyclonecommerce.cyclone.services.messageQueryService.InvalidQueryException",
                      new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "InvalidQueryException"), 
                      true
                     ));
        _operations[1] = oper;

    }

    public MessageQueryServiceSoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public MessageQueryServiceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public MessageQueryServiceSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "ArrayOf_xsd_string");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "item");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "ArrayOfMetadataAttribute");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MetadataAttribute");
            qName2 = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "item");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "ArrayOfRemoteMessage");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.RemoteMessage[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "RemoteMessage");
            qName2 = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "item");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "ArrayOfRemoteMessageState");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.RemoteMessageState[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "RemoteMessageState");
            qName2 = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "item");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "DateRange");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.DateRange.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "InvalidQueryException");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.InvalidQueryException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MessageQueryInfo");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MessageQueryRequest");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MessageQueryResponse");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MetadataAttribute");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "RemoteMessage");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.RemoteMessage.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "RemoteMessageState");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.RemoteMessageState.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "SortOptions");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.messageQueryService.SortOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/sessionService", "InvalidSessionException");
            cachedSerQNames.add(qName);
            cls = com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }


    /**
     * Retreive the maximum number of messages that will be returned
     * in a
     *                 single call to get Messages.
     */
    public int getMaxPageSize(byte[] cookie) throws java.rmi.RemoteException, com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("getMaxPageSize");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "getMaxPageSize"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Integer) _resp).intValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, int.class)).intValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) {
              throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }


    /**
     * Execute query to retreive Interchange Messages. getMessages
     * is
     *                 written to support large result sets. To conserve
     * resources, large result sets are
     *                 not returned in whole. The result sets are broken
     * up into pages. Only one page at a
     *                 time will be returned by getMessages. Also note that
     * the the results from a single
     *                 query are not persisted between calls to getMessages.
     * An Interchange message that is
     *                 on page 1 during the first call to getMessages may
     * move to a different page in
     *                 subsequent calls to getMessages (even using the same
     * query criteria).
     */
    public com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryResponse getMessages(byte[] cookie, com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryRequest request) throws java.rmi.RemoteException, com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException, com.cyclonecommerce.cyclone.services.messageQueryService.InvalidQueryException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("getMessages");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "getMessages"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cookie, request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) {
              throw (com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.cyclonecommerce.cyclone.services.messageQueryService.InvalidQueryException) {
              throw (com.cyclonecommerce.cyclone.services.messageQueryService.InvalidQueryException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
