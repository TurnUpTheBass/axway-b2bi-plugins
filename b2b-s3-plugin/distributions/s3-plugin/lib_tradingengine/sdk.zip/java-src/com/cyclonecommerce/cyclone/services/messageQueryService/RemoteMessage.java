/**
 * RemoteMessage.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageQueryService;

public class RemoteMessage  implements java.io.Serializable {
    private boolean child;
    private java.lang.String contentMimeType;
    private java.lang.String coreId;
    private int currentMessageStateIndex;
    private boolean delivered;
    private java.util.Calendar deliveryDate;
    private int direction;
    private java.lang.String documentClass;
    private java.lang.String documentId;
    private boolean duplicate;
    private boolean finalState;
    private boolean ignored;
    private java.lang.String messageId;
    private com.cyclonecommerce.cyclone.services.messageQueryService.RemoteMessageState[] messageStates;
    private int messageType;
    private com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute[] metaDataAttributes;
    private java.util.Calendar originationDate;
    private boolean receipt;
    private java.lang.String receiverPartyId;
    private java.lang.String receiverPartyName;
    private java.lang.String receiverRoutingId;
    private java.lang.String refToCoreId;
    private boolean rejected;
    private java.lang.String senderPartyId;
    private java.lang.String senderPartyName;
    private java.lang.String senderRoutingId;

    public RemoteMessage() {
    }

    public RemoteMessage(
           boolean child,
           java.lang.String contentMimeType,
           java.lang.String coreId,
           int currentMessageStateIndex,
           boolean delivered,
           java.util.Calendar deliveryDate,
           int direction,
           java.lang.String documentClass,
           java.lang.String documentId,
           boolean duplicate,
           boolean finalState,
           boolean ignored,
           java.lang.String messageId,
           com.cyclonecommerce.cyclone.services.messageQueryService.RemoteMessageState[] messageStates,
           int messageType,
           com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute[] metaDataAttributes,
           java.util.Calendar originationDate,
           boolean receipt,
           java.lang.String receiverPartyId,
           java.lang.String receiverPartyName,
           java.lang.String receiverRoutingId,
           java.lang.String refToCoreId,
           boolean rejected,
           java.lang.String senderPartyId,
           java.lang.String senderPartyName,
           java.lang.String senderRoutingId) {
           this.child = child;
           this.contentMimeType = contentMimeType;
           this.coreId = coreId;
           this.currentMessageStateIndex = currentMessageStateIndex;
           this.delivered = delivered;
           this.deliveryDate = deliveryDate;
           this.direction = direction;
           this.documentClass = documentClass;
           this.documentId = documentId;
           this.duplicate = duplicate;
           this.finalState = finalState;
           this.ignored = ignored;
           this.messageId = messageId;
           this.messageStates = messageStates;
           this.messageType = messageType;
           this.metaDataAttributes = metaDataAttributes;
           this.originationDate = originationDate;
           this.receipt = receipt;
           this.receiverPartyId = receiverPartyId;
           this.receiverPartyName = receiverPartyName;
           this.receiverRoutingId = receiverRoutingId;
           this.refToCoreId = refToCoreId;
           this.rejected = rejected;
           this.senderPartyId = senderPartyId;
           this.senderPartyName = senderPartyName;
           this.senderRoutingId = senderRoutingId;
    }


    /**
     * Gets the child value for this RemoteMessage.
     * 
     * @return child
     */
    public boolean isChild() {
        return child;
    }


    /**
     * Sets the child value for this RemoteMessage.
     * 
     * @param child
     */
    public void setChild(boolean child) {
        this.child = child;
    }


    /**
     * Gets the contentMimeType value for this RemoteMessage.
     * 
     * @return contentMimeType
     */
    public java.lang.String getContentMimeType() {
        return contentMimeType;
    }


    /**
     * Sets the contentMimeType value for this RemoteMessage.
     * 
     * @param contentMimeType
     */
    public void setContentMimeType(java.lang.String contentMimeType) {
        this.contentMimeType = contentMimeType;
    }


    /**
     * Gets the coreId value for this RemoteMessage.
     * 
     * @return coreId
     */
    public java.lang.String getCoreId() {
        return coreId;
    }


    /**
     * Sets the coreId value for this RemoteMessage.
     * 
     * @param coreId
     */
    public void setCoreId(java.lang.String coreId) {
        this.coreId = coreId;
    }


    /**
     * Gets the currentMessageStateIndex value for this RemoteMessage.
     * 
     * @return currentMessageStateIndex
     */
    public int getCurrentMessageStateIndex() {
        return currentMessageStateIndex;
    }


    /**
     * Sets the currentMessageStateIndex value for this RemoteMessage.
     * 
     * @param currentMessageStateIndex
     */
    public void setCurrentMessageStateIndex(int currentMessageStateIndex) {
        this.currentMessageStateIndex = currentMessageStateIndex;
    }


    /**
     * Gets the delivered value for this RemoteMessage.
     * 
     * @return delivered
     */
    public boolean isDelivered() {
        return delivered;
    }


    /**
     * Sets the delivered value for this RemoteMessage.
     * 
     * @param delivered
     */
    public void setDelivered(boolean delivered) {
        this.delivered = delivered;
    }


    /**
     * Gets the deliveryDate value for this RemoteMessage.
     * 
     * @return deliveryDate
     */
    public java.util.Calendar getDeliveryDate() {
        return deliveryDate;
    }


    /**
     * Sets the deliveryDate value for this RemoteMessage.
     * 
     * @param deliveryDate
     */
    public void setDeliveryDate(java.util.Calendar deliveryDate) {
        this.deliveryDate = deliveryDate;
    }


    /**
     * Gets the direction value for this RemoteMessage.
     * 
     * @return direction
     */
    public int getDirection() {
        return direction;
    }


    /**
     * Sets the direction value for this RemoteMessage.
     * 
     * @param direction
     */
    public void setDirection(int direction) {
        this.direction = direction;
    }


    /**
     * Gets the documentClass value for this RemoteMessage.
     * 
     * @return documentClass
     */
    public java.lang.String getDocumentClass() {
        return documentClass;
    }


    /**
     * Sets the documentClass value for this RemoteMessage.
     * 
     * @param documentClass
     */
    public void setDocumentClass(java.lang.String documentClass) {
        this.documentClass = documentClass;
    }


    /**
     * Gets the documentId value for this RemoteMessage.
     * 
     * @return documentId
     */
    public java.lang.String getDocumentId() {
        return documentId;
    }


    /**
     * Sets the documentId value for this RemoteMessage.
     * 
     * @param documentId
     */
    public void setDocumentId(java.lang.String documentId) {
        this.documentId = documentId;
    }


    /**
     * Gets the duplicate value for this RemoteMessage.
     * 
     * @return duplicate
     */
    public boolean isDuplicate() {
        return duplicate;
    }


    /**
     * Sets the duplicate value for this RemoteMessage.
     * 
     * @param duplicate
     */
    public void setDuplicate(boolean duplicate) {
        this.duplicate = duplicate;
    }


    /**
     * Gets the finalState value for this RemoteMessage.
     * 
     * @return finalState
     */
    public boolean isFinalState() {
        return finalState;
    }


    /**
     * Sets the finalState value for this RemoteMessage.
     * 
     * @param finalState
     */
    public void setFinalState(boolean finalState) {
        this.finalState = finalState;
    }


    /**
     * Gets the ignored value for this RemoteMessage.
     * 
     * @return ignored
     */
    public boolean isIgnored() {
        return ignored;
    }


    /**
     * Sets the ignored value for this RemoteMessage.
     * 
     * @param ignored
     */
    public void setIgnored(boolean ignored) {
        this.ignored = ignored;
    }


    /**
     * Gets the messageId value for this RemoteMessage.
     * 
     * @return messageId
     */
    public java.lang.String getMessageId() {
        return messageId;
    }


    /**
     * Sets the messageId value for this RemoteMessage.
     * 
     * @param messageId
     */
    public void setMessageId(java.lang.String messageId) {
        this.messageId = messageId;
    }


    /**
     * Gets the messageStates value for this RemoteMessage.
     * 
     * @return messageStates
     */
    public com.cyclonecommerce.cyclone.services.messageQueryService.RemoteMessageState[] getMessageStates() {
        return messageStates;
    }


    /**
     * Sets the messageStates value for this RemoteMessage.
     * 
     * @param messageStates
     */
    public void setMessageStates(com.cyclonecommerce.cyclone.services.messageQueryService.RemoteMessageState[] messageStates) {
        this.messageStates = messageStates;
    }


    /**
     * Gets the messageType value for this RemoteMessage.
     * 
     * @return messageType
     */
    public int getMessageType() {
        return messageType;
    }


    /**
     * Sets the messageType value for this RemoteMessage.
     * 
     * @param messageType
     */
    public void setMessageType(int messageType) {
        this.messageType = messageType;
    }


    /**
     * Gets the metaDataAttributes value for this RemoteMessage.
     * 
     * @return metaDataAttributes
     */
    public com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute[] getMetaDataAttributes() {
        return metaDataAttributes;
    }


    /**
     * Sets the metaDataAttributes value for this RemoteMessage.
     * 
     * @param metaDataAttributes
     */
    public void setMetaDataAttributes(com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute[] metaDataAttributes) {
        this.metaDataAttributes = metaDataAttributes;
    }


    /**
     * Gets the originationDate value for this RemoteMessage.
     * 
     * @return originationDate
     */
    public java.util.Calendar getOriginationDate() {
        return originationDate;
    }


    /**
     * Sets the originationDate value for this RemoteMessage.
     * 
     * @param originationDate
     */
    public void setOriginationDate(java.util.Calendar originationDate) {
        this.originationDate = originationDate;
    }


    /**
     * Gets the receipt value for this RemoteMessage.
     * 
     * @return receipt
     */
    public boolean isReceipt() {
        return receipt;
    }


    /**
     * Sets the receipt value for this RemoteMessage.
     * 
     * @param receipt
     */
    public void setReceipt(boolean receipt) {
        this.receipt = receipt;
    }


    /**
     * Gets the receiverPartyId value for this RemoteMessage.
     * 
     * @return receiverPartyId
     */
    public java.lang.String getReceiverPartyId() {
        return receiverPartyId;
    }


    /**
     * Sets the receiverPartyId value for this RemoteMessage.
     * 
     * @param receiverPartyId
     */
    public void setReceiverPartyId(java.lang.String receiverPartyId) {
        this.receiverPartyId = receiverPartyId;
    }


    /**
     * Gets the receiverPartyName value for this RemoteMessage.
     * 
     * @return receiverPartyName
     */
    public java.lang.String getReceiverPartyName() {
        return receiverPartyName;
    }


    /**
     * Sets the receiverPartyName value for this RemoteMessage.
     * 
     * @param receiverPartyName
     */
    public void setReceiverPartyName(java.lang.String receiverPartyName) {
        this.receiverPartyName = receiverPartyName;
    }


    /**
     * Gets the receiverRoutingId value for this RemoteMessage.
     * 
     * @return receiverRoutingId
     */
    public java.lang.String getReceiverRoutingId() {
        return receiverRoutingId;
    }


    /**
     * Sets the receiverRoutingId value for this RemoteMessage.
     * 
     * @param receiverRoutingId
     */
    public void setReceiverRoutingId(java.lang.String receiverRoutingId) {
        this.receiverRoutingId = receiverRoutingId;
    }


    /**
     * Gets the refToCoreId value for this RemoteMessage.
     * 
     * @return refToCoreId
     */
    public java.lang.String getRefToCoreId() {
        return refToCoreId;
    }


    /**
     * Sets the refToCoreId value for this RemoteMessage.
     * 
     * @param refToCoreId
     */
    public void setRefToCoreId(java.lang.String refToCoreId) {
        this.refToCoreId = refToCoreId;
    }


    /**
     * Gets the rejected value for this RemoteMessage.
     * 
     * @return rejected
     */
    public boolean isRejected() {
        return rejected;
    }


    /**
     * Sets the rejected value for this RemoteMessage.
     * 
     * @param rejected
     */
    public void setRejected(boolean rejected) {
        this.rejected = rejected;
    }


    /**
     * Gets the senderPartyId value for this RemoteMessage.
     * 
     * @return senderPartyId
     */
    public java.lang.String getSenderPartyId() {
        return senderPartyId;
    }


    /**
     * Sets the senderPartyId value for this RemoteMessage.
     * 
     * @param senderPartyId
     */
    public void setSenderPartyId(java.lang.String senderPartyId) {
        this.senderPartyId = senderPartyId;
    }


    /**
     * Gets the senderPartyName value for this RemoteMessage.
     * 
     * @return senderPartyName
     */
    public java.lang.String getSenderPartyName() {
        return senderPartyName;
    }


    /**
     * Sets the senderPartyName value for this RemoteMessage.
     * 
     * @param senderPartyName
     */
    public void setSenderPartyName(java.lang.String senderPartyName) {
        this.senderPartyName = senderPartyName;
    }


    /**
     * Gets the senderRoutingId value for this RemoteMessage.
     * 
     * @return senderRoutingId
     */
    public java.lang.String getSenderRoutingId() {
        return senderRoutingId;
    }


    /**
     * Sets the senderRoutingId value for this RemoteMessage.
     * 
     * @param senderRoutingId
     */
    public void setSenderRoutingId(java.lang.String senderRoutingId) {
        this.senderRoutingId = senderRoutingId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RemoteMessage)) return false;
        RemoteMessage other = (RemoteMessage) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.child == other.isChild() &&
            ((this.contentMimeType==null && other.getContentMimeType()==null) || 
             (this.contentMimeType!=null &&
              this.contentMimeType.equals(other.getContentMimeType()))) &&
            ((this.coreId==null && other.getCoreId()==null) || 
             (this.coreId!=null &&
              this.coreId.equals(other.getCoreId()))) &&
            this.currentMessageStateIndex == other.getCurrentMessageStateIndex() &&
            this.delivered == other.isDelivered() &&
            ((this.deliveryDate==null && other.getDeliveryDate()==null) || 
             (this.deliveryDate!=null &&
              this.deliveryDate.equals(other.getDeliveryDate()))) &&
            this.direction == other.getDirection() &&
            ((this.documentClass==null && other.getDocumentClass()==null) || 
             (this.documentClass!=null &&
              this.documentClass.equals(other.getDocumentClass()))) &&
            ((this.documentId==null && other.getDocumentId()==null) || 
             (this.documentId!=null &&
              this.documentId.equals(other.getDocumentId()))) &&
            this.duplicate == other.isDuplicate() &&
            this.finalState == other.isFinalState() &&
            this.ignored == other.isIgnored() &&
            ((this.messageId==null && other.getMessageId()==null) || 
             (this.messageId!=null &&
              this.messageId.equals(other.getMessageId()))) &&
            ((this.messageStates==null && other.getMessageStates()==null) || 
             (this.messageStates!=null &&
              java.util.Arrays.equals(this.messageStates, other.getMessageStates()))) &&
            this.messageType == other.getMessageType() &&
            ((this.metaDataAttributes==null && other.getMetaDataAttributes()==null) || 
             (this.metaDataAttributes!=null &&
              java.util.Arrays.equals(this.metaDataAttributes, other.getMetaDataAttributes()))) &&
            ((this.originationDate==null && other.getOriginationDate()==null) || 
             (this.originationDate!=null &&
              this.originationDate.equals(other.getOriginationDate()))) &&
            this.receipt == other.isReceipt() &&
            ((this.receiverPartyId==null && other.getReceiverPartyId()==null) || 
             (this.receiverPartyId!=null &&
              this.receiverPartyId.equals(other.getReceiverPartyId()))) &&
            ((this.receiverPartyName==null && other.getReceiverPartyName()==null) || 
             (this.receiverPartyName!=null &&
              this.receiverPartyName.equals(other.getReceiverPartyName()))) &&
            ((this.receiverRoutingId==null && other.getReceiverRoutingId()==null) || 
             (this.receiverRoutingId!=null &&
              this.receiverRoutingId.equals(other.getReceiverRoutingId()))) &&
            ((this.refToCoreId==null && other.getRefToCoreId()==null) || 
             (this.refToCoreId!=null &&
              this.refToCoreId.equals(other.getRefToCoreId()))) &&
            this.rejected == other.isRejected() &&
            ((this.senderPartyId==null && other.getSenderPartyId()==null) || 
             (this.senderPartyId!=null &&
              this.senderPartyId.equals(other.getSenderPartyId()))) &&
            ((this.senderPartyName==null && other.getSenderPartyName()==null) || 
             (this.senderPartyName!=null &&
              this.senderPartyName.equals(other.getSenderPartyName()))) &&
            ((this.senderRoutingId==null && other.getSenderRoutingId()==null) || 
             (this.senderRoutingId!=null &&
              this.senderRoutingId.equals(other.getSenderRoutingId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isChild() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getContentMimeType() != null) {
            _hashCode += getContentMimeType().hashCode();
        }
        if (getCoreId() != null) {
            _hashCode += getCoreId().hashCode();
        }
        _hashCode += getCurrentMessageStateIndex();
        _hashCode += (isDelivered() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getDeliveryDate() != null) {
            _hashCode += getDeliveryDate().hashCode();
        }
        _hashCode += getDirection();
        if (getDocumentClass() != null) {
            _hashCode += getDocumentClass().hashCode();
        }
        if (getDocumentId() != null) {
            _hashCode += getDocumentId().hashCode();
        }
        _hashCode += (isDuplicate() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isFinalState() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIgnored() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getMessageId() != null) {
            _hashCode += getMessageId().hashCode();
        }
        if (getMessageStates() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMessageStates());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMessageStates(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getMessageType();
        if (getMetaDataAttributes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMetaDataAttributes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMetaDataAttributes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOriginationDate() != null) {
            _hashCode += getOriginationDate().hashCode();
        }
        _hashCode += (isReceipt() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getReceiverPartyId() != null) {
            _hashCode += getReceiverPartyId().hashCode();
        }
        if (getReceiverPartyName() != null) {
            _hashCode += getReceiverPartyName().hashCode();
        }
        if (getReceiverRoutingId() != null) {
            _hashCode += getReceiverRoutingId().hashCode();
        }
        if (getRefToCoreId() != null) {
            _hashCode += getRefToCoreId().hashCode();
        }
        _hashCode += (isRejected() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getSenderPartyId() != null) {
            _hashCode += getSenderPartyId().hashCode();
        }
        if (getSenderPartyName() != null) {
            _hashCode += getSenderPartyName().hashCode();
        }
        if (getSenderRoutingId() != null) {
            _hashCode += getSenderRoutingId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RemoteMessage.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "RemoteMessage"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("child");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "child"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contentMimeType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "contentMimeType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("coreId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "coreId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentMessageStateIndex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "currentMessageStateIndex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("delivered");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "delivered"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deliveryDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "deliveryDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("direction");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "direction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentClass");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "documentClass"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "documentId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "duplicate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("finalState");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "finalState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ignored");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "ignored"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "messageId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageStates");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "messageStates"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "RemoteMessageState"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "messageType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metaDataAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "metaDataAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "MetadataAttribute"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("originationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "originationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receipt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "receipt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receiverPartyId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "receiverPartyId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receiverPartyName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "receiverPartyName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receiverRoutingId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "receiverRoutingId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refToCoreId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "refToCoreId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rejected");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "rejected"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senderPartyId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "senderPartyId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senderPartyName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "senderPartyName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senderRoutingId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "senderRoutingId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
