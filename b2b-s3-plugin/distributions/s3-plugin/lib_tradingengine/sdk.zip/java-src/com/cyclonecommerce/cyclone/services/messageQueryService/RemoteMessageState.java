/**
 * RemoteMessageState.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageQueryService;

public class RemoteMessageState  implements java.io.Serializable {
    private java.lang.String backupFilename;
    private long contentSize;
    private java.lang.String exchangePointUrl;
    private java.lang.String messageCoreId;
    private java.lang.String name;
    private java.util.Calendar transitionTime;

    public RemoteMessageState() {
    }

    public RemoteMessageState(
           java.lang.String backupFilename,
           long contentSize,
           java.lang.String exchangePointUrl,
           java.lang.String messageCoreId,
           java.lang.String name,
           java.util.Calendar transitionTime) {
           this.backupFilename = backupFilename;
           this.contentSize = contentSize;
           this.exchangePointUrl = exchangePointUrl;
           this.messageCoreId = messageCoreId;
           this.name = name;
           this.transitionTime = transitionTime;
    }


    /**
     * Gets the backupFilename value for this RemoteMessageState.
     * 
     * @return backupFilename
     */
    public java.lang.String getBackupFilename() {
        return backupFilename;
    }


    /**
     * Sets the backupFilename value for this RemoteMessageState.
     * 
     * @param backupFilename
     */
    public void setBackupFilename(java.lang.String backupFilename) {
        this.backupFilename = backupFilename;
    }


    /**
     * Gets the contentSize value for this RemoteMessageState.
     * 
     * @return contentSize
     */
    public long getContentSize() {
        return contentSize;
    }


    /**
     * Sets the contentSize value for this RemoteMessageState.
     * 
     * @param contentSize
     */
    public void setContentSize(long contentSize) {
        this.contentSize = contentSize;
    }


    /**
     * Gets the exchangePointUrl value for this RemoteMessageState.
     * 
     * @return exchangePointUrl
     */
    public java.lang.String getExchangePointUrl() {
        return exchangePointUrl;
    }


    /**
     * Sets the exchangePointUrl value for this RemoteMessageState.
     * 
     * @param exchangePointUrl
     */
    public void setExchangePointUrl(java.lang.String exchangePointUrl) {
        this.exchangePointUrl = exchangePointUrl;
    }


    /**
     * Gets the messageCoreId value for this RemoteMessageState.
     * 
     * @return messageCoreId
     */
    public java.lang.String getMessageCoreId() {
        return messageCoreId;
    }


    /**
     * Sets the messageCoreId value for this RemoteMessageState.
     * 
     * @param messageCoreId
     */
    public void setMessageCoreId(java.lang.String messageCoreId) {
        this.messageCoreId = messageCoreId;
    }


    /**
     * Gets the name value for this RemoteMessageState.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this RemoteMessageState.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the transitionTime value for this RemoteMessageState.
     * 
     * @return transitionTime
     */
    public java.util.Calendar getTransitionTime() {
        return transitionTime;
    }


    /**
     * Sets the transitionTime value for this RemoteMessageState.
     * 
     * @param transitionTime
     */
    public void setTransitionTime(java.util.Calendar transitionTime) {
        this.transitionTime = transitionTime;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RemoteMessageState)) return false;
        RemoteMessageState other = (RemoteMessageState) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.backupFilename==null && other.getBackupFilename()==null) || 
             (this.backupFilename!=null &&
              this.backupFilename.equals(other.getBackupFilename()))) &&
            this.contentSize == other.getContentSize() &&
            ((this.exchangePointUrl==null && other.getExchangePointUrl()==null) || 
             (this.exchangePointUrl!=null &&
              this.exchangePointUrl.equals(other.getExchangePointUrl()))) &&
            ((this.messageCoreId==null && other.getMessageCoreId()==null) || 
             (this.messageCoreId!=null &&
              this.messageCoreId.equals(other.getMessageCoreId()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.transitionTime==null && other.getTransitionTime()==null) || 
             (this.transitionTime!=null &&
              this.transitionTime.equals(other.getTransitionTime())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBackupFilename() != null) {
            _hashCode += getBackupFilename().hashCode();
        }
        _hashCode += new Long(getContentSize()).hashCode();
        if (getExchangePointUrl() != null) {
            _hashCode += getExchangePointUrl().hashCode();
        }
        if (getMessageCoreId() != null) {
            _hashCode += getMessageCoreId().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getTransitionTime() != null) {
            _hashCode += getTransitionTime().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RemoteMessageState.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "RemoteMessageState"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("backupFilename");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "backupFilename"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contentSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "contentSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exchangePointUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "exchangePointUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageCoreId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "messageCoreId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transitionTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "transitionTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
