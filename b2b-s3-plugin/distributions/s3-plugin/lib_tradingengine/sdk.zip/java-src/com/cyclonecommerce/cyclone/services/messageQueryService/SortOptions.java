/**
 * SortOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageQueryService;

public class SortOptions  implements java.io.Serializable {
    private boolean ascendingOrder;
    /** Sort order of the returned messages -
 *                                 SORT_DELIVERED_DATE = 0, SORT_ORIGINATION_DATE
 * = 1,
 *                                 SORT_PROCESSING_STATUS = 2, SORT_DOCUMENT_ID
 * = 3. */
    private int sortOption;

    public SortOptions() {
    }

    public SortOptions(
           boolean ascendingOrder,
           int sortOption) {
           this.ascendingOrder = ascendingOrder;
           this.sortOption = sortOption;
    }


    /**
     * Gets the ascendingOrder value for this SortOptions.
     * 
     * @return ascendingOrder
     */
    public boolean isAscendingOrder() {
        return ascendingOrder;
    }


    /**
     * Sets the ascendingOrder value for this SortOptions.
     * 
     * @param ascendingOrder
     */
    public void setAscendingOrder(boolean ascendingOrder) {
        this.ascendingOrder = ascendingOrder;
    }


    /**
     * Gets the sortOption value for this SortOptions.
     * 
     * @return sortOption Sort order of the returned messages -
 *                                 SORT_DELIVERED_DATE = 0, SORT_ORIGINATION_DATE
 * = 1,
 *                                 SORT_PROCESSING_STATUS = 2, SORT_DOCUMENT_ID
 * = 3.
     */
    public int getSortOption() {
        return sortOption;
    }


    /**
     * Sets the sortOption value for this SortOptions.
     * 
     * @param sortOption Sort order of the returned messages -
 *                                 SORT_DELIVERED_DATE = 0, SORT_ORIGINATION_DATE
 * = 1,
 *                                 SORT_PROCESSING_STATUS = 2, SORT_DOCUMENT_ID
 * = 3.
     */
    public void setSortOption(int sortOption) {
        this.sortOption = sortOption;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SortOptions)) return false;
        SortOptions other = (SortOptions) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.ascendingOrder == other.isAscendingOrder() &&
            this.sortOption == other.getSortOption();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isAscendingOrder() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getSortOption();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SortOptions.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "SortOptions"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ascendingOrder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "ascendingOrder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sortOption");
        elemField.setXmlName(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/messageQueryService", "sortOption"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
