/**
 * MessageResubmitService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageResubmitService;

public interface MessageResubmitService extends java.rmi.Remote {

    /**
     * Resubmit a single Interchange message to the Trading Engine.
     */
    public void resubmitMessage(byte[] cookie, java.lang.String coreId) throws java.rmi.RemoteException, com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException, com.cyclonecommerce.cyclone.services.messageResubmitService.CannotResubmitMessageException;

    /**
     * Resubmit a list of Interchange messages to the Trading Engine.
     */
    public void resubmitMultipleMessages(byte[] cookie, java.lang.String[] coreIds) throws java.rmi.RemoteException, com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException, com.cyclonecommerce.cyclone.services.messageResubmitService.CannotResubmitMessageException;
}
