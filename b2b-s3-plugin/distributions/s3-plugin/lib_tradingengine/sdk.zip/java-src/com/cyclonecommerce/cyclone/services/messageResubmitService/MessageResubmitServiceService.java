/**
 * MessageResubmitServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.messageResubmitService;

public interface MessageResubmitServiceService extends javax.xml.rpc.Service {

/**
 * Interchange Webservice for resubmitting Trading Engine Messages
 * for
 *          reprocessing. See the Interchange User's Guide for resubmittal
 * limitations.
 */
    public java.lang.String getMessageResubmitServiceAddress();

    public com.cyclonecommerce.cyclone.services.messageResubmitService.MessageResubmitService getMessageResubmitService() throws javax.xml.rpc.ServiceException;

    public com.cyclonecommerce.cyclone.services.messageResubmitService.MessageResubmitService getMessageResubmitService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
