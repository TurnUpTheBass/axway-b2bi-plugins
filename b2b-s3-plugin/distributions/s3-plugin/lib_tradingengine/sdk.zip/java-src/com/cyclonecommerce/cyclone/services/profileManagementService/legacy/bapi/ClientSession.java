// Copyright Axway Software. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi;

import com.axway.defence.validation.FilterRule;
import com.axway.defence.validation.RegexConstant;
import com.axway.defence.validation.StringFilter;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.serializers.ClientSessionDeserializerFactory;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.serializers.ClientSessionSerializerFactory;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;

import org.apache.axis.AxisFault;
import org.apache.axis.NoEndPointException;
import org.apache.axis.client.Call;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.description.ParameterDesc;
import org.apache.axis.utils.JavaUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.xml.namespace.QName;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.Map;

public class ClientSession extends ClientStub
{
    private static final Logger logger = LogManager.getLogger(ClientSession.class);

    static org.apache.axis.description.OperationDesc[] operations;
	// use axway defence to validate URL's
	private static final FilterRule URLFilterRule =  new FilterRule(RegexConstant.SequenceLibrary.URL);
	private static final StringFilter urlFilter = new StringFilter(URLFilterRule);

	static
    {
        operations = new OperationDesc[2];
        initOperationDesc();
    }

    private static void initOperationDesc()
    {
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("createSession");
        param = new org.apache.axis.description.ParameterDesc(new QName("", "authenicationType"), ParameterDesc.IN, new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new QName("", "authenticationData"), ParameterDesc.IN, new QName("http://xml.apache.org/xml-soap", "Map"), Map.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new QName("", "serverUrl"), ParameterDesc.IN, new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://beans.bapi.legacy4x.webservices.framework.collaboration.cyclonecommerce.com", "ClientSession"));
        oper.setReturnClass(ClientSession.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "createSessionReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("closeSession");
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        operations[1] = oper;
    }

    /**
     * Creates a session on the IDK SOAP server.
     *
     * @param authenticationType A string that identifies the name of the authenticator that
     *                           should authenticate this request.
     * @param authenticationData Information from the client the authenticator needs to identify the client.
     * @param serverURL          The URL of the IDK SOAP server where the session should be
     *                           created.
     * @return A client session that represents the session on the server.
     *         //@throws AuthenticationException Thrown when the client is not authorized to create a session.
     */
    public static ClientSession createSession(String authenticationType, Map authenticationData, URL serverURL)
            throws AuthenticationException
    {
        ClientSession createdSession;
        try
        {
            createdSession = createSession(serverURL, authenticationType, authenticationData);
        }
        catch (RemoteException e)
        {
            logger.error("Unexpected RemoteException during creation of session.", e);
            throw new AuthenticationException(e.getMessage(), e);
        }

        return createdSession;
    }


    private String serverURL = null;
    private String sessionCookie = null;

    public ClientSession(String serverURL, String sessionCookie)
    {
        this();
        this.serverURL = serverURL;
        this.sessionCookie = sessionCookie;
    }

    private ClientSession()
    {
        super();
    }

    public String getServerURL()
    {
        return serverURL;
    }

    public String getSessionCookie()
    {
        return sessionCookie;
    }

    protected Class[] getBeanClasses()
    {
        return new Class[0];
    }

    public void close()
    {
        try
        {
            closeSession();
        }
        catch (RemoteException e)
        {
            logger.error("Unexpected RemoteException during close of session: " + sessionCookie + ".", e);
        }
    }

    protected void closeSession()
            throws RemoteException
    {

        Call call = createCallEx(this);
        call.setTargetEndpointAddress(serverURL);
        call.setOperation(operations[1]);
        call.setOperationName(new javax.xml.namespace.QName("urn:cyclonecommerce.SerssionService", "closeSession"));

        try
        {
            java.lang.Object resp = call.invoke(new java.lang.Object[]{});
            if (resp instanceof RemoteException)
            {
                throw (RemoteException) resp;
            }
            extractAttachments(call);
        }
        catch (AxisFault e)
        {
            throw e;
        }
        }

    protected static ClientSession createSession(URL serverURL, String authenicationType, Map authenticationData)
            throws RemoteException
    {
        if (serverURL == null)
        {
            throw new NoEndPointException();
        }


		Call call = createCall();

		call.setTargetEndpointAddress(serverURL);
        call.setOperation(operations[0]);
        call.setOperationName(new QName("urn:cyclonecommerce.SessionService", "createSession", "urn"));

        QName qname = new QName("http://beans.bapi.legacy4x.webservices.framework.collaboration.cyclonecommerce.com", "ClientSession");
        call.registerTypeMapping(ClientSession.class, qname, ClientSessionSerializerFactory.class, ClientSessionDeserializerFactory.class, false);

        try
        {
            Object resp = call.invoke(new Object[]{authenicationType, authenticationData, serverURL.toExternalForm()});
            if (resp instanceof RemoteException)
            {
                throw (RemoteException) resp;
            }
            else
            {
                //extractAttachments(call);
                try
                {
                    return (ClientSession) resp;
                }
                catch (Exception ex)
                {
                    return (ClientSession) JavaUtils.convert(resp, ClientSession.class);
                }
            }
        }
        catch (AxisFault e)
        {
            throw e;
        }
    }

}
