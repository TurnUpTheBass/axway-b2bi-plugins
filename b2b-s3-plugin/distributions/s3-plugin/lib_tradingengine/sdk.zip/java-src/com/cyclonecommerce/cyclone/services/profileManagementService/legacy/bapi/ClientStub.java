// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi;

import com.axway.defence.errors.ValidationException;
import com.axway.defence.validation.StringFilter;
import com.axway.defence.validation.FilterRule;
import com.axway.defence.validation.RegexConstant;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.InvalidFormatException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.ServerException;

import org.apache.axis.AxisFault;
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.encoding.ser.BeanDeserializerFactory;
import org.apache.axis.encoding.ser.BeanSerializerFactory;
import org.apache.axis.message.SOAPHeaderElement;
import org.apache.axis.utils.JavaUtils;

import javax.xml.namespace.QName;
import java.rmi.RemoteException;

public abstract class ClientStub
{
 	// use axway defence to validate URL's
	public static final FilterRule URLFilterRule =  new FilterRule(RegexConstant.SequenceLibrary.URL);
	public static final StringFilter urlFilter = new StringFilter(URLFilterRule);

	protected static Call createCall()
            throws RemoteException
    {
        Service service = new Service();
        try
        {
            Call call = (Call) service.createCall();
            call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
            call.setEncodingStyle(org.apache.axis.Constants.URI_SOAP11_ENC);
            call.setUseSOAPAction(true);
            call.setSOAPActionURI("");

			//command-line imports were timing out after 10 minutes,
			call.getMessageContext().setTimeout(36000000);//this raises the timeout to 10 hours.
			//call.setTimeout(36000000);//this has not been tested, but may be desirable if further timeout issues occur

            return call;
        }
        catch (Throwable t)
        {
            throw new AxisFault("Failure trying to get the Call object", t);
        }
    }

    protected Call createCallEx(ClientSession session)
        throws RemoteException
    {
		String serverURL = session.getServerURL();

		Call call = createCall();
		call.setTargetEndpointAddress(serverURL);
        SOAPHeaderElement header = new SOAPHeaderElement("", "IDKSessionCookie", session.getSessionCookie());
        call.addHeader(header);

        Class[] beanClasses = getBeanClasses();
        if (beanClasses != null)
        {
            for (Class beanClass : beanClasses)
            {
                QName qname = new QName("urn:cyclonecommerce.com", beanClass.getSimpleName());
                call.registerTypeMapping(beanClass, qname, BeanSerializerFactory.class, BeanDeserializerFactory.class, false);
            }
        }

        return call;
    }

    protected Object executeWithResponse(ClientSession session, OperationDesc operation, Object param)
        throws RemoteException
    {
        return executeWithResponse(session, operation, new Object[] {param});
    }

    protected Object executeWithResponse(ClientSession session, OperationDesc operation, Object[] params)
        throws RemoteException
    {
        Class responseType = operation.getReturnClass();
        Call call = createCallEx(session);
        call.setOperation(operation);
        call.setOperationName(new javax.xml.namespace.QName("urn:cyclonecommerce.com", operation.getName()));

        setRequestHeaders(call);
        setAttachments(call);
        try
        {
            Object resp = call.invoke(params);
            if (resp instanceof RemoteException)
            {
                throw (RemoteException)resp;
            }
            else
            {
                extractAttachments(call);
                if (resp == null) return null;
                if (responseType.isAssignableFrom(resp.getClass()))
                    return resp;
                else
                    return JavaUtils.convert(resp, responseType);
            }
        }
        catch (AxisFault axisFaultException)
        {
            throw convertFault(axisFaultException);
        }
    }

    protected abstract Class[] getBeanClasses();

    protected void setRequestHeaders(Call call)
    {
        // does nothing
    }

    protected void setAttachments(Call call)
    {
        // does nothing
    }

    protected void extractAttachments(Call call)
    {
        // does nothing
    }

    protected RemoteException convertFault(AxisFault axisFaultException)
    {
        if (axisFaultException.detail != null)
        {
            if (axisFaultException.detail instanceof java.rmi.RemoteException)
            {
                return (java.rmi.RemoteException) axisFaultException.detail;
            }
            if (axisFaultException.detail instanceof ServerException)
            {
                return (ServerException) axisFaultException.detail;
            }
            if (axisFaultException.detail instanceof InvalidFormatException)
            {
                return (InvalidFormatException) axisFaultException.detail;
            }
            if (axisFaultException.detail instanceof AuthenticationException)
            {
                return (AuthenticationException) axisFaultException.detail;
            }
        }
        return axisFaultException;
    }
}
