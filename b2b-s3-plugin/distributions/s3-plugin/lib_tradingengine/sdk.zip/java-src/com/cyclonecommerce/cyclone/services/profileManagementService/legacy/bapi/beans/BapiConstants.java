// Copyright (c) 1996-2011 Axway All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans;

import org.dom4j.Namespace;
import org.dom4j.QName;

public interface BapiConstants
{
    public static final String URL_BAPI = "http://www.cyclonecommerce.com/Schemas/2001/07/bapi";
    public static final String URL_XSI = "http://www.w3.org/2001/XMLSchema-instance";

    public static final String DISPOSITION = "Disposition";

    public static final String ID_ATT = "id";
    public static final String TITLE_ATT = "title";

    public static final String ORGANIZATION_ID_LIST = "OrganizationIdList";
    public static final String ORGANIZATION_ID = "OrganizationId";

    public static final String CURSOR = "Cursor";

    public static final Namespace NS_BAPI = Namespace.get("bapi", URL_BAPI);
    public static final Namespace NS_XSI = Namespace.get("xsi", URL_XSI);

    public static final QName QN_CURSOR = new QName(CURSOR, NS_BAPI);
    public static final QName QN_DISPOSITION = new QName(DISPOSITION, NS_BAPI);
}
