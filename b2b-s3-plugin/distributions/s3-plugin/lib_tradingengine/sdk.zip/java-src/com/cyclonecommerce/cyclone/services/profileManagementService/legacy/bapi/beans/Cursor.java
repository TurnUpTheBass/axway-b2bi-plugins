// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.io.Serializable;

public class Cursor
        implements Serializable
{
    private String value;

    public Cursor()
    {
        super();
    }

    public Cursor(Element elem)
    {
        setValue(elem.getText());
    }

    public String getValue()
    {
        return value;
    }

    public void setValue(String value)
    {
        this.value = value;
    }

    public Element toElement()
    {
        Element root = DocumentHelper.createElement(BapiConstants.QN_CURSOR);
        if (value != null)
            root.setText(value);
        return root;
    }
}
