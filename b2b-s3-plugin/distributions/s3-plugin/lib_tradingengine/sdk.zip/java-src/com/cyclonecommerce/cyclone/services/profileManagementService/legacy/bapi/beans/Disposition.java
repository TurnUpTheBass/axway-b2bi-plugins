// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.io.Serializable;
import java.util.List;

public class Disposition
        implements Serializable
{
	private static final long serialVersionUID = 42L;

    private String id;
    private String title;
    private transient org.w3c.dom.Element messageDetails;

    public Disposition()
    {
        super();
    }

    public Disposition(Element root)
    {
        setId(root.attributeValue(BapiConstants.ID_ATT));
        setTitle(root.attributeValue(BapiConstants.TITLE_ATT));
        List children = root.elements();
        if (!children.isEmpty())
        {
            Element messageDetailsElem = (Element) children.get(0);
            setMessageDetails(ElementUtil.toDomElement(messageDetailsElem));
        }
    }

    public Disposition(String id, String title)
    {
        this.id = id;
        this.title = title;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public org.w3c.dom.Element getMessageDetails()
    {
        return messageDetails;
    }

    public void setMessageDetails(org.w3c.dom.Element messageDetails)
    {
        this.messageDetails = messageDetails;
    }

    public Element toElement()
    {
        Element root = DocumentHelper.createElement(BapiConstants.QN_DISPOSITION);
        if (id != null)
            root.addAttribute(BapiConstants.ID_ATT, id);
        if (title != null)
            root.addAttribute(BapiConstants.TITLE_ATT, title);
        if (messageDetails != null)
            root.add(ElementUtil.toDom4JElement(messageDetails));
        return root;
    }

    public Disposition copy()
    {
        Disposition copy = new Disposition(getId(), getTitle());
        copy.setMessageDetails(getMessageDetails());
        return copy;
    }
}
