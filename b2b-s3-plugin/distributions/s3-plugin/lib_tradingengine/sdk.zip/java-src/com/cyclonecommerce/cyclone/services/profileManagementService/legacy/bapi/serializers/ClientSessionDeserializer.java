// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.serializers;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;

import com.axway.defence.validation.FilterRule;
import com.axway.defence.validation.RegexConstant;
import com.axway.defence.validation.StringFilter;
import com.axway.defence.errors.ValidationException;

import org.apache.axis.Constants;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.DeserializerImpl;
import org.apache.axis.message.SOAPEnvelope;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.namespace.QName;
import java.util.Hashtable;

public class ClientSessionDeserializer extends DeserializerImpl
{
    public static final String SESSION_COOKIE = "SessionCookie";
    public static final String SERVER_URL = "ServerURL";
    public static final QName myTypeQName = new QName("typeNS", "ClientSession");

	// use axway defence to validate URL's
	public static final FilterRule URLFilterRule =  new FilterRule(RegexConstant.SequenceLibrary.URL);
	public static final StringFilter urlFilter = new StringFilter(URLFilterRule);

    @SuppressWarnings({"MismatchedQueryAndUpdateOfCollection"})
    private Hashtable<String, javax.xml.namespace.QName>  typesByMemberName = new Hashtable<String, javax.xml.namespace.QName>();

    public ClientSessionDeserializer()
    {
        typesByMemberName.put(SESSION_COOKIE, Constants.XSD_STRING);
        typesByMemberName.put(SERVER_URL, Constants.XSD_STRING);
    }

    public void onEndElement(String namespace, String localName, DeserializationContext context)
            throws SAXException
    {
        Element cookieElem = getElement(context.getEnvelope(), SESSION_COOKIE);
        if (cookieElem == null)
            throw new SAXException("Invalid: Missing " + SESSION_COOKIE + " element.");

        Element urlElem = getElement(context.getEnvelope(), SERVER_URL);
        if (urlElem == null)
            throw new SAXException("Invalid: Missing " + SERVER_URL + " element.");

        String cookie = getElementText(cookieElem);
        String url = getElementText(urlElem);

		// validate the URL before creating new ClientSession

        setValue(new ClientSession(url, cookie));
    }

    private Element getElement(SOAPEnvelope envelope, String name)
    {
        NodeList nl = envelope.getElementsByTagName(name);
        if (nl == null || nl.getLength() == 0)
            return null;
        return (Element) nl.item(0);
    }

    private String getElementText(Element elem)
    {
        Node node = elem.getFirstChild();
        if (node == null)
            return null;
        return node.getNodeValue();
    }
}
