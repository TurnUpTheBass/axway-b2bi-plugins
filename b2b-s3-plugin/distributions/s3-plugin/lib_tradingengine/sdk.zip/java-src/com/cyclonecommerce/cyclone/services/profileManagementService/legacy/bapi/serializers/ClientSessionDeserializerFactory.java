// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.serializers;

import org.apache.axis.Constants;
import org.apache.axis.encoding.DeserializerFactory;

import java.util.Iterator;
import java.util.Vector;

public class ClientSessionDeserializerFactory implements DeserializerFactory
{
    private Vector mechanisms;

    public ClientSessionDeserializerFactory()
    {
    }

    public javax.xml.rpc.encoding.Deserializer getDeserializerAs(String mechanismType)
    {
        return new ClientSessionDeserializer();
    }

    public Iterator getSupportedMechanismTypes()
    {
        if (mechanisms == null)
        {
            mechanisms = new Vector();
            //noinspection unchecked
            mechanisms.add(Constants.AXIS_SAX);
        }
        return mechanisms.iterator();
    }
}
