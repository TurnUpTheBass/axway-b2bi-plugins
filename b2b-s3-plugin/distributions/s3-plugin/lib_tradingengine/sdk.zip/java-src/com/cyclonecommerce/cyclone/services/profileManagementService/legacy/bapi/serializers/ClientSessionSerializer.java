// Copyright (c) 1996-2010 Axway All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.serializers;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;

import org.apache.axis.Constants;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.encoding.Serializer;
import org.apache.axis.wsdl.fromJava.Types;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;

import javax.xml.namespace.QName;
import java.io.IOException;

public class ClientSessionSerializer implements Serializer
{
    public void serialize(QName name, Attributes attributes,
                          Object value, SerializationContext context)
            throws IOException
    {
        if (!(value instanceof ClientSession))
            throw new IOException("Can't serialize a " + value.getClass().getName() + " with a DataSerializer.");
        ClientSession cs = (ClientSession) value;

        context.startElement(name, attributes);
        context.writeString("<SessionCookie xsi:type=\"xsd:string\">");
        context.writeString(cs.getSessionCookie());
        context.writeString("</SessionCookie>");
        context.writeString("<ServerURL xsi:type=\"xsd:string\">");
        context.writeString(cs.getServerURL());
        context.writeString("</ServerURL>");
        context.endElement();
    }

    public String getMechanismType()
    {
        return Constants.AXIS_SAX;
    }

    public Element writeSchema(Class javaType, Types types) throws Exception
    {
		Element complexType = types.createElement("complexType");
		complexType.setAttribute("name", "ClientSession");
		Element complexContent = types.createElement("complexContent");
		complexType.appendChild(complexContent);
		Element sequence = types.createElement("sequence");
		complexContent.appendChild(sequence);
		Element sessionCookie = types.createElement("element");
		sessionCookie.setAttribute("name", "SessionCookie");
		sessionCookie.setAttribute("type", "xsd:string");
		sessionCookie.setAttribute("nillable", "false");
		sequence.appendChild(sessionCookie);
		Element serverUrl = types.createElement("element");
		serverUrl.setAttribute("name", "ServerURL");
		serverUrl.setAttribute("type", "xsd:string");
		serverUrl.setAttribute("nillable", "false");
		sequence.appendChild(serverUrl);
		return complexType;
	}
}
