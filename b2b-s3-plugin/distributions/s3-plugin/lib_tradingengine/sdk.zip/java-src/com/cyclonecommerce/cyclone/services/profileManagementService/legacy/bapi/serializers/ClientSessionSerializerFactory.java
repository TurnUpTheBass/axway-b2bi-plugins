// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.serializers;

import org.apache.axis.Constants;
import org.apache.axis.encoding.SerializerFactory;

import java.util.Iterator;
import java.util.Vector;

public class ClientSessionSerializerFactory implements SerializerFactory
{
    private Vector mechanisms;

    public ClientSessionSerializerFactory()
    {
    }

    public javax.xml.rpc.encoding.Serializer getSerializerAs(String mechanismType)
    {
        return new ClientSessionSerializer();
    }

    public Iterator getSupportedMechanismTypes()
    {
        if (mechanisms == null)
        {
            mechanisms = new Vector();
            //noinspection unchecked
            mechanisms.add(Constants.AXIS_SAX);
        }
        return mechanisms.iterator();
    }
}
