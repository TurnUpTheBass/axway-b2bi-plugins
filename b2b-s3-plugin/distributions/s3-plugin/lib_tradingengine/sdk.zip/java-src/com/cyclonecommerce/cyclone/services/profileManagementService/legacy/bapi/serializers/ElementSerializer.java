// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.serializers;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;

import org.apache.axis.MessageContext;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.utils.Messages;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;

import javax.xml.namespace.QName;
import java.io.IOException;
import java.io.Writer;

/**
 * This class is an override of the default implentation of the AXIS element serializer.  It is necessary
 * because AXIS's version puts namespace prefixes in all the elements it serializes.  This causes problems
 * for 4.x clients which deserialize with the old Apache SOAP deserialier.  In short, this class must
 * be used to serialize elements in SOAP responses.
 */
@edu.umd.cs.findbugs.annotations.SuppressWarnings(value="NM_SAME_SIMPLE_NAME_AS_SUPERCLASS",justification="This class has had this name for too long to change it now.")
public class ElementSerializer extends org.apache.axis.encoding.ser.ElementSerializer
{
    /**
     * Serialize a DOM Element
     */
    public void serialize(QName name, Attributes attributes,
                          Object value, SerializationContext context)
        throws IOException
    {
        if (!(value instanceof Element))
            throw new IOException(Messages.getMessage("cantSerialize01"));

        MessageContext mc = context.getMessageContext();
        context.setWriteXMLType(null);
        boolean writeWrapper = (mc == null) ||
                mc.isPropertyTrue("writeWrapperForElements", true);
        if (writeWrapper)
            context.startElement(name, attributes);

        ElementSerializerWriter writer = new ElementSerializerWriter(context);
        ElementUtil.write((Element)value, writer);
        writer.close();

        if (writeWrapper)
            context.endElement();
    }

    private class ElementSerializerWriter
            extends Writer
    {
        private SerializationContext context;

        public ElementSerializerWriter(SerializationContext context)
        {
            this.context = context;
        }

        public void write(char cbuf[], int off, int len) throws IOException
        {
            // Write the element stuff out as a string
            context.writeString(String.valueOf(cbuf, off, len));
        }

        public void flush() throws IOException
        {
        }

        public void close() throws IOException
        {
        }
    }
}
