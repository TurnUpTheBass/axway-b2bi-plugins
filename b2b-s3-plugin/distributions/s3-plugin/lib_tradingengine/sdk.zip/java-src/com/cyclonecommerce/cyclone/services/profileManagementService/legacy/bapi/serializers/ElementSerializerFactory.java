// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.serializers;

import org.apache.axis.encoding.ser.BaseSerializerFactory;

/**
 * SerializerFactory for Element
 *
 * @author Rich Scheuerle <scheu@us.ibm.com>
 */
public class ElementSerializerFactory extends BaseSerializerFactory {
    public ElementSerializerFactory() {
        super(ElementSerializer.class);  // Share ElementSerializer instance
    }
}
