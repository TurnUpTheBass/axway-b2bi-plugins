// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Cursor;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Community;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Subscription;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.SubscriptionList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.SubscriptionOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.SubscriptionQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.SubscriptionQueryResult;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.InvalidFormatException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.InvalidQueryException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.ServerException;

import org.apache.axis.description.OperationDesc;

import java.rmi.RemoteException;

public class CommunityManagementApiStub
        extends ClientStub
{
    private ClientSession session;

    public CommunityManagementApiStub(ClientSession session)
    {
        this.session = session;
    }

    public org.w3c.dom.Element findCommunities(org.w3c.dom.Element element)
            throws RemoteException, ServerException, AuthenticationException, InvalidQueryException
    {
        return (org.w3c.dom.Element)executeWithResponse(operations[0], element);
    }

    public CommunityList findCommunitiesEx(CommunityQuery communityQuery)
            throws RemoteException, ServerException, AuthenticationException, InvalidQueryException
    {
        return (CommunityList)executeWithResponse(operations[1], communityQuery);
    }

    public org.w3c.dom.Element findSubscriptions(org.w3c.dom.Element element)
            throws RemoteException, ServerException, AuthenticationException, InvalidQueryException
    {
        return (org.w3c.dom.Element)executeWithResponse(operations[2], element);
    }

    public SubscriptionQueryResult findSubscriptionsEx(SubscriptionQuery subscriptionQuery)
            throws RemoteException
    {
        return (SubscriptionQueryResult)executeWithResponse(operations[3], subscriptionQuery);
    }

    public org.w3c.dom.Element setSubscriptions(org.w3c.dom.Element element)
            throws RemoteException, ServerException, InvalidFormatException, AuthenticationException
    {
        return (org.w3c.dom.Element)executeWithResponse(operations[4], element);
    }

    public SubscriptionOutputList setSubscriptionsEx(SubscriptionList subscriptionList)
            throws RemoteException, ServerException, InvalidFormatException, AuthenticationException
    {
        return (SubscriptionOutputList)executeWithResponse(operations[5], subscriptionList);
    }

    protected Object executeWithResponse(OperationDesc operation, Object param)
        throws RemoteException
    {
        return super.executeWithResponse(session, operation, param);
    }

    protected Class[] getBeanClasses()
    {
        return beanClasses;
    }

    static Class[] beanClasses;

    static
    {
        beanClasses = new Class[10];
        beanClasses[0] = Cursor.class;
        beanClasses[1] = Disposition.class;
        beanClasses[2] = Community.class;
        beanClasses[3] = CommunityList.class;
        beanClasses[4] = CommunityQuery.class;
        beanClasses[5] = Subscription.class;
        beanClasses[6] = SubscriptionList.class;
        beanClasses[7] = SubscriptionOutputList.class;
        beanClasses[8] = SubscriptionQuery.class;
        beanClasses[9] = SubscriptionQueryResult.class;
    }

    static OperationDesc[] operations;

    static
    {
        operations = new OperationDesc[6];
        initOperationDesc();
    }

    private static void initOperationDesc()
    {
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCommunities");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "element"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"), org.w3c.dom.Element.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"));
        oper.setReturnClass(org.w3c.dom.Element.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCommunitiesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "InvalidQueryException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidQueryException"),
                true));
        operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCommunitiesEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "communityQuery"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.cyclonecommerce.com/CommunityManagementAPI", "CommunityQuery"), CommunityQuery.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.cyclonecommerce.com/CommunityManagementAPI", "CommunityList"));
        oper.setReturnClass(CommunityList.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCommunitiesExReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "InvalidQueryException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidQueryException"),
                true));
        operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findSubscriptions");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "element"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"), org.w3c.dom.Element.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"));
        oper.setReturnClass(org.w3c.dom.Element.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findSubscriptionsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "InvalidQueryException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidQueryException"),
                true));
        operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findSubscriptionsEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "subscriptionQuery"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.cyclonecommerce.com/CommunityManagementAPI", "SubscriptionQuery"), SubscriptionQuery.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.cyclonecommerce.com/CommunityManagementAPI", "SubscriptionQueryResult"));
        oper.setReturnClass(SubscriptionQueryResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findSubscriptionsExReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        operations[3] = oper;


        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setSubscriptions");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "element"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"), org.w3c.dom.Element.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"));
        oper.setReturnClass(org.w3c.dom.Element.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "setSubscriptionsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidFormatException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidFormatException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        operations[4] = oper;


        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setSubscriptionsEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "subscriptionList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.cyclonecommerce.com/CommunityManagementAPI", "SubscriptionList"), SubscriptionList.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.cyclonecommerce.com/CommunityManagementAPI", "SubscriptionOutputList"));
        oper.setReturnClass(SubscriptionOutputList.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "setSubscriptionsExReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidFormatException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidFormatException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        operations[5] = oper;

    }
}
