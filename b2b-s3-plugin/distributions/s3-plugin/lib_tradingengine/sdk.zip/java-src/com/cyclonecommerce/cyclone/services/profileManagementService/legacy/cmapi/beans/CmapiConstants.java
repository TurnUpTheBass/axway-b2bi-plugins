// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans;

import org.dom4j.Namespace;

public interface CmapiConstants
{
    public static final String URL_CMAPI = "http://www.cyclonecommerce.com/Schemas/2001/07/cmapi";

    public static final String COMMUNITY_LIST = "CommunityList";
    public static final String COMMUNITY = "Community";
    public static final String COMMUNITY_QUERY = "CommunityQuery";
    public static final String NAME = "Name";
    public static final String SUBSCRIPTION_QUERY = "SubscriptionQuery";
    public static final String COMMUNITY_ID_LIST = "CommunityIdList";
    public static final String COMMUNITY_ID = "CommunityId";
    public static final String ORGANIZATION_ID_LIST = "OrganizationIdList";
    public static final String ORGANIZATION_ID = "OrganizationId";
    // Note, the original CMAPI specs had "BrokerId" as the child element of a
    // community list query, but because of a bug on Cyclone Centrals part, they
    // spelled it "Broker".  In order for the two product it interoperate, we
    // spelled it wrong as well so two wrongs make a right.
    public static final String BROKER = "Broker";
    public static final String SUBSCRIPTION_STATE_LIST = "SubscriptionStateList";
    public static final String SUBSCRIPTION_STATE = "SubscriptionState";
    public static final String SUBSCRIPTION_QUERY_RESULT = "SubscriptionQueryResult";
    public static final String SUBSCRIPTION_LIST = "SubscriptionList";
    public static final String SUBSCRIPTION_OUTPUT_LIST = "SubscriptionOutputList";
    public static final String SUBSCRIPTION = "Subscription";

    // Attribute Values
    public static final String COMMUNITY_ID_ATT = "communityId";
    public static final String ORGANIZATION_ID_ATT = "organizationId";
    public static final String COMMUNITY_NAME_ATT = "communityName";
    public static final String ORGANIZATION_NAME_ATT = "organizationName";
    public static final String STATE_ATT = "state";
    public static final String NAME_ATT = "name";
    public static final String VISIBILITY = "visibility";

    // Visibility Enumerations
    public static final String PUBLIC = "PUBLIC";
    public static final String PRIVATE = "PRIVATE";

    // State Enumerations
    public static final String PENDING = "PENDING";
    public static final String APPROVED = "APPROVED";
    public static final String ACTIVE = "ACTIVE";
    public static final String REVOKED = "REVOKED";

    public static final Namespace NS_UNQUAL = Namespace.get(CmapiConstants.URL_CMAPI);
    public static final Namespace NS_QUAL = Namespace.get("cmapi", CmapiConstants.URL_CMAPI);
}
