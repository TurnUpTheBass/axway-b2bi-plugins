// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.io.Serializable;

public class Community
        implements Serializable
{
    private String communityId;
    private String communityName;
    private String brokerId;
    private boolean publicCommunity;

    public Community()
    {
        super();
    }

    public Community(Element root)
    {
        setCommunityId(root.attributeValue(CmapiConstants.COMMUNITY_ID_ATT));
        setCommunityName(root.attributeValue(CmapiConstants.NAME_ATT));
        setBrokerId(root.elementText(CmapiConstants.BROKER));
        String visiblity = root.attributeValue(CmapiConstants.VISIBILITY);
        setPublicCommunity(CmapiConstants.PUBLIC.equals(visiblity));
    }

    /**
     * Returns the community ID.
     *
     * @return The community ID.
     */
    public String getCommunityId()
    {
        return communityId;
    }

    /**
     * Sets the community ID.
     *
     * @param communityId the community ID.
     */
    public void setCommunityId(String communityId)
    {
        this.communityId = communityId;
    }

    /**
     * Returns the community name.
     *
     * @return The community name.
     */
    public String getCommunityName()
    {
        return communityName;
    }

    /**
     * Sets the community name.
     *
     * @param communityName the community name.
     */
    public void setCommunityName(String communityName)
    {
        this.communityName = communityName;
    }

    /**
     * Returns the broker ID of the broker of this community.  Returns null
     * if the community is not brokered.
     *
     * @return the broker ID.
     */
    public String getBrokerId()
    {
        return brokerId;
    }

    /**
     * Sets the broker ID of the broker of this community.
     *
     * @param brokerId the broker ID.
     */
    public void setBrokerId(String brokerId)
    {
        this.brokerId = brokerId;
    }

    public boolean isPublicCommunity()
    {
        return publicCommunity;
    }

    public void setPublicCommunity(boolean publicCommunity)
    {
        this.publicCommunity = publicCommunity;
    }

    public Element toElement()
    {
        QName qname = new QName(CmapiConstants.COMMUNITY, CmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (communityId != null)
            root.addAttribute(CmapiConstants.COMMUNITY_ID_ATT, communityId);
        if (communityName != null)
            root.addAttribute(CmapiConstants.NAME_ATT, communityName);
        if (brokerId != null)
            root.addElement(CmapiConstants.BROKER).setText(brokerId);
        String visiblity = isPublicCommunity() ? CmapiConstants.PUBLIC : CmapiConstants.PRIVATE;
        root.addAttribute(CmapiConstants.VISIBILITY, visiblity);

        return root;
    }
}
