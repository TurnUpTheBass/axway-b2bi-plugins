// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.BapiConstants;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Cursor;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class CommunityList
        implements Serializable
{
    private Cursor cursor;
    private Community[] communities;

    public CommunityList()
    {
        super();
    }

    public CommunityList(Element root)
    {
        Element cursorElem = root.element(BapiConstants.QN_CURSOR);
        if (cursorElem != null)
            setCursor(new Cursor(cursorElem));

        ArrayList<Community> list = new ArrayList<Community>();
        Iterator it = root.elementIterator(CmapiConstants.COMMUNITY);
        while (it.hasNext())
        {
            list.add(new Community((Element) it.next()));
        }

        Community[] array = new Community[list.size()];
        list.toArray(array);
        setCommunities(array);
    }

    public Cursor getCursor()
    {
        return cursor;
    }

    public void setCursor(Cursor cursor)
    {
        this.cursor = cursor;
    }

    public Community[] getCommunities()
    {
        return communities;
    }

    public void setCommunities(Community[] communities)
    {
        this.communities = communities;
    }

    public Element toElement()
    {
        QName qname = new QName(CmapiConstants.COMMUNITY_LIST, CmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (cursor != null)
            root.add(cursor.toElement());
        if (communities != null)
        {
            for (Community community : communities)
                root.add(community.toElement());
        }

        return root;
    }
}
