// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.BapiConstants;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Cursor;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.io.Serializable;

public class CommunityQuery
        implements Serializable
{
    private Integer max;
    private Cursor cursor;
    private String communityName;

    public CommunityQuery()
    {
        super();
    }

    public CommunityQuery(Element root)
    {
        String sMax = root.attributeValue("max");
        if (sMax != null)
        {
            try
            {
                setMax(new Integer(sMax));
            }
            catch (NumberFormatException e)
            {
                //
            }
        }

        Element cursorElem = root.element(BapiConstants.QN_CURSOR);
        if (cursorElem != null)
            setCursor(new Cursor(cursorElem));

        setCommunityName(root.elementText(CmapiConstants.NAME));
    }

    public Integer getMax()
    {
        return max;
    }

    public void setMax(Integer max)
    {
        this.max = max;
    }

    public Cursor getCursor()
    {
        return cursor;
    }

    public void setCursor(Cursor cursor)
    {
        this.cursor = cursor;
    }

    public String getCommunityName()
    {
        return communityName;
    }

    public void setCommunityName(String communityName)
    {
        this.communityName = communityName;
    }

    public Element toElement()
    {
        QName qname = new QName(CmapiConstants.COMMUNITY_QUERY, CmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);

        if (max != null)
            root.addAttribute("max", max.toString());
        if (cursor != null)
            root.add(cursor.toElement());
        if (communityName != null)
            root.addElement(CmapiConstants.NAME, communityName);

        return root;
    }
}
