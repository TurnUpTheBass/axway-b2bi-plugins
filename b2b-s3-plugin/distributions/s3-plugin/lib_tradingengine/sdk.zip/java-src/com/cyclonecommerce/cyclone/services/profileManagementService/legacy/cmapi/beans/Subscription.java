// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.BapiConstants;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.io.Serializable;

public class Subscription
        implements Serializable
{
    private String communityId;
    private String communityName;
    private String organizationId;
    private String organizationName;
    private String state;
    private Disposition disposition;

    public Subscription()
    {
        super();
    }

    public Subscription(Element root)
    {
        setCommunityId(root.attributeValue(CmapiConstants.COMMUNITY_ID_ATT));
        setCommunityName(root.attributeValue(CmapiConstants.COMMUNITY_NAME_ATT));
        setOrganizationId(root.attributeValue(CmapiConstants.ORGANIZATION_ID_ATT));
        setState(root.attributeValue(CmapiConstants.STATE_ATT));
        Element dispostionElem = root.element(BapiConstants.QN_DISPOSITION);
        if (dispostionElem != null)
            setDisposition(new Disposition(dispostionElem));
    }

    /**
     * Returns the community ID for this subscription.
     *
     * @return The community ID.
     */
    public String getCommunityId()
    {
        return communityId;
    }

    public void setCommunityId(String communityId)
    {
        this.communityId = communityId;
    }

    /**
     * Returns the community name for this subscription.
     *
     * @return The community name.
     */
    public String getCommunityName()
    {
        return communityName;
    }

    public void setCommunityName(String communityName)
    {
        this.communityName = communityName;
    }

    /**
     * Returns the organization ID for this subscription.
     *
     * @return The organization ID.
     */
    public String getOrganizationId()
    {
        return organizationId;
    }

    /**
     * Sets the organization ID for this subscription.
     *
     * @param organizationId the organization ID.
     */
    public void setOrganizationId(String organizationId)
    {
        this.organizationId = organizationId;
    }

    /**
     * Returns the organization name for this subscription.
     *
     * @return The organization name.
     */
    public String getOrganizationName()
    {
        return organizationName;
    }

    /**
     * Sets the organization name for this subscription.
     *
     * @param organizationName the organization name.
     */
    public void setOrganizationName(String organizationName)
    {
        this.organizationName = organizationName;
    }

    /**
     * Returns the subscription state.
     *
     * @return The subscription state.
     */
    public String getState()
    {
        return state;
    }

    /**
     * Sets the subscription state.
     *
     * @param state the subscription state.
     */
    public void setState(String state)
    {
        this.state = state;
    }

    public Disposition getDisposition()
    {
        return disposition;
    }

    public void setDisposition(Disposition disposition)
    {
        this.disposition = disposition;
    }

    public Element toElement()
    {
        QName qname = new QName(CmapiConstants.SUBSCRIPTION, CmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (communityId != null)
            root.addAttribute(CmapiConstants.COMMUNITY_ID_ATT, communityId);
        if (communityName != null)
            root.addAttribute(CmapiConstants.COMMUNITY_NAME_ATT, communityName);
        if (organizationId != null)
            root.addAttribute(CmapiConstants.ORGANIZATION_ID_ATT, organizationId);
        if (organizationName != null)
            root.addAttribute(CmapiConstants.ORGANIZATION_NAME_ATT, organizationName);
        if (state != null)
            root.addAttribute(CmapiConstants.STATE_ATT, state);
        if (disposition != null)
        {
            root.add(BapiConstants.NS_BAPI);
            root.add(disposition.toElement());
        }

        return root;
    }
}
