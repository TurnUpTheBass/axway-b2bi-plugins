// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.util.ArrayList;
import java.util.Iterator;

public class SubscriptionOutputList
{
    private Subscription[] subscriptions;

    public SubscriptionOutputList()
    {
        super();
    }

    public SubscriptionOutputList(Element root)
    {
        ArrayList<Subscription> list = new ArrayList<Subscription>();
        Iterator it = root.elementIterator(CmapiConstants.SUBSCRIPTION);
        while (it.hasNext())
        {
            list.add(new Subscription((org.dom4j.Element) it.next()));
        }

        Subscription[] array = new Subscription[list.size()];
        list.toArray(array);
        setSubscriptions(array);
    }

    public Subscription[] getSubscriptions()
    {
        return subscriptions;
    }

    public void setSubscriptions(Subscription[] subscriptions)
    {
        this.subscriptions = subscriptions;
    }

    public Element toElement()
    {
        QName qname = new QName(CmapiConstants.SUBSCRIPTION_OUTPUT_LIST, CmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (subscriptions != null)
        {
            for (Subscription subscription : subscriptions)
            {
                root.add(subscription.toElement());
            }
        }

        return root;
    }
}
