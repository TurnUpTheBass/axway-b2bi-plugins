// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.BapiConstants;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Cursor;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.util.ArrayList;
import java.util.Iterator;

public class SubscriptionQuery
{
    private Integer max;
    private Cursor cursor;
    private String[] communityIds;
    private String[] subscriptionStates;
    private String[] organizationIds;

    public SubscriptionQuery()
    {
        super();
    }

    public SubscriptionQuery(Element root)
    {
        String sMax = root.attributeValue("max");
        if (sMax != null)
        {
            try
            {
                setMax(new Integer(sMax));
            }
            catch (NumberFormatException e)
            {
                //
            }
        }

        Element cursorElem = root.element(BapiConstants.QN_CURSOR);
        if (cursorElem != null)
            setCursor(new Cursor(cursorElem));

        ArrayList<String> tempList = new ArrayList<String>();
        QName qname = new QName(CmapiConstants.COMMUNITY_ID_LIST, BapiConstants.NS_BAPI);
        Element elem = root.element(qname);
        if (elem != null)
        {
            Iterator it = elem.elementIterator(CmapiConstants.COMMUNITY_ID);
            while (it.hasNext())
            {
                tempList.add(((Element) it.next()).getText());
            }
        }
        String[] array = new String[tempList.size()];
        tempList.toArray(array);
        setCommunityIds(array);

        tempList = new ArrayList<String>();
        elem = root.element(CmapiConstants.SUBSCRIPTION_STATE_LIST);
        if (elem != null)
        {
            Iterator it = elem.elementIterator(CmapiConstants.SUBSCRIPTION_STATE);
            while (it.hasNext())
            {
                tempList.add(((Element) it.next()).getText());
            }
        }
        array = new String[tempList.size()];
        tempList.toArray(array);
        setSubscriptionStates(array);

        tempList = new ArrayList<String>();
        qname = new QName(CmapiConstants.ORGANIZATION_ID_LIST, BapiConstants.NS_BAPI);
        elem = root.element(qname);
        if (elem != null)
        {
            Iterator it = elem.elementIterator(CmapiConstants.ORGANIZATION_ID);
            while (it.hasNext())
            {
                tempList.add(((Element) it.next()).getText());
            }
        }
        array = new String[tempList.size()];
        tempList.toArray(array);
        setOrganizationIds(array);
    }

    public Integer getMax()
    {
        return max;
    }

    public void setMax(Integer max)
    {
        this.max = max;
    }

    public Cursor getCursor()
    {
        return cursor;
    }

    public void setCursor(Cursor cursor)
    {
        this.cursor = cursor;
    }

    public String[] getCommunityIds()
    {
        return communityIds;
    }

    public void setCommunityIds(String[] communityIds)
    {
        this.communityIds = communityIds;
    }

    public String[] getSubscriptionStates()
    {
        return subscriptionStates;
    }

    public void setSubscriptionStates(String[] subscriptionStates)
    {
        this.subscriptionStates = subscriptionStates;
    }

    public String[] getOrganizationIds()
    {
        return organizationIds;
    }

    public void setOrganizationIds(String[] organizationIds)
    {
        this.organizationIds = organizationIds;
    }

    public Element toElement()
    {
        QName qname = new QName(CmapiConstants.COMMUNITY_QUERY, CmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);

        if (max != null)
            root.addAttribute("max", max.toString());
        if (cursor != null)
            root.add(cursor.toElement());

        if (communityIds != null)
        {
            qname = new QName(CmapiConstants.COMMUNITY_ID_LIST, BapiConstants.NS_BAPI);
            Element elem = root.addElement(qname);
            for (String id : communityIds)
            {
                elem.addElement(CmapiConstants.COMMUNITY_ID).setText(id);
            }
        }

        if (subscriptionStates != null)
        {
            Element elem = root.addElement(CmapiConstants.SUBSCRIPTION_STATE_LIST);
            for (int i = 0; i < communityIds.length; i++)
            {
                String state = subscriptionStates[i];
                elem.addElement(CmapiConstants.SUBSCRIPTION_STATE).setText(state);
            }
        }

        if (organizationIds != null)
        {
            qname = new QName(CmapiConstants.ORGANIZATION_ID_LIST, BapiConstants.NS_BAPI);
            Element elem = root.addElement(qname);
            for (int i = 0; i < communityIds.length; i++)
            {
                String id = organizationIds[i];
                elem.addElement(CmapiConstants.ORGANIZATION_ID).setText(id);
            }
        }

        return root;
    }
}
