// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.BapiConstants;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Cursor;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.util.ArrayList;
import java.util.Iterator;

public class SubscriptionQueryResult
{
    private Cursor cursor;
    private Subscription[] subscriptions;

    public SubscriptionQueryResult()
    {
        super();
    }

    public SubscriptionQueryResult(Element root)
    {
        Element cursorElem = root.element(BapiConstants.QN_CURSOR);
        if (cursorElem != null)
            setCursor(new Cursor(cursorElem));

        ArrayList<Subscription> list = new ArrayList<Subscription>();
        Iterator it = root.elementIterator(CmapiConstants.SUBSCRIPTION);
        while (it.hasNext())
        {
            list.add(new Subscription((Element) it.next()));
        }

        Subscription[] array = new Subscription[list.size()];
        list.toArray(array);
        setSubscriptions(array);
    }

    public Cursor getCursor()
    {
        return cursor;
    }

    public void setCursor(Cursor cursor)
    {
        this.cursor = cursor;
    }

    public Subscription[] getSubscriptions()
    {
        return subscriptions;
    }

    public void setSubscriptions(Subscription[] subscriptions)
    {
        this.subscriptions = subscriptions;
    }

    public Element toElement()
    {
        QName qname = new QName(CmapiConstants.SUBSCRIPTION_QUERY_RESULT, CmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (cursor != null)
            root.add(cursor.toElement());
        if (subscriptions != null)
        {
            for (Subscription subscription : subscriptions)
                root.add(subscription.toElement());
        }

        return root;
    }
}
