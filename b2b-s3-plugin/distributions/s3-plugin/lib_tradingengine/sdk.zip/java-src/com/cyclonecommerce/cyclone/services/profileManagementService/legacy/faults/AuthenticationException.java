// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults;

import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.message.SOAPEnvelope;
import org.apache.axis.message.SOAPFault;
import org.apache.axis.message.SOAPHeaderElement;
import org.apache.axis.soap.SOAPConstants;

public class AuthenticationException extends BaseException
{
    private static final String LEGACY_FAULT_CODE = "SOAP-ENV:Server.IDK_AUTHENTICATION";

    public static final String AUTHENTICATION_FAILED = "102";
    public static final String UNABLE_TO_DECODE_SIGNED_MESSAGE = "103";
    public static final String INVALID_TOKEN = "104";
    public static final String INVALID_TIMESTAMP = "105";
    public static final String ORGANIZATION_NOT_FOUND = "106";
    public static final String INVALID_SIGNATURE_CERT = "107";
    public static final String METHOD_NOT_IMPLEMENTED = "108";

    private String reasonCode;

    public AuthenticationException()
    {
        super();
    }

    public AuthenticationException(String reasonCode)
    {
        super();
        this.reasonCode = reasonCode;
    }

    public AuthenticationException(String reasonCode, String message)
    {
        super(message);
        this.reasonCode = reasonCode;
    }

    public AuthenticationException(String reasonCode, String message, Throwable t)
    {
        super(message, t);
        this.reasonCode = reasonCode;
    }

    public AuthenticationException(String reasonCode, Throwable t)
    {
        super(t);
        this.reasonCode = reasonCode;
    }

    public String getReasonCode()
    {
        return reasonCode;
    }

    public void setReasonCode(String reasonCode)
    {
        this.reasonCode = reasonCode;
    }

    /**
     * Overrides the default implementation so the reason code is added as an attribute to
     * the fault body of the envelope. This is necessary to interop with CI 4.x clients.
     */
    public void output(SerializationContext context) throws Exception {

        SOAPConstants soapConstants = org.apache.axis.Constants.DEFAULT_SOAP_VERSION;
        if (context.getMessageContext() != null) {
            soapConstants = context.getMessageContext().getSOAPConstants();
        }

        SOAPEnvelope envelope = new SOAPEnvelope(soapConstants);

        SOAPFault fault = new SOAPFault(this);
        envelope.addBodyElement(fault);

        // Begin custom code
        if (reasonCode != null)
            fault.addAttribute("", "reason_code", reasonCode);
        // End custom code

        // add any headers we need
        if (faultHeaders != null) {
            for (Object faultHeader : faultHeaders)
            {
                SOAPHeaderElement header = (SOAPHeaderElement) faultHeader;
                envelope.addHeader(header);
            }
        }

        envelope.output(context);
    }

    /**
     * This is necessary for 4.x interop
     */
    protected void init()
    {
        setFaultCodeAsString(LEGACY_FAULT_CODE);
        setFaultString(getMessage());
        setFaultActor("/idk");
    }

    protected String getLegacyClassName()
    {
        return LEGACY_FAULT_CODE;
    }
}
