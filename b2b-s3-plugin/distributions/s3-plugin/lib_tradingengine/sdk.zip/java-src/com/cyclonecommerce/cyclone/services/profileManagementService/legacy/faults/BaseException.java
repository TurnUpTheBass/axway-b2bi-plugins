// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults;

import org.apache.axis.AxisFault;

import java.io.PrintWriter;
import java.io.StringWriter;

public abstract class BaseException extends AxisFault
{
    private static final String FAULT_CODE_SERVER = "SOAP-ENV:Server";
    private static final String JAVA_EXCEPTION_FAULT_PREFIX = FAULT_CODE_SERVER + ".JAVA_EXCEPTION.";
    
    private String remoteCause;

    public BaseException()
    {
        super();
        init();
    }

    public BaseException(String message)
    {
        super(message);
        init();
    }

    public BaseException(String message, Throwable t)
    {
        super(message);
        setRemoteCause(t);
        init();
    }

    public BaseException(Throwable t)
    {
        super(t.getMessage());
        setRemoteCause(t);
        init();
    }

    public String getRemoteCause()
    {
        return remoteCause;
    }

    public void setRemoteCause(String remoteCause)
    {
        this.remoteCause = remoteCause;
    }

    private void setRemoteCause(Throwable cause)
    {
        StringWriter sw = new StringWriter(1024);
        cause.printStackTrace(new PrintWriter(sw));
        remoteCause = sw.toString();
    }

    protected abstract String getLegacyClassName();

    /**
     * This is necessary for 4.x interop
     */
    protected void init()
    {
        setFaultCodeAsString(JAVA_EXCEPTION_FAULT_PREFIX + getLegacyClassName());
        setFaultString(getMessage());
        setFaultActor("/idk");
    }
}
