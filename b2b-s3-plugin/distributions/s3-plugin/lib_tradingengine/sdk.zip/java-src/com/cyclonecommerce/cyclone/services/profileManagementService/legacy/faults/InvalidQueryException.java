// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults;

public class InvalidQueryException extends BaseException
{
    private static final String LEGACY_CLASS_NAME = "com.cyclonecommerce.idk.api.InvalidQueryException";

    public InvalidQueryException()
    {
        super();
    }

    public InvalidQueryException(String message)
    {
        super(message);
    }

    public InvalidQueryException(String message, Throwable t)
    {
        super(message, t);
    }

    protected String getLegacyClassName()
    {
        return LEGACY_CLASS_NAME;
    }
}
