// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import org.dom4j.Document;
import org.dom4j.Element;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Batch_Module
{
	public static final String product = "Interchange PMAPI Test Tool Version 1.0";
	private static Batch_Module instance;
	private boolean fatal_error;

	public static synchronized Batch_Module getInstance()
	{
		if (instance == null)
			instance = new Batch_Module();
    	return instance;
	}

	public void processFiles()
	{
		Utilities.displayAndLogMessage(product, false);
		// Community Profiles
		importConfiguredProfiles(true);
		exportCommunity(true);
		// Partner Profiles
		importConfiguredProfiles(false);
		exportConfiguredPartnerProfiles();
		exportCommunity(false);

		executeCommands(Constants.SET_FILE);
		executeCommands(Constants.GET_FILE);
		executeCommands(Constants.DELETE_FILE);

		deleteConfiguredProfiles(Constants.COMMUNITY_PROFILE_DELETE);
		deleteConfiguredProfiles(Constants.PARTNER_PROFILE_DELETE);
	}

	private void importConfiguredProfiles(boolean isCommunityProfile)
	{
		String profileType = (isCommunityProfile) ? "Community" : "Partner";
		Utilities.displayAndLogMessage("Importing configured "+profileType+" profiles", false);

		Map<File, String> importedConfiguredProfiles = new HashMap<File, String>();
		String profileKey = (isCommunityProfile) ? Constants.COMMUNITY_PROFILE_IMPORT : Constants.PARTNER_PROFILE_IMPORT;
		for (String xmlFileName : Utilities.getProperty(profileKey))
		{
			File xmlFile = Utilities.verifyXMLFile(xmlFileName);
			if (xmlFile == null)
			{
				fatal_error = true;
				break;
			}
			Document doc = Utilities.readFile(xmlFile, xmlFileName);
			if (doc == null)
			{
				fatal_error = true;
				break;
			}
			Element rootElement = Utilities.getProfileRootElement(doc, xmlFileName, isCommunityProfile);
			if (rootElement == null)
			{
				fatal_error = true;
				break;
			}
			Element adminInfoElement = Utilities.getElement(rootElement, Constants.ADMINISTRATIVE_INFO);
			if (adminInfoElement == null)
			{
				Utilities.displayAndLogMessage("Error: XML file " + xmlFileName + " invalid: No AdministrativeInfo element found", true);
				fatal_error = true;
				break;
			}
			String organizationName = Utilities.getOrganizationName(adminInfoElement, Constants.ORGANIZATION_NAME);
			if (organizationName == null)
			{
				Utilities.displayAndLogMessage("Error: "+profileType+" Name not found in XML File: " + xmlFileName, true);
				fatal_error = true;
				break;
			}
			importedConfiguredProfiles.put(xmlFile, organizationName);
		}
		if (fatal_error)
			exit_with_error();
		else
		{
			Set<File> importKeys = importedConfiguredProfiles.keySet();
			if (importKeys.isEmpty())
			{
				Utilities.displayAndLogMessage("No files found for importing "+profileType+" profiles", false);
				return;
			}
			for (File importFile : importKeys)
			{
				String organizationName = importedConfiguredProfiles.get(importFile);
				PMAPI_Profile_Processing pmapi_profile_processing = new PMAPI_Profile_Processing();
				if (!pmapi_profile_processing.importProfile(importFile, organizationName, isCommunityProfile))
				{
					fatal_error = true;
					break;
				}
			}
			if (fatal_error)
				exit_with_error();
		}
		Utilities.displayAndLogMessage("Importing "+profileType+" profiles complete.", false);
	}

	private void exportConfiguredPartnerProfiles()
	{
		Utilities.displayAndLogMessage("Exporting configured profiles", false);
		for (String partnerProfile : Utilities.getProperty(Constants.PARTNER_PROFILE_EXPORT))
		{
			PMAPI_Profile_Processing pmapi_profile_processing = new PMAPI_Profile_Processing();
			if (!pmapi_profile_processing.exportPartnerProfile(partnerProfile))
			{
				fatal_error = true;
				break;
			}
		}
		if (fatal_error)
			exit_with_error();
		Utilities.displayAndLogMessage("Exporting profiles complete.", false);
	}

	private void exportCommunity(boolean exportAsCommunityProfile)
	{
		if (exportAsCommunityProfile)
			Utilities.displayAndLogMessage("Exporting Community profiles.", false);
		else
			Utilities.displayAndLogMessage("Exporting Community profiles as partner profile", false);

		List<String> communityExportList = (exportAsCommunityProfile) ?
				Utilities.getProperty(Constants.COMMUNITY_EXPORT_PROFILE) :
				Utilities.getProperty(Constants.COMMUNITY_EXPORT_AS_PARTNER_PROFILE);

		if (communityExportList.size() > 0)
		{
			String[] community = new String[communityExportList.size()];
			communityExportList.toArray(community);
			PMAPI_Profile_Processing pmapi_profile_processing = new PMAPI_Profile_Processing();
			if (!pmapi_profile_processing.exportCommunity(community, exportAsCommunityProfile))
				fatal_error = true;

			//Utilities.validateProfiles(true);
			if (fatal_error)
				exit_with_error();
			if (exportAsCommunityProfile)
				Utilities.displayAndLogMessage("Exporting Community profiles complete.", false);
			else
				Utilities.displayAndLogMessage("Exporting Community as partner profile complete.", false);
		}
		else
			Utilities.displayAndLogMessage("No communities found for exporting.", false);
	}

	private void deleteConfiguredProfiles(String profileType)
	{
		Utilities.displayAndLogMessage("Deleting configured "+(Constants.COMMUNITY_PROFILE_DELETE.equals(profileType) ? "community" : "partner")+" profiles", false);
		List<String> validatedKeys = new ArrayList<String>();
		for (String partnerProfile : Utilities.getProperty(profileType))
		{
			PMAPI_Profile_Processing pmapi_profile_processing = new PMAPI_Profile_Processing();
			if (!pmapi_profile_processing.deleteProfile(partnerProfile, true))
			{
				fatal_error = true;
				break;
			}
			else
				validatedKeys.add(partnerProfile);
		}
		if (fatal_error)
			exit_with_error();
		Utilities.removeOrganizations(validatedKeys, profileType.equals(Constants.COMMUNITY_PROFILE_DELETE));
		Utilities.displayAndLogMessage("Deleting profiles complete.", false);
	}

	private void  executeCommands(String typeKey)
	{
		Utilities.displayAndLogMessage("Executing configured "+typeKey+" commands", false);
		Map<String, String> exportImportValues = PropertiesFile.getInstance().getExportImportValues();
		List<String> fileKeys = new ArrayList<String>();
		for (String aKey : exportImportValues.keySet())
		{
			if (aKey.contains(typeKey))
				fileKeys.add(aKey);
		}
		CommandAndDocument[] commandAndDocuments = new CommandAndDocument[fileKeys.size()];
		int i = 0;
		for (String propertiesFileKey : fileKeys)
		{
			String aFileName = exportImportValues.get(propertiesFileKey);
			File aFile = Utilities.verifyXMLFile(aFileName);
			if (aFile == null)
			{
				fatal_error = true;
				break;
			}
        	Document doc = Utilities.readFile(aFile, aFileName);
			if (doc == null)
			{
				fatal_error = true;
				break;
			}
        	String pluggableCommandName = Utilities.getPluggableCommand(doc, aFileName);
			if (pluggableCommandName == null)
			{
				fatal_error = true;
				break;
			}
			if (Constants.GET_FILE.equals(typeKey))
				commandAndDocuments[i++] = new CommandAndDocument(pluggableCommandName, doc, Utilities.findArtifactNameInGetXML(doc));
			else
				commandAndDocuments[i++] = new CommandAndDocument(pluggableCommandName, doc, null);
		}
		if (fatal_error)
			exit_with_error();
		else
		{
			for (CommandAndDocument aCommandAndDoc : commandAndDocuments)
			{
				PmApiProcessing pmApiProcessing = new PmApiProcessing();
				if (!pmApiProcessing.processCommand(aCommandAndDoc))
				{
					fatal_error = true;
					break;
				}
			}
			if (fatal_error)
				exit_with_error();
			if (Constants.GET_FILE.equals(typeKey) && !Utilities.validateCommands())
				exit_with_error();
		}
		Utilities.displayAndLogMessage("Executing "+typeKey+" commands complete.", false);
	}

	private void exit_with_error()
	{
		Utilities.displayAndLogMessage("Abnormal termination", true);
		System.exit(-1);
	}

}
