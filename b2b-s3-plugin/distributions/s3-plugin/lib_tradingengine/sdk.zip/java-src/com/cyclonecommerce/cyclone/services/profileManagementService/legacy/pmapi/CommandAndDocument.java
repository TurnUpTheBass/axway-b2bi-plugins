// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import org.dom4j.Document;

public class CommandAndDocument
{
	private String pluggableCommand;
	private Document userDoc;
	private String artifactName;
	private Document hostReturnedDoc;

	public CommandAndDocument(String pluggableCommand, Document doc, String artifactName)
	{
		this.pluggableCommand = pluggableCommand;
		this.userDoc = doc;
		this.artifactName = artifactName;
	}

	public String getCommand()
	{
		return pluggableCommand;
	}

	public Document getUserDoc()
	{
		return userDoc;
	}

	public String getArtifactName()
	{
		return artifactName;
	}

	public void setHostReturnedDoc(Document doc)
	{
		this.hostReturnedDoc = doc;
	}

	public Document getHostReturnedDoc()
	{
		return hostReturnedDoc;
	}

}
