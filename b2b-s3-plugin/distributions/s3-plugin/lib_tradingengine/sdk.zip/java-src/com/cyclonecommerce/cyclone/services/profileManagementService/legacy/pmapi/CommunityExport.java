// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.CommunityManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Community;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommunityExport
{
	private static final Logger logger = LogManager.getLogger(CommunityExport.class);

	private String message;

	public CommunityExport()
	{
		this.message = null;
	}

	public boolean exportCommunitiesProfile(File outputDir, boolean exportAsCommunityProfile, String... exportNames)
	{
		try
		{
			List<Community> communities;
			if (exportNames != null && exportNames.length > 0)
			{
				communities = getCommunities(exportNames);
				if (communities.size() != exportNames.length)
				{
					String missingCommunities = Utilities.extractMissingCommunities(exportNames, communities);
					this.message = missingCommunities + " not found on the host. Nothing exported";
					return false;
				}
			}
			else
			{
				communities = getCommunities();
				if (communities.size() == 0)
				{
					this.message = "No communities exist in host for export";
					return false;
				}
			}

			for (Community community : communities)
			{
				if (exportAsCommunityProfile)
					Utilities.displayAndLogMessage("Writing community profile to export directory " + outputDir + " for community: " + community.getCommunityName() + ".", false);
				else
					Utilities.displayAndLogMessage("Writing partner profile to export directory " + outputDir + " for community: " + community.getCommunityName() + ".", false);

				ProfileExport pe = new ProfileExport();
				pe.exportCommunityProfiles(outputDir, community, exportAsCommunityProfile);
			}
			return true;
		}
		catch (Exception e)
		{
			logger.error("Error exporting communities", e);
			this.message = e.getMessage();
			return false;
		}
	}

	private List<Community> getCommunities(String... communityNames)
		throws RemoteException
	{
		List<Community> result = new ArrayList<Community>();
		for (String communityName : communityNames)
		{
			CommunityQuery cq = new CommunityQuery();
			cq.setCommunityName(communityName);
			CommunityList cl = getCommunityIds(cq);
			Community[] communities = cl.getCommunities();
			// if communities was not found in host then don't add it to result
			if (communities.length != 0)
				result.addAll(Arrays.asList(communities));
		}
		return result;
	}

	public String getMessage()
	{
		return message;
	}

	private CommunityList getCommunityIds(CommunityQuery cq)
		throws RemoteException
	{
		ClientSession session = null;
		try
		{
			PropertiesFile pf = PropertiesFile.getInstance();
			session = Utilities.createSession(pf.getUser(), pf.getPASSWORD(), pf.getURL());
			CommunityManagementApiStub service = new CommunityManagementApiStub(session);
			return service.findCommunitiesEx(cq);
		}
		finally
		{
			if (session != null)
				session.close();
		}
	}

}
