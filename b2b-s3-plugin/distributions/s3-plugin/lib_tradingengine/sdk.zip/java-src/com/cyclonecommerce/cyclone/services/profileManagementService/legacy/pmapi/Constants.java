// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

public final class Constants
{
	public static final String ACTION = "Action";
	public static final String ADMINISTRATIVE_INFO = "AdministrativeInfo";
	public static final String DELETE_FILE = "DEL.FILE";
	public static final String GET_FILE = "GET.FILE";
	public static final String SET_FILE = "SET.FILE";
	public static final String BUSINESS_PROTOCOLS = "BusinessProtocols";
	public static final String COMMAND = "Command";
	public static final String COMMUNITY_EXPORT_PROFILE = "COMMUNITY_EXPORT_PROFILE";
	public static final String COMMUNITY_REQUEST_FILENAME = "COMMUNITY_REQUEST_FILENAME";
	public static final String COMMUNITY_EXPORT_AS_PARTNER_PROFILE = "COMMUNITY_EXPORT_AS_PARTNER_PROFILE";
	public static final String CONTACT = "Contact";
	public static final String CONTACTS = "Contacts";
	public static final String COUNTRY_CODE = "CountryCode";
	public static final String COUNTRY_CODE_NAME = "CountryCodeName";
	public static final String DETECTOR = "Detector";
	public static final String EMAIL = "Email";
	public static final String EXIT = "Exit";
	public static final String EXPORT = "Export";
	public static final String EXPORT_DIR = "EXPORT_DIR";
	public static final String IMPORT = "Import";
	public static final String INTERCHANGE_COMMUNITY_PROFILE = "InterchangeCommunityProfile";
	public static final String nAME = "name";
	public static final String NAME = "Name";
	public static final String NOTES = "Notes";
	public static final String ORGANIZATION_FORMAT = "CycloneOrganizationProfile_2001";
	public static final String ORGANIZATION_NAME = "OrganizationName";
	public static final String ORGANIZATION_PROFILE = "OrganizationProfile";
	public static final String PARTY_NAME = "partyName";

	public static final String PLUGGABLE_COMMAND = "PluggableCommand";
	public static final String POSTAL_ADDRESS = "PostalAddress";
	public static final String PREFERRED_TRANSPORT_REF = "preferredTransportRef";
	public static final String COMMUNITY_PROFILE_IMPORT = "COMMUNITY_PROFILE_IMPORT";
	public static final String COMMUNITY_PROFILE_DELETE = "COMMUNITY_PROFILE_DELETE";
	public static final String PARTNER_PROFILE_DELETE = "PARTNER_PROFILE_DELETE";
	public static final String PARTNER_PROFILE_EXPORT = "PARTNER_PROFILE_EXPORT";
	public static final String PARTNER_PROFILE_IMPORT = "PARTNER_PROFILE_IMPORT";
	public static final String ROUTING_IDS = "RoutingIds";
	public static final String ROUTINGID = "RoutingId";
	public static final String TRANSPORTS = "Transports";
	public static final String TYPE = "type";
	public static final String UI_GET_COMMANDS = "Get Commands";
	public static final String UI_SET_COMMANDS = "Set Commands";
	public static final String UI_DELETE_COMMANDS = "Delete Commands";
	public static final String UI_EXPORT_COMMUNITIES = "Export Communities";
	public static final String UI_EXPORT_COMMUNITIES_AS_PARTNER_PROFILE = "As Partner profile";
	public static final String UI_EXPORT_COMMUNITIES_AS_COMMUNITY_PROFILE = "As Community profile";
	public static final String UI_COMMUNITY_PROFILE_IMPORT = "Import Community Profile";
	public static final String UI_COMMUNITY_PROFILE_DELETE = "Delete Community Profile";
	public static final String UI_EXPORT_PARTNERS = "Export Partners";
	public static final String UI_PARTNER_PROFILE_DELETE = "Delete Partner Profile";
	public static final String UI_PARTNER_PROFILE_IMPORT = "Import Partner Profile";
	public static final String URL = "URL";
	public static final String USER = "USER";
	public static final String VALIDATION_ERROR = "Validation error: ";
	//
	// Error Messages
	//
	public static final String ERR_ADMIN_INFO = " AdminInfo Elements ";
	public static final String ERR_ROUTING_IDS = " Routing ID's ";
	public static final String ERR_TRANSPORTS = " Transport definitions ";
	//
	// Commands
	//
	public static final String DEL_APPLICATION_DELIVERY = "DeleteApplicationDelivery";
	public static final String DEL_APPLICATION_PICKUP = "DeleteApplicationPickup";
	public static final String DEL_INTEGRATION_DELIVERY = "DeleteIntegrationDelivery";
	public static final String DEL_INTEGRATION_PICKUP = "DeleteIntegrationPickup";
	public static final String DEL_METADATA = "DeleteMetadata";
	public static final String DEL_METADATA_TEMPLATE = "DeleteMetadataTemplate";
	public static final String GET_APPLICATION_DELIVERY = "GetApplicationDelivery";
	public static final String GET_APPLICATION_PICKUP = "GetApplicationPickup";
	public static final String GET_APPLICATION_EXTENSION_PROFILE = "GetApplicationExtensionProfile";
	public static final String GET_DEFAULT_COLLABORATION_SETTINGS = "GetDefaultCollaborationSettings";
	public static final String GET_DOCUMENT_SERVICE = "GetDocumentService";
	public static final String GET_E_INVOICE_SERVICE = "GetEInvoiceService";
	public static final String GET_INTEGRATION_DELIVERY = "GetIntegrationDelivery";
	public static final String GET_INTEGRATION_PICKUP = "GetIntegrationPickup";
	public static final String GET_MESSAGE_HANDLER = "GetMessageHandler";
	public static final String GET_METADATA = "GetMetadata";
	public static final String GET_METADATA_PROFILE = "GetMetadataProfile";
	public static final String GET_METADATA_TEMPLATE = "GetMetadataTemplate";
	public static final String GET_PROPERTY_TEMPLATE = "GetPropertyTemplate";
	public static final String GET_PROCESSING_STEP = "GetProcessingStep";
	public static final String GET_SENTINEL_INTEGRATION_CONFIG = "GetSentinelIntegrationConfig";
	public static final String GET_AGREEMENT_PROFILE = "GetAgreementProfile";
	public static final String SET_APPLICATION_DELIVERY = "SetApplicationDelivery";
	public static final String SET_APPLICATION_PICKUP = "SetApplicationPickup";
	public static final String SET_APPLICATION_EXTENSION_PROFILE = "SetApplicationExtensionProfile";
	public static final String SET_DEFAULT_COLLABORATION_SETTINGS = "SetDefaultCollaborationSettings";
	public static final String SET_DOCUMENT_SERVICE = "SetDocumentService";
	public static final String SET_E_INVOICE_SERVICE = "SetEInvoiceService";
	public static final String SET_ENTIRE_SYSTEM_IMPORT = "SetEntireSystemImport";
	public static final String SET_INTEGRATION_DELIVERY = "SetIntegrationDelivery";
	public static final String SET_INTEGRATION_PICKUP = "SetIntegrationPickup";
	public static final String SET_MESSAGE_HANDLER = "SetMessageHandler";
	public static final String SET_METADATA = "SetMetadata";
	public static final String SET_METADATA_PROFILE = "SetMetadataProfile";
	public static final String SET_METADATA_TEMPLATE = "SetMetadataTemplate";
	public static final String SET_PROPERTY_TEMPLATE = "SetPropertyTemplate";
	public static final String SET_PROCESSING_STEP = "SetProcessingStep";
	public static final String SET_SENTINEL_INTEGRATION_CONFIG = "SetSentinelIntegrationConfig";
	public static final String SET_AGREEMENT_PROFILE = "SetAgreementProfile";
	//
	// Names
	//
	public static final String APPLICATION_EXTENSION = "ApplicationExtension";
	public static final String APPLICATION_EXTENSION_PROFILE_NAME = "ApplicationExtensionProfileName";
	public static final String DOCUMENT_SERVICE = "DocumentService";
	public static final String DOCUMENT_SERVICE_NAME = "DocumentServiceName";
	public static final String E_INVOICE_SERVICE_PARAMETERS = "eInvoiceServiceParameters";
	public static final String META_DATA_PROFILE = "MetadataProfile";
	public static final String META_DATA_PROFILE_NAME = "MetadataProfileName";
	public static final String PROCESSING_STEP = "ProcessingStep";
	public static final String PROCESSING_STEP_NAME = "ProcessingStepName";
	public static final String METADATA_TEMPLATE_NAME = "MetadataTemplateName";
	public static final String PROPERTY_TEMPLATE = "PropertyTemplate";
	public static final String METADATA_ATTRIBUTE_NAME = "MessageAttributeName";
	//
	// Display Messages and keys
	//
	public static final String PROCESSING_STEPS = "ProcessingSteps";

	private Constants()
	{
		//utility classes should not have a public or default constructor
	}

}
