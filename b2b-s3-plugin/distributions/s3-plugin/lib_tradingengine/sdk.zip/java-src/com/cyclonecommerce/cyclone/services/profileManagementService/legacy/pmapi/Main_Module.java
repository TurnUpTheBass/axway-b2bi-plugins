// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Main_Module
{
	private static final Logger logger = LogManager.getLogger(Main_Module.class);

	public Main_Module(String propertiesFileName)
	{
		PropertiesFile propertiesFile = PropertiesFile.getInstance();
		propertiesFile.setPropertiesFileName(propertiesFileName);
		try
		{
			if (!propertiesFile.readPropertiesFile())
				System.exit(-1);
		}
		catch (Exception e)
		{
			logger.error("Error: " + e.getMessage(), e);
			System.out.println("Error: " + e.getMessage());
			System.exit(-1);
		}
	}

	public static void main(String[] args)
	{
		if (args != null &&
			args.length == 2 &&
			(args[0].equals("-m") || args[0].equals("-b")) &&
			Utilities.verifyPropertiesFile(args))
		{
			new Main_Module(args[1]);
			if (args[0].equals("-m"))
				new UI_Module();
			else //"-b" batch-mode is the default
			{
				Batch_Module bm = Batch_Module.getInstance();
				bm.processFiles();
			}
		}
		else
			usage();

		System.exit(-1);
	}

	private static void usage()
	{
		System.out.println("\nUsage: PMAPI_TestTool.jar -option propertiesFile");
		System.out.println("   option: -m (manual mode)");
		System.out.println("           -b (batch mode)");
		System.out.println("Example: PMAPI_TestTool.jar -m c:\\PMAPI_TestTool.properties");
	}

}
