// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;

import java.io.IOException;
import java.io.StringWriter;

public class NegativeDispositionException
	extends Exception
{
	private Disposition disposition;

	public NegativeDispositionException(Disposition disposition)
	{
		super(disposition.getTitle());
		this.disposition = disposition;
	}

	public String getId()
	{
		return disposition.getId();
	}

	public Disposition getDisposition()
	{
		return disposition;
	}

	public String toString()
	{
		StringWriter sw = new StringWriter(512);
		try
		{
			ElementUtil.write(disposition.toElement(), sw);
		}
		catch (IOException e)
		{
			return super.toString();
		}
		return sw.toString();
	}

}
