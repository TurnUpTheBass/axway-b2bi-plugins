// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import java.io.File;
import java.util.Arrays;

public class PMAPI_Profile_Processing
{
	public PMAPI_Profile_Processing()
	{
	}

	public boolean exportCommunity(String[] community, boolean exportAsCommunityProfile)
	{
		if (community == null)
			return Utilities.displayAndLogMessageWithReturn("Error: community parameter was null", true, false);
		Utilities.displayAndLogMessage("exportCommunity: "+ Arrays.asList(community), false);

		CommunityExport exporter = new CommunityExport();
		PropertiesFile pf = PropertiesFile.getInstance();
		String exportDirectory = pf.getExportDirectory();
		File dir = new File(exportDirectory);
		if (!dir.exists() && !dir.mkdirs() && !dir.isDirectory())
			return Utilities.displayAndLogMessageWithReturn("Error: Invalid directory name for EXPORT_DIR ["+exportDirectory+"]", true, false);
		if (exporter.exportCommunitiesProfile(dir, exportAsCommunityProfile, community))
			return Utilities.displayAndLogMessageWithReturn("Successful export of Community", false, true);
		else
			return Utilities.displayAndLogMessageWithReturn("Error: " + exporter.getMessage(), true, false);
	}

	public boolean exportPartnerProfile(String partnerProfileName)
	{
		PropertiesFile pf = PropertiesFile.getInstance();
		ProfileExport pe = new ProfileExport();
		String exportDirectory = pf.getExportDirectory();
		File dir = new File(exportDirectory);
		if (!dir.exists() && !dir.mkdirs() && !dir.isDirectory())
			return Utilities.displayAndLogMessageWithReturn("Error: Invalid directory name for EXPORT_DIR ["+exportDirectory+"]", true, false);
		if (partnerProfileName != null)
		{
			if (pe.exportPartnerProfiles(dir, partnerProfileName))
				return Utilities.displayAndLogMessageWithReturn("Successful export of Partner Profile", false, true);
			else
				return Utilities.displayAndLogMessageWithReturn("Error: " + pe.getMessage(), true, false);
		}
		else
			return Utilities.displayAndLogMessageWithReturn("Error: partnerProfileName parameter was null", true, false);
	}

	public boolean deleteProfile(String profileName, boolean isCommunityProfile)
	{
		String partyType = (isCommunityProfile) ? "Community" : "Partner";
		ProfileDelete pd = new ProfileDelete();
		if (profileName != null)
		{
			if (pd.deleteProfiles(profileName))
				return Utilities.displayAndLogMessageWithReturn("Successful delete of " + partyType + " Profile: " + profileName, false, true);
			else
				return Utilities.displayAndLogMessageWithReturn("Error: " + pd.getMessage(), true, false);
		}
		else
			return Utilities.displayAndLogMessageWithReturn("Error: " + partyType + " name parameter was null", true, false);
	}

	public boolean importProfile(File xmlFile, String organizationName, boolean isCommunityProfile)
	{
		Utilities.displayAndLogMessage("Importing Profile for: " + organizationName, false);
		ProfileImport pi = new ProfileImport();
		try
		{
			pi.importProfile(xmlFile, organizationName, isCommunityProfile);
		}
		catch (Exception ex)
		{
			return Utilities.displayAndLogErrorWithReturn("Exception: " + ex.getMessage(), ex, false);
		}
		String message = isCommunityProfile ? "Successful import of Community Profile: " : "Successful import of Partner Profile: ";
		return Utilities.displayAndLogMessageWithReturn(message + organizationName, false, true);
	}

}
