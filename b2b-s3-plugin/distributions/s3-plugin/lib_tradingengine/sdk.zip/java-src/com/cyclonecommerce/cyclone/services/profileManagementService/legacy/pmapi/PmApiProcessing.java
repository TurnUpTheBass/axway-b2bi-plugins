// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dom4j.io.DOMReader;
import org.w3c.dom.Element;

import java.io.File;

public class PmApiProcessing
{
	private static final Logger logger = LogManager.getLogger(PmApiProcessing.class);

	public PmApiProcessing()
	{
	}

	public boolean processCommand(CommandAndDocument doc)
	{
		if (doc == null)
			return Utilities.displayAndLogMessageWithReturn("Error: command is null", true, false);

		String command = doc.getCommand();
		if (
				Constants.DEL_APPLICATION_DELIVERY.equalsIgnoreCase(command) ||
				Constants.DEL_APPLICATION_PICKUP.equalsIgnoreCase(command) ||
				Constants.DEL_INTEGRATION_DELIVERY.equalsIgnoreCase(command) ||
				Constants.DEL_INTEGRATION_PICKUP.equalsIgnoreCase(command) ||
				Constants.DEL_METADATA.equalsIgnoreCase(command) ||
				Constants.DEL_METADATA_TEMPLATE.equalsIgnoreCase(command) ||
				Constants.GET_APPLICATION_DELIVERY.equalsIgnoreCase(command) ||
				Constants.GET_APPLICATION_PICKUP.equalsIgnoreCase(command) ||
				Constants.GET_APPLICATION_EXTENSION_PROFILE.equalsIgnoreCase(command) ||
				Constants.GET_DEFAULT_COLLABORATION_SETTINGS.equalsIgnoreCase(command) ||
				Constants.GET_DOCUMENT_SERVICE.equalsIgnoreCase(command) ||
				Constants.GET_E_INVOICE_SERVICE.equalsIgnoreCase(command) ||
				Constants.GET_INTEGRATION_DELIVERY.equalsIgnoreCase(command) ||
				Constants.GET_INTEGRATION_PICKUP.equalsIgnoreCase(command) ||
				Constants.GET_MESSAGE_HANDLER.equalsIgnoreCase(command) ||
				Constants.GET_METADATA.equalsIgnoreCase(command) ||
				Constants.GET_METADATA_PROFILE.equalsIgnoreCase(command) ||
				Constants.GET_METADATA_TEMPLATE.equalsIgnoreCase(command) ||
				Constants.GET_PROPERTY_TEMPLATE.equalsIgnoreCase(command) ||
				Constants.GET_PROCESSING_STEP.equalsIgnoreCase(command) ||
				Constants.GET_SENTINEL_INTEGRATION_CONFIG.equalsIgnoreCase(command) ||
				Constants.GET_AGREEMENT_PROFILE.equalsIgnoreCase(command) ||
				Constants.SET_APPLICATION_DELIVERY.equalsIgnoreCase(command) ||
				Constants.SET_APPLICATION_PICKUP.equalsIgnoreCase(command) ||
				Constants.SET_APPLICATION_EXTENSION_PROFILE.equalsIgnoreCase(command) ||
				Constants.SET_DEFAULT_COLLABORATION_SETTINGS.equalsIgnoreCase(command) ||
				Constants.SET_DOCUMENT_SERVICE.equalsIgnoreCase(command) ||
				Constants.SET_E_INVOICE_SERVICE.equalsIgnoreCase(command) ||
				Constants.SET_ENTIRE_SYSTEM_IMPORT.equalsIgnoreCase(command) ||
				Constants.SET_INTEGRATION_DELIVERY.equalsIgnoreCase(command) ||
				Constants.SET_INTEGRATION_PICKUP.equalsIgnoreCase(command) ||
				Constants.SET_MESSAGE_HANDLER.equalsIgnoreCase(command) ||
				Constants.SET_METADATA.equalsIgnoreCase(command) ||
				Constants.SET_METADATA_PROFILE.equalsIgnoreCase(command) ||
				Constants.SET_METADATA_TEMPLATE.equalsIgnoreCase(command) ||
				Constants.SET_PROPERTY_TEMPLATE.equalsIgnoreCase(command) ||
				Constants.SET_PROCESSING_STEP.equalsIgnoreCase(command) ||
				Constants.SET_SENTINEL_INTEGRATION_CONFIG.equalsIgnoreCase(command) ||
				Constants.SET_AGREEMENT_PROFILE.equalsIgnoreCase(command)
			)
			return execute(doc);
		else
		{
			return Utilities.displayAndLogMessageWithReturn("Error: command ["+command+"] doesn't match a valid command constant", true, false);
		}
	}

	private boolean execute(CommandAndDocument doc)
	{
		boolean returnValue;
		OrganizationDataOutput[] output = pushCommand(doc);
		if (output == null)
			returnValue = Utilities.displayAndLogMessageWithReturn("Error when processing command: " + doc.getCommand(), true, false);
		else if (output.length == 1)
		{
			String id = output[0].getDisposition().getId();
			if (!id.startsWith("0"))
			{
				returnValue = Utilities.displayAndLogMessageWithReturn(
					"Bad Disposition code returned: " + id + " for " + doc.getCommand(), true, false);
				String title = output[0].getDisposition().getTitle();
				if (!StringUtils.isBlank(title))
					Utilities.displayAndLogMessage("Error: " + title, true);//'returnValue' is already set correctly to false.
			}
			else
			{
				Element data = output[0].getOrganizationData();
				if (data != null)
				{
					PropertiesFile pf = PropertiesFile.getInstance();
					String exportDirectory = pf.getExportDirectory();
					File dir = new File(exportDirectory);
					if (!dir.exists() && !dir.mkdirs() && !dir.isDirectory())
						returnValue = Utilities.displayAndLogMessageWithReturn("Error: Invalid directory name for EXPORT_DIR ["+exportDirectory+"]", true, false);
					else
					{
						String fileNameAndPath = "";
						try
						{
							fileNameAndPath = Utilities.writeProfile(dir, data, doc.getCommand());
						}
						catch (Exception e)
						{
							Utilities.displayAndLogError("Error writing profile", e);
						}
						// For now, we only validate on ProcessingStep because it's the only element configured in the CycloneOrganizationProfile schema
						if (Constants.GET_PROCESSING_STEP.equalsIgnoreCase(doc.getCommand()))
						{
							// Convert w3c Doc to dom4j doc for validation purposes
							DOMReader domReader = new DOMReader();
							org.w3c.dom.Document w3cDoc = data.getOwnerDocument();
							org.dom4j.Document dom4jDoc = domReader.read(w3cDoc);
							doc.setHostReturnedDoc(dom4jDoc);
							Utilities.addGetCommandDocument(doc);
						}
						returnValue = Utilities.displayAndLogMessageWithReturn("Data returned for command " + doc.getCommand() + " in " + fileNameAndPath, false, true);
					}
				}
				else
				{
					returnValue = Utilities.displayAndLogMessageWithReturn("Disposition OK for " + doc.getCommand() + " No data returned", false, true);
					// For now, we only validate on ProcessingStep because it's the only element configured in the CycloneOrganizationProfile schema
					if (Constants.SET_PROCESSING_STEP.equalsIgnoreCase(doc.getCommand()))
						Utilities.addSetCommandDocument(doc);
				}
			}
		}
		else
		{
			Utilities.displayAndLogMessageWithReturn("Invalid size of OrganizationDataOutput returned from host for " + doc.getCommand(), true, false);
			returnValue = false;
		}
		return returnValue;
	}

	private OrganizationDataOutput[] pushCommand(CommandAndDocument doc)
	{
		ClientSession session = null;
		OrganizationDataOutput[] orgOutput = null;
		try
		{
			Utilities.displayAndLogMessage("Sending command: " + doc.getCommand() + " to host", false);

			// initiate session
			PropertiesFile pf = PropertiesFile.getInstance();
			session = Utilities.createSession(pf.getUser(), pf.getPASSWORD(), pf.getURL());

			ProfileManagementApiStub service = new ProfileManagementApiStub(session);
			OrganizationDataInputList orgInputList = new OrganizationDataInputList();
			OrganizationDataInput orgInput = new OrganizationDataInput();

			org.dom4j.Element rootElement = doc.getUserDoc().getRootElement();
			orgInput.setOrganizationData( ElementUtil.toDomElement(rootElement) );

			orgInputList.setOrganizationDataInput(new OrganizationDataInput[]{orgInput});
			// the following line actually send the request to the server
			// The first method executed on the server side is: IDKService.setOrganizationDataEx
			// Put a breakpoint there on the CN node.
			OrganizationDataOutputList orgOutputList = service.setOrganizationDataEx(orgInputList);

			if (orgOutputList == null)
				throw new InvalidRemoteResponseException("The setOrganizationData response did not return OrganizationDataOutputList as expected.");
			orgOutput = orgOutputList.getOrganizationDataOutput();
			if (orgOutput == null || orgOutput.length == 0)
				throw new InvalidRemoteResponseException("The setOrganizationData response did not return OrganizationDataOutput as expected.");
			Disposition disp = orgOutput[0].getDisposition();
			if (disp == null)
				throw new InvalidRemoteResponseException("The setOrganizationData response did not return Disposition as expected.");

			String id = disp.getId();
			if (id == null || !id.startsWith("0"))
				throw new NegativeDispositionException(disp);
		}
		catch (Exception e)
		{
			logger.error("pushCommand exception", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return orgOutput;
	}

}
