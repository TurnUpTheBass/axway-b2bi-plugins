// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import com.axway.util.StringUtil;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationIdList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class ProfileDelete
{
	private static final Logger logger = LogManager.getLogger(ProfileDelete.class);
	private String message;

	public ProfileDelete()
	{
		this.message = null;
	}

	public boolean deleteProfiles(String profileName)
	{
		try
		{
			PropertiesFile pf = PropertiesFile.getInstance();
			ClientSession session = Utilities.createSession(pf.getUser(), pf.getPASSWORD(), pf.getURL());
			ProfileManagementApiStub service = new ProfileManagementApiStub(session);
			String orgId = Utilities.getOrganizationId(service, profileName);
			if (StringUtil.isNullEmptyOrBlank(orgId))
			{
				this.message = "Organization " + profileName + " does not exist on host";
				return false;
			}
			List<String> ids = new ArrayList<String>(10);
			ids.add(orgId);
			Utilities.displayAndLogMessage("Deleting profile " + profileName + "  from host.", false);
			deleteProfile(ids, 0);
		}
		catch (Exception e)
		{
			logger.error("Error writing profile", e);
			this.message = e.getMessage();
			return false;
		}
		return true;
	}

	private void deleteProfile(List<String> orgIds, int index)
		throws RemoteException
	{
		OrganizationIdList orgIdList = new OrganizationIdList();
		List<String> tempList = new ArrayList<String>(20);
		for (int i = 0; i < 20; i++)
		{
			tempList.add(orgIds.get(index++));
			if (index == orgIds.size())
				break;
		}
		String[] ids = new String[tempList.size()];
		tempList.toArray(ids);
		orgIdList.setOrganizationIds(ids);

		ClientSession session = null;
		try
		{
			PropertiesFile pf = PropertiesFile.getInstance();
			session = Utilities.createSession(pf.getUser(), pf.getPASSWORD(), pf.getURL());
			ProfileManagementApiStub api = new ProfileManagementApiStub(session);
			OrganizationDataOutputList odol = api.removeOrganizationEx(orgIdList);
			OrganizationDataOutput[] orgOutput = odol.getOrganizationDataOutput();
			for (OrganizationDataOutput organizationDataOutput : orgOutput)
			{
				if (organizationDataOutput.getDisposition() == null)
				{
					org.w3c.dom.Element orgProfileElem = organizationDataOutput.getOrganizationData();
				}
			}
		}
		finally
		{
			if (session != null)
				session.close();
		}
	}

	public String getMessage()
	{
		return message;
	}

}
