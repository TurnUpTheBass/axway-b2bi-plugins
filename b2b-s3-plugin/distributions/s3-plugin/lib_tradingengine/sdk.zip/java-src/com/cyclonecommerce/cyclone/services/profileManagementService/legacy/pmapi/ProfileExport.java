// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import com.axway.util.StringUtil;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Cursor;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.CommunityManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Community;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Subscription;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.SubscriptionQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.SubscriptionQueryResult;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationIdList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.DOMReader;
import org.dom4j.io.SAXReader;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class ProfileExport
{
	private static final Logger logger = LogManager.getLogger(ProfileExport.class);

	private String message;

	public ProfileExport()
	{
		this.message = null;
	}

	public boolean exportPartnerProfiles(File outputDir, String partnerProfileName)
	{
		try
		{
			PropertiesFile pf = PropertiesFile.getInstance();
			ClientSession session = Utilities.createSession(pf.getUser(), pf.getPASSWORD(), pf.getURL());
			ProfileManagementApiStub service = new ProfileManagementApiStub(session);
			String orgId = Utilities.getOrganizationId(service, partnerProfileName);
			if (StringUtil.isNullEmptyOrBlank(orgId))
			{
				this.message = "Organization " + partnerProfileName + " does not exist on host";
				return false;
			}
			List<String> ids = new ArrayList<String>(10);
			ids.add(orgId);
			Utilities.displayAndLogMessage("Writing profile " + partnerProfileName + " to disk.", false);
			String encoded = partnerProfileName.replace(' ', '_');
			encoded = URLEncoder.encode(encoded, "UTF-8");
			File profileDir = new File(outputDir, encoded);
			if (!profileDir.exists() && !profileDir.mkdirs())
				Utilities.displayAndLogMessage("error creating directory ["+profileDir.getAbsolutePath()+"]", false);
			persistProfiles(profileDir, ids);
		}
		catch (Exception e)
		{
			logger.error("Error exporting partner profiles", e);
			this.message = e.getMessage();
			return false;
		}
		return true;
	}

	public void exportCommunityProfiles(File outputDir, Community community, boolean exportAsCommunityProfile)
		throws IOException, TransformerException, DocumentException
	{
		Utilities.displayAndLogMessage("Writing community profiles to disk.", false);
		String commName = community.getCommunityName();
		Utilities.displayAndLogMessage("exportCommunityProfiles for community ["+commName+"]", false);
		String encoded = commName.replace(' ', '_');
		encoded = URLEncoder.encode(encoded, "UTF-8");
		File commDir = new File(outputDir, encoded);
		if (!commDir.exists() && !commDir.mkdirs())
			Utilities.displayAndLogMessage("error creating directory ["+commDir.getAbsolutePath()+"]", false);
		if (exportAsCommunityProfile)
			persistCommunityProfile(commDir, community);
		else
			persistProfiles(commDir, getCommunityOrganizationIds(community));
	}

	protected void persistCommunityProfile(File outputDir, Community community)
		throws IOException, TransformerException, DocumentException
	{
		ClientSession session = null;
		try
		{
			Element profileElement = loadCommunityProfileRequest();
			if (profileElement == null )
			{
				Utilities.displayAndLogMessage("Profile request xml does not exist", true);
				return;
			}
			PropertiesFile pf = PropertiesFile.getInstance();
			session = Utilities.createSession(pf.getUser(), pf.getPASSWORD(), pf.getURL());
			ProfileManagementApiStub api = new ProfileManagementApiStub(session);
			OrganizationDataInput orgDataInput = new OrganizationDataInput();
			orgDataInput.setOrganizationId(community.getCommunityId());
			orgDataInput.setOrganizationData(ElementUtil.toDomElement(profileElement));

			OrganizationDataInputList orgDataInputList = new OrganizationDataInputList();
			orgDataInputList.setOrganizationDataInput(new OrganizationDataInput[]{orgDataInput});

			OrganizationDataOutputList ol = api.getOrganizationDataEx2(orgDataInputList, Constants.INTERCHANGE_COMMUNITY_PROFILE);
			OrganizationDataOutput[] orgOutput = ol.getOrganizationDataOutput();
			for (OrganizationDataOutput organizationDataOutput : orgOutput)
			{
				if (organizationDataOutput.getDisposition() == null)
				{
					org.w3c.dom.Element orgProfileElem = organizationDataOutput.getOrganizationData();
					// Convert w3c Doc to dom4j doc for validation purposes
					DOMReader domReader = new DOMReader();
					org.w3c.dom.Document w3cDoc = orgProfileElem.getOwnerDocument();
					org.dom4j.Document dom4jDoc = domReader.read(w3cDoc);
					Element adminInfoElement = Utilities.getElement(dom4jDoc.getRootElement(), Constants.ADMINISTRATIVE_INFO);
					if (adminInfoElement == null)
						throw new DocumentException("AdministrativeInfo element not found in exported Document from host");
					String organizationName = Utilities.getOrganizationName(adminInfoElement, Constants.ORGANIZATION_NAME);
					if (organizationName == null)
						throw new DocumentException("Organization name not found in AdministrativeInfo element exported from host");

					Utilities.putExportedOrganizations(organizationName, dom4jDoc, true);
					String fileNameAndPath = Utilities.writeProfile(outputDir, orgProfileElem, "CommunityProfileExport");
					Utilities.displayAndLogMessage("Data returned for command CommunityProfileExport in " + fileNameAndPath, false);
				}
				else
				{
					String dispositionTitle = organizationDataOutput.getDisposition().getTitle();
					throw new RemoteException(dispositionTitle);
				}
			}
		}
		finally
		{
			if (session != null)
				session.close();
		}
	}

	private void persistProfiles(File outputDir, List<String> orgIds)
		throws IOException, TransformerException, DocumentException
	{
		OrganizationIdList orgIdList = new OrganizationIdList();
		String[] ids = new String[orgIds.size()];
		orgIds.toArray(ids);
		orgIdList.setOrganizationIds(ids);

		ClientSession session = null;
		try
		{
			PropertiesFile pf = PropertiesFile.getInstance();
			session = Utilities.createSession(pf.getUser(), pf.getPASSWORD(), pf.getURL());
			ProfileManagementApiStub api = new ProfileManagementApiStub(session);
			OrganizationDataOutputList ol = api.getOrganizationDataEx(orgIdList, Constants.ORGANIZATION_FORMAT);
			OrganizationDataOutput[] orgOutput = ol.getOrganizationDataOutput();
			for (OrganizationDataOutput organizationDataOutput : orgOutput)
			{
				if (organizationDataOutput.getDisposition() == null)
				{
					org.w3c.dom.Element orgProfileElem = organizationDataOutput.getOrganizationData();
					// Convert w3c Doc to dom4j doc for validation purposes
					DOMReader domReader = new DOMReader();
					org.w3c.dom.Document w3cDoc = orgProfileElem.getOwnerDocument();
					org.dom4j.Document dom4jDoc = domReader.read(w3cDoc);
					Element adminInfoElement = Utilities.getElement(dom4jDoc.getRootElement(), Constants.ADMINISTRATIVE_INFO);
					if (adminInfoElement == null)
						throw new DocumentException("AdministrativeInfo element not found in exported Document from host");
					String organizationName = Utilities.getOrganizationName(adminInfoElement, Constants.ORGANIZATION_NAME);
					if (organizationName == null)
						throw new DocumentException("Organization name not found in AdministrativeInfo element exported from host");
					Utilities.putExportedOrganizations(organizationName, dom4jDoc, false);
					String fileNameAndPath = Utilities.writeProfile(outputDir, orgProfileElem, "PartnerProfileExport");
					Utilities.displayAndLogMessage("Data returned for command PartnerProfileExport in " + fileNameAndPath, false);
				}
				else
				{
					String dispositionTitle = organizationDataOutput.getDisposition().getTitle();
					throw new RemoteException(dispositionTitle);
				}
			}
		}
		finally
		{
			if (session != null)
				session.close();
		}
	}

	private List<String> getCommunityOrganizationIds(Community community)
		throws RemoteException
	{
		List<String> ids = new ArrayList<String>(1000);
		Cursor cursor;
		SubscriptionQuery query = new SubscriptionQuery();
		query.setCommunityIds(new String[]{community.getCommunityId()});
//		query.setSubscriptionStates(new String[]{"Active"});  // todo check this
		do
		{
			SubscriptionQueryResult result = getOrganizationIds(query);
			Subscription[] subscriptions = result.getSubscriptions();
			for (Subscription subscription : subscriptions)
			{
				String orgId = subscription.getOrganizationId();
				if (orgId != null && !orgId.equals(community.getBrokerId()))
					ids.add(orgId);
			}
			cursor = result.getCursor();
			if (cursor != null)
			{
				query = new SubscriptionQuery();
				query.setCursor(cursor);
			}
		}
		while (cursor != null);

		return ids;
	}

	private SubscriptionQueryResult getOrganizationIds(SubscriptionQuery query)
		throws RemoteException
	{
		ClientSession session = null;
		try
		{
			PropertiesFile pf = PropertiesFile.getInstance();
			session = Utilities.createSession(pf.getUser(), pf.getPASSWORD(), pf.getURL());
			CommunityManagementApiStub service = new CommunityManagementApiStub(session);
			return service.findSubscriptionsEx(query);
		}
		finally
		{
			if (session != null)
				session.close();
		}
	}

	private Element loadCommunityProfileRequest()
		throws IOException, DocumentException
	{
		String profileRequestFilename = PropertiesFile.getInstance().getExportImportValue(Constants.COMMUNITY_REQUEST_FILENAME);
		if (profileRequestFilename == null)
			throw new DocumentException("No profile request xml defined");

		File profileRequestFile = new File(profileRequestFilename);
		if (!profileRequestFile.exists())
			throw new DocumentException("No profile request xml file exists, this is a mandatory file: "+profileRequestFilename);

		FileInputStream fis = null;
		Element rootElement = null;
		try
		{
			fis = new FileInputStream(profileRequestFile);
			SAXReader reader = new SAXReader();
			reader.setValidation(false);
			Document profileDocument = reader.read(fis);

			rootElement = Utilities.getInterChangeCommunityProfileRootElement(profileDocument, null);
		}
		finally
		{
			if (fis != null)
			{
				fis.close();
			}
		}
		return rootElement;
	}

	public String getMessage()
	{
		return message;
	}

}
