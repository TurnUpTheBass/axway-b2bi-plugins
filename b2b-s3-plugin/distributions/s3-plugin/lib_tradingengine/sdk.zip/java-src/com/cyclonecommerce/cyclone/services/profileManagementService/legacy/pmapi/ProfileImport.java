// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.rmi.RemoteException;

/**
 * This utility uploads an Interchange Partner Profile an IDK enabled Interchange server.
 *
 * @author Bob Krier
 */
public class ProfileImport
{
	public ProfileImport()
	{
	}

	/**
	 * Uploads a Interchange Community (ICP)Profile or Interchange Partner Profile (IPP) to the Interchange server.
	 *
	 * @param file		  a {@link File} to the IPP XML on disk.
	 * @param communityName optional, if specified subscribes the partner profile to the community after the push.
	 * @param isCommunityProfile specifies if the profile is community profile or partner profile.
	 * @throws IOException
	 * @throws DocumentException
	 * @throws NegativeDispositionException   if the server returns a {@link Disposition} which is not known to
	 *                                        be a success.
	 * @throws InvalidRemoteResponseException if the server returns a SOAP response which is not expected.
	 */
	public void importProfile(File file, String communityName, boolean isCommunityProfile)
			throws IOException, DocumentException, NegativeDispositionException, InvalidRemoteResponseException
	{
		FileInputStream fis = null;
		try
		{
			fis = new FileInputStream(file);
			readFile(fis, communityName, isCommunityProfile);
		}
		finally
		{
			if (fis != null)
			{
				fis.close();
			}
		}
	}

	/**
	 * Uploads a Interchange Community (ICP)Profile or Interchange Partner Profile (IPP) to the Interchange server.
	 *
	 * @param is			a {@link InputStream} to the source of the IPP.
	 * @param communityName optional, if specified subscribes the profile to the community after the push.
	 * @param isCommunityProfile specifies if the profile is community profile or partner profile.
	 * @throws IOException
	 * @throws DocumentException
	 * @throws NegativeDispositionException   if the server returns a {@link Disposition} which is not known to
	 *                                        be a success.
	 * @throws InvalidRemoteResponseException if the server returns a SOAP response which is not expected.
	 */
	public void readFile(InputStream is, String communityName, boolean isCommunityProfile)
			throws IOException, DocumentException, NegativeDispositionException, InvalidRemoteResponseException

	{
		SAXReader reader = new SAXReader();
		reader.setValidation(false);
		Document profileDocument = reader.read(is);
		// The Document and Org name should be OK since they were verified upon startup
		Element rootElement = Utilities.getProfileRootElement(profileDocument, null, isCommunityProfile);
		Element adminInfoElement = Utilities.getElement(rootElement, Constants.ADMINISTRATIVE_INFO);
		String organizationName = Utilities.getOrganizationName(adminInfoElement, Constants.ORGANIZATION_NAME);
		pushProfile(profileDocument, communityName, organizationName, isCommunityProfile);
	}

	public void pushProfile(Document profileDocument, String partnerName, String organizationName, boolean isCommunityProfile)
			throws RemoteException, NegativeDispositionException, InvalidRemoteResponseException
	{
		ClientSession session = null;
		try
		{
			PropertiesFile pf = PropertiesFile.getInstance();
			session = Utilities.createSession(pf.getUser(), pf.getPASSWORD(), pf.getURL());
			org.w3c.dom.Element ippElement = ElementUtil.toDomElement(profileDocument.getRootElement());
			ProfileManagementApiStub service = new ProfileManagementApiStub(session);

			OrganizationDataInputList orgInputList = new OrganizationDataInputList();
			OrganizationDataInput orgInput = new OrganizationDataInput();
			orgInput.setOrganizationId(Utilities.getOrganizationId(service, partnerName));

			orgInput.setOrganizationData(ippElement);
			orgInputList.setOrganizationDataInput(new OrganizationDataInput[]{orgInput});
			OrganizationDataOutputList orgOutputList = service.setOrganizationDataEx(orgInputList);
			if (orgOutputList == null)
				throw new InvalidRemoteResponseException("The setOrganizationData response did not return OrganizationDataOutputList as expected.");

			OrganizationDataOutput[] orgOutput = orgOutputList.getOrganizationDataOutput();
			if (orgOutput == null || orgOutput.length == 0)
				throw new InvalidRemoteResponseException("The setOrganizationData response did not return OrganizationDataOutput as expected.");

			Disposition disp = orgOutput[0].getDisposition();
			if (disp == null)
				throw new InvalidRemoteResponseException("The setOrganizationData response did not return Disposition as expected.");

			String id = disp.getId();
			if (id == null || !id.startsWith("0"))
				throw new NegativeDispositionException(disp);
			// only add if the import was successful
			Utilities.putImportedOrganization(organizationName, profileDocument, isCommunityProfile);
		}
		finally
		{
			if (session != null)
				session.close();
		}
	}

}
