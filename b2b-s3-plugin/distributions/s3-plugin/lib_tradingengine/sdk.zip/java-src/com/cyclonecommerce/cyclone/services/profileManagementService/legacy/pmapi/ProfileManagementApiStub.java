// Copyright (c) $smartDate Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Cursor;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.InvalidFormatException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.InvalidQueryException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.ServerException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationIdList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationState;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.QueryResult;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.SearchBy;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.SortBy;

import org.apache.axis.description.OperationDesc;

import java.rmi.RemoteException;

public class ProfileManagementApiStub extends ClientStub
{
    private ClientSession session;

    public ProfileManagementApiStub(ClientSession session)
    {
        this.session = session;
    }

    public org.w3c.dom.Element findOrganizations(org.w3c.dom.Element element)
        throws RemoteException, AuthenticationException, InvalidQueryException, ServerException
    {
        return (org.w3c.dom.Element)executeWithResponse(operations[0], element);
    }

    public QueryResult findOrganizationsEx(OrganizationQuery organizationQuery)
        throws RemoteException, AuthenticationException, InvalidQueryException, ServerException
    {
        return (QueryResult)executeWithResponse(operations[1], organizationQuery);
    }

     public org.w3c.dom.Element getOrganizationData(org.w3c.dom.Element element, String formatName)
        throws RemoteException, AuthenticationException, InvalidFormatException, ServerException
    {
        return (org.w3c.dom.Element)executeWithResponse(operations[2], element);
    }

    public OrganizationDataOutputList getOrganizationDataEx(OrganizationIdList organizationIdList, String formatName)
        throws RemoteException, AuthenticationException, InvalidFormatException, ServerException
    {
        return (OrganizationDataOutputList)executeWithResponse(operations[3], new Object[] {organizationIdList, formatName});
    }

    public OrganizationDataOutputList getOrganizationDataEx2(OrganizationDataInputList organizationInputList, String formatName)
        throws RemoteException, AuthenticationException, InvalidFormatException, ServerException
    {
        return (OrganizationDataOutputList)executeWithResponse(operations[4], new Object[] {organizationInputList, formatName});
    }

    public org.w3c.dom.Element setOrganizationData(org.w3c.dom.Element element)
        throws RemoteException, AuthenticationException, InvalidFormatException, ServerException
    {
        return (org.w3c.dom.Element)executeWithResponse(operations[5], element);
    }

    public OrganizationDataOutputList setOrganizationDataEx(OrganizationDataInputList organizationDataInputList)
        throws RemoteException, AuthenticationException, InvalidFormatException, ServerException
    {
        return (OrganizationDataOutputList)executeWithResponse(operations[6], organizationDataInputList);
    }

    public org.w3c.dom.Element removeOrganization(org.w3c.dom.Element element)
        throws RemoteException, AuthenticationException, InvalidFormatException, ServerException
    {
        return (org.w3c.dom.Element)executeWithResponse(operations[7], element);
    }

    public OrganizationDataOutputList removeOrganizationEx(OrganizationIdList organizationIdList)
        throws RemoteException, AuthenticationException, InvalidFormatException, ServerException
    {
        return (OrganizationDataOutputList)executeWithResponse(operations[8], organizationIdList);
    }

    protected Object executeWithResponse(OperationDesc operation, Object param)
        throws RemoteException
    {
        return super.executeWithResponse(session, operation, param);
    }

    protected Object executeWithResponse(OperationDesc operation, Object[] params)
        throws RemoteException
    {
        return super.executeWithResponse(session, operation, params);
    }

    protected Class[] getBeanClasses()
    {
        return beanClasses;
    }

    static Class[] beanClasses;

    static
    {
        beanClasses = new Class[12];
        beanClasses[0] = Cursor.class;
        beanClasses[1] = Disposition.class;
        beanClasses[2] = SearchBy.class;
        beanClasses[3] = SortBy.class;
        beanClasses[4] = OrganizationState.class;
        beanClasses[5] = OrganizationQuery.class;
        beanClasses[6] = QueryResult.class;
        beanClasses[7] = OrganizationIdList.class;
        beanClasses[8] = OrganizationDataInput.class;
        beanClasses[9] = OrganizationDataInputList.class;
        beanClasses[10] = OrganizationDataOutput.class;
        beanClasses[11] = OrganizationDataOutputList.class;
    }

    static OperationDesc[] operations;

    static
    {
        operations = new OperationDesc[9];
        initOperationDesc();
    }

    private static void initOperationDesc()
    {
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findOrganizations");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "element"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"), org.w3c.dom.Element.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"));
        oper.setReturnClass(org.w3c.dom.Element.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findOrganizationsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidQueryException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidQueryException"),
                true));
        operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findOrganizationsEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "organizationQuery"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.cyclonecommerce.com/ProfileManagementAPI", "OrganizationState"), OrganizationState.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.cyclonecommerce.com/ProfileManagementAPI", "QueryResult"));
        oper.setReturnClass(QueryResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findOrganizationsExReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidQueryException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidQueryException"),
                true));
        operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getOrganizationData");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "element"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"), org.w3c.dom.Element.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "formatName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"));
        oper.setReturnClass(org.w3c.dom.Element.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getOrganizationDataReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidFormatException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidFormatException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getOrganizationDataEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "organizationIdList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.cyclonecommerce.com/ProfileManagementAPI", "OrganizationIdList"), OrganizationIdList.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "formatName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.cyclonecommerce.com/ProfileManagementAPI", "OrganizationDataOutputList"));
        oper.setReturnClass(OrganizationDataOutputList.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getOrganizationDataExReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidFormatException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidFormatException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getOrganizationDataEx2");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "organizationInputList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.cyclonecommerce.com/ProfileManagementAPI", "OrganizationDataInputList"), OrganizationDataInputList.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "formatName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.cyclonecommerce.com/ProfileManagementAPI", "OrganizationDataOutputList"));
        oper.setReturnClass(OrganizationDataOutputList.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getOrganizationDataEx2Return"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidFormatException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidFormatException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setOrganizationData");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "element"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"), org.w3c.dom.Element.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"));
        oper.setReturnClass(org.w3c.dom.Element.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "setOrganizationDataReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidFormatException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidFormatException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        operations[5] = oper;


        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setOrganizationDataEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "organizationDataInputList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.cyclonecommerce.com/ProfileManagementAPI", "OrganizationDataInputList"), OrganizationDataInputList.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.cyclonecommerce.com/ProfileManagementAPI", "OrganizationDataOutputList"));
        oper.setReturnClass(OrganizationDataOutputList.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "setOrganizationDataExReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidFormatException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidFormatException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("removeOrganization");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "element"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"), org.w3c.dom.Element.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xml.apache.org/xml-soap", "Element"));
        oper.setReturnClass(org.w3c.dom.Element.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "removeOrganizationReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidFormatException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidFormatException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("removeOrganizationEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "organizationIdList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.cyclonecommerce.com/ProfileManagementAPI", "OrganizationIdList"), OrganizationIdList.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.cyclonecommerce.com/ProfileManagementAPI", "OrganizationDataOutputList"));
        oper.setReturnClass(OrganizationDataOutputList.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "removeOrganizationExReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.ServerException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "ServerException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.InvalidFormatException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "InvalidFormatException"),
                true));
        oper.addFault(new org.apache.axis.description.FaultDesc(new javax.xml.namespace.QName("http://localhost:6080/cyclone/services/legacy/idk", "fault"),
                "com.cyclonecommerce.pmapi.client.AuthenticationException",
                new javax.xml.namespace.QName("http://faults.legacy.profileManagementService.idk.cyclonecommerce.com", "AuthenticationException"),
                true));
        operations[8] = oper;

    }

}
