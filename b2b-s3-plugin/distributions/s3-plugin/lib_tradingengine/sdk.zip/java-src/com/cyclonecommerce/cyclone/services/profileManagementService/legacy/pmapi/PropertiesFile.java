// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import com.axway.util.StringUtil;

import javax.xml.bind.PropertyException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class PropertiesFile
{
	private String URL;
	private String USER;
	private String PASSWORD;
	private String propertiesFileName;
	private String exportDirectory;
	private Map<String, String> exportImportValues = new LinkedHashMap<>();

	private static PropertiesFile instance;

	public static synchronized PropertiesFile getInstance()
	{
		if (instance == null)
		{
			Utilities.displayAndLogMessage("creating new PropertiesFile object...", false);
			instance = new PropertiesFile();
		}
    	return instance;
	}

	public boolean readPropertiesFile()
			throws IOException, PropertyException
	{
		Properties properties = new Properties();
		File propertiesFile = new File(propertiesFileName);
		if (!propertiesFile.exists())
			throw new FileNotFoundException("PMAPI_TestTool.properties file does not exist: ");
		FileInputStream fis = null;
		try
		{
			fis = new FileInputStream(propertiesFile);
			properties.load(fis);
		}
		finally
		{
			if (fis != null)
				fis.close();
		}
		URL = properties.getProperty(Constants.URL).trim();
		if (StringUtil.isNullEmptyOrBlank(URL))
			throw new PropertyException("Invalid value ["+URL+"] for URL in properties file");
        USER = properties.getProperty(Constants.USER).trim();
		if (StringUtil.isNullEmptyOrBlank(USER))
			throw new PropertyException("Invalid value ["+USER+"] for USER in properties file");
		PASSWORD = properties.getProperty("PASSWORD").trim();
		if (StringUtil.isNullEmptyOrBlank(PASSWORD))
            throw new PropertyException("Invalid value for PASSWORD in properties file");
		exportDirectory = properties.getProperty(Constants.EXPORT_DIR).trim();
		if (StringUtil.isNullEmptyOrBlank(exportDirectory))
			throw new PropertyException("Invalid value ["+exportDirectory+"] for EXPORT_DIR in properties file");

		return extractExportImportValues(properties);
	}

	public String getURL()
	{
		return URL;
	}

	public String getUser()
	{
		return USER;
	}

	public String getPASSWORD()
	{
		return PASSWORD;
	}

	public String getExportDirectory()
	{
		return exportDirectory;
	}

	public void setPropertiesFileName(String propertiesFileName)
	{
		this.propertiesFileName = propertiesFileName;
	}

	public String getExportImportValue(String key)
	{
		return exportImportValues.get(key);
	}

	public Map<String, String> getExportImportValues()
	{
		return exportImportValues;
	}

	public void setExportImportValues(Map<String, String> values)
	{
		exportImportValues = values;
	}

	private boolean extractExportImportValues(Properties properties)
			throws PropertyException
	{
		Map<String, String> export_import_values = new HashMap<>();
		for (Object obj : properties.keySet())
		{
			String key = (String)obj;
			if
			(
				key.contains(Constants.COMMUNITY_EXPORT_AS_PARTNER_PROFILE) ||
				key.contains(Constants.COMMUNITY_EXPORT_PROFILE) ||
				key.contains(Constants.COMMUNITY_PROFILE_DELETE) ||
				key.contains(Constants.COMMUNITY_PROFILE_IMPORT) ||
				key.contains(Constants.COMMUNITY_REQUEST_FILENAME) ||
				key.contains(Constants.PARTNER_PROFILE_DELETE) ||
				key.contains(Constants.PARTNER_PROFILE_EXPORT) ||
				key.contains(Constants.PARTNER_PROFILE_IMPORT) ||
				key.contains(Constants.DELETE_FILE)||
				key.contains(Constants.GET_FILE) ||
				key.contains(Constants.SET_FILE)
			)
			{
				//get the filename
				String value = properties.getProperty(key).trim();
				if (StringUtil.isNullEmptyOrBlank(value))
					Utilities.displayAndLogMessageWithReturn("\nInvalid value ["+value+"] for key ["+key+"]", true, false);

				//prepend the filename with the directory path
				if (value.endsWith(".xml"))
					value = System.getProperty("axway.qatools.home")+File.separator+"conf"+File.separator+"xml"+File.separator+value;

				export_import_values.put(key, value);
			}
		}

		//sort the export_import_values
		Set<String> keys = export_import_values.keySet();
		String[] keysArray = keys.toArray(new String[keys.size()]);
		Arrays.sort(keysArray);
		Map<String, String> sortedExportImportValues = new LinkedHashMap<>();
		for (String key : keysArray)
			sortedExportImportValues.put(key, export_import_values.get(key));//the HashMap is 'insertion-ordered'

		int size = sortedExportImportValues.size();
		setExportImportValues(sortedExportImportValues);
	    return Utilities.displayAndLogMessageWithReturn("\nFound " + size + " entities for Profile Management API processing", false, true);
	}

}
