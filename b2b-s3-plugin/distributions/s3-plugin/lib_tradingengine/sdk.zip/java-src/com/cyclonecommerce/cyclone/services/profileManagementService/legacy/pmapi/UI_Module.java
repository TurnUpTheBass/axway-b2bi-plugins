// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class UI_Module
	extends WindowAdapter
		implements WindowListener, ActionListener, Runnable
{
	private static final Logger logger = LogManager.getLogger(UI_Module.class);

	public static final String product = "Interchange PMAPI Test Tool Version 1.0";

	private JFrame frame;
	private JMenu fileMenu;
	private JMenu actionMenu;
	private JTextArea textArea;
	private Thread reader;
	private Thread reader2;
	private volatile Thread pmapi_Processing_Thread;
	private PMAPI_Profile_Processing pmapi_profile_processing;
	private PmApiProcessing pmapiProcessing;
	private JMenuItem exportCommunity;
	private JMenuItem exportPartnerProfile;
	private JMenuItem communityProfileImport;
	private JMenuItem partnerProfileImport;
	private JMenuItem communityProfileDelete;
	private JMenuItem partnerProfileDelete;
	private JMenuItem getCommands;
	private JMenuItem setCommands;
	private JMenuItem deleteCommands;
	private final PipedInputStream pin = new PipedInputStream();
	private final PipedInputStream pin2 = new PipedInputStream();

	public UI_Module()
	{
		createGUI();
		addPropertyValuesToMenu();
	}

	private void createGUI()
	{
		try
		{
			UIManager.setLookAndFeel(
			UIManager.getSystemLookAndFeelClassName());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		pmapi_Processing_Thread = null;
		createTheFrame();
		createTheFileMenu();
		JMenuBar menuBar = new JMenuBar();
		menuBar.add(fileMenu);
		createTheActionMenu();
		menuBar.add(actionMenu);

		textArea = new JTextArea();
		textArea.setEditable(false);

		frame.setJMenuBar(menuBar);
		frame.getContentPane().setLayout(new BorderLayout());
		frame.getContentPane().add(new JScrollPane(textArea), java.awt.BorderLayout.CENTER);
		frame.setVisible(true);
		frame.addWindowListener(this);

		redirectSTDOUT_STDERR();

		reader = new Thread(this);
		reader.setDaemon(true);
		reader.start();

		reader2 = new Thread(this);
		reader2.setDaemon(true);
		reader2.start();
	}

	@Override
	public synchronized void windowClosed(WindowEvent evt)
	{
		this.notifyAll(); // stop all threads
		try
		{
			reader.join(1000);
			pin.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			reader2.join(1000);
			pin2.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		System.exit(0);
	}

	@Override
	public synchronized void windowClosing(WindowEvent evt)
	{
		frame.setVisible(false); // default behaviour of JFrame
		frame.dispose();
	}

	public synchronized void actionPerformed(ActionEvent e)
	{
		textArea.setText("");
	}

	private void exportCommunities_actionPerformed(final String[] community, final boolean exportAsCommunityProfile)
	{
		actionMenu.setEnabled(false);
		pmapi_Processing_Thread = new Thread()
		{
			@Override
			public void run()
			{
				pmapi_profile_processing = new PMAPI_Profile_Processing();
				pmapi_profile_processing.exportCommunity(community, exportAsCommunityProfile);
				actionMenu.setEnabled(true);
			}
		};
		pmapi_Processing_Thread.start();
	}

	private void exportPartnerProfile_actionPerformed(final String partnerProfileName)
	{
		actionMenu.setEnabled(false);
		pmapi_Processing_Thread = new Thread()
		{
			@Override
			public void run()
			{
				pmapi_profile_processing = new PMAPI_Profile_Processing();
				pmapi_profile_processing.exportPartnerProfile(partnerProfileName);
				actionMenu.setEnabled(true);
			}
		};
		pmapi_Processing_Thread.start();
	}

	private void deleteProfile_actionPerformed(final String profileName, final boolean isCommunityProfile)
	{
		actionMenu.setEnabled(false);
		pmapi_Processing_Thread = new Thread()
		{
			@Override
			public void run()
			{
				pmapi_profile_processing = new PMAPI_Profile_Processing();
				List<String> validatedKeys = new ArrayList<String>();
				if (pmapi_profile_processing.deleteProfile(profileName, isCommunityProfile))
				{
					validatedKeys.add(profileName);
					Utilities.removeOrganizations(validatedKeys, isCommunityProfile);
				}
				actionMenu.setEnabled(true);
			}
		};
		pmapi_Processing_Thread.start();
	}

	private void processCommand_actionPerformed(final CommandAndDocument doc)
	{
		actionMenu.setEnabled(false);
		pmapi_Processing_Thread = new Thread()
		{
			@Override
			public void run()
			{
				pmapiProcessing = new PmApiProcessing();
				if (pmapiProcessing.processCommand(doc) && doc.getCommand().equalsIgnoreCase(Constants.GET_PROCESSING_STEP))
				{
					Utilities.validateCommands();
					Utilities.clearGetCommandDocuments();
					Utilities.clearSetCommandDocuments();
				}
				actionMenu.setEnabled(true);
			}
		};
		pmapi_Processing_Thread.start();
	}

	private void profileImport_actionPerformed(final File xmlFile, final String organizationName, final boolean isCommunityProfile)
	{
		actionMenu.setEnabled(false);
		pmapi_Processing_Thread = new Thread()
		{
			@Override
			public void run()
			{
				pmapi_profile_processing = new PMAPI_Profile_Processing();
				pmapi_profile_processing.importProfile(xmlFile, organizationName, isCommunityProfile);
				actionMenu.setEnabled(true);
			}
		};
		pmapi_Processing_Thread.start();
	}

	private void exitMenuItem_actionPerformed(ActionEvent e)
	{
		if (logger.isDebugEnabled())
			logger.debug("exiting: "+(e == null ? null : e.getActionCommand()));
		System.exit(0);
	}

	public synchronized void run()
	{
		try
		{
			while (Thread.currentThread() == reader)
			{
				try
				{
					this.wait(100);
				}
				catch (InterruptedException ie)
				{
					ie.printStackTrace();
				}

				if (pin.available() != 0)
				{
					String input = this.readLine(pin);
					textArea.append(input);
				}

				//Lets not add more than 500 lines cause it would get outta control real quick
				if (textArea.getLineCount() >500)
				{
					textArea.setText("");
				}
			}
			while (Thread.currentThread() == reader2)
			{
				try
				{
					this.wait(100);
				}
				catch (InterruptedException ie)
				{
					ie.printStackTrace();
				}
				if (pin2.available() != 0)
				{
					String input = this.readLine(pin2);
					textArea.append(input);
				}

			}
		}
		catch (Exception e)
		{
			textArea.append("\nConsole reports an Internal error.");
			textArea.append("The error is: " + e);
		}
 	}

	private synchronized String readLine(PipedInputStream in)
		throws IOException
	{
		StringBuilder buffer = new StringBuilder();
		do
		{
			int available = in.available();

			if (available == 0)
				break;

			byte[] b = new byte[available];
			int totalBytesRead = in.read(b);
			if (logger.isDebugEnabled())
				logger.debug("read ["+totalBytesRead+"] bytes of available ["+available+"] bytes in the input stream");
			buffer.append(new String(b, 0, b.length));

		} while (!buffer.toString().endsWith("\n") && !buffer.toString().endsWith("\r\n"));

		return buffer.toString();
	}

	private void addPropertyValuesToMenu()
	{
		addImportProfilesToMenu(communityProfileImport, Constants.COMMUNITY_PROFILE_IMPORT);
		addExportCommunitiesToMenu();
		addDeleteProfilesToMenu(communityProfileDelete, Constants.COMMUNITY_PROFILE_DELETE);

		addImportProfilesToMenu(partnerProfileImport, Constants.PARTNER_PROFILE_IMPORT);
		addExportPartnerProfilesToMenu();
		addDeleteProfilesToMenu(partnerProfileDelete, Constants.PARTNER_PROFILE_DELETE);

		addSetCommands();
		addGetCommands();
		addDeleteCommands();
	}

	private void addExportCommunitiesToMenu()
	{
		JMenu commAsCommunityProfile = new JMenu(Constants.UI_EXPORT_COMMUNITIES_AS_COMMUNITY_PROFILE);
		exportCommunity.add(commAsCommunityProfile);
		addExportCommunitiesToMenuEx(commAsCommunityProfile, Constants.COMMUNITY_EXPORT_PROFILE);

		JMenu commAsPartnerProfile = new JMenu(Constants.UI_EXPORT_COMMUNITIES_AS_PARTNER_PROFILE);
		exportCommunity.add(commAsPartnerProfile);
		addExportCommunitiesToMenuEx(commAsPartnerProfile, Constants.COMMUNITY_EXPORT_AS_PARTNER_PROFILE);
	}

	private void addExportCommunitiesToMenuEx(JMenu exportMenu, String exportTypeKey)
	{
		final boolean isExportCommunity = exportTypeKey.equals(Constants.COMMUNITY_EXPORT_PROFILE);
		List<String> exportCommunitiesProfile = Utilities.getProperty(exportTypeKey);
		for(String community : exportCommunitiesProfile)
		{
			JMenuItem comm = new JMenuItem(community);
			exportMenu.add(comm);
			comm.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					String communityName = e.getActionCommand();

					if (isExportCommunity)
						Utilities.displayAndLogMessage("Community: " + communityName + " selected for exporting profile", false);
					else
						Utilities.displayAndLogMessage("Community: " + communityName + " selected for exporting as partner profile", false);

					String[] community = new String[1];
					community[0] = communityName;
					exportCommunities_actionPerformed(community, isExportCommunity);
				}
			});
		}
	}

	private void addExportPartnerProfilesToMenu()
	{
		for (String partnerProfile : Utilities.getProperty(Constants.PARTNER_PROFILE_EXPORT))
		{
			JMenuItem pp = new JMenuItem(partnerProfile);
			exportPartnerProfile.add(pp);
			pp.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					String partnerProfileName = e.getActionCommand();
					Utilities.displayAndLogMessage("Partner Profile: " + partnerProfileName + " selected for exporting", false);
					exportPartnerProfile_actionPerformed(partnerProfileName);
				}
			});
		}
	}

	private void addDeleteProfilesToMenu(JMenuItem deleteMenu, String profileKey)
	{
		final boolean isCommunityProfile = profileKey.equals(Constants.COMMUNITY_PROFILE_DELETE);
		List<String> profileDeletes = Utilities.getProperty(profileKey);
		for(String aProfileDelete : profileDeletes)
		{
			JMenuItem pd = new JMenuItem(aProfileDelete);
			deleteMenu.add(pd);
			pd.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					String profileName = e.getActionCommand();
					if (isCommunityProfile)
						Utilities.displayAndLogMessage("Community Profile: " + profileName + " selected for delete", false);
					else
						Utilities.displayAndLogMessage("Partner Profile: " + profileName + " selected for delete", false);

					deleteProfile_actionPerformed(profileName, isCommunityProfile);
				}
			});
		}
	}

	private void addImportProfilesToMenu(JMenuItem importMenu, String profileKey)
	{
		final boolean isCommunityProfile = profileKey.equals(Constants.COMMUNITY_PROFILE_IMPORT);
		List<String> profileImports = Utilities.getProperty(profileKey);
		for(String xmlFileName : profileImports)
		{
			final File xmlFile = Utilities.verifyXMLFile(xmlFileName);
			if (xmlFile == null)
				continue;

			Document doc = Utilities.readFile(xmlFile, xmlFileName);
			if (doc == null)
				continue;

			Element rootElement = Utilities.getProfileRootElement(doc, xmlFileName, isCommunityProfile);
			if (rootElement == null)
				continue;

			Element adminInfoElement = Utilities.getElement(rootElement, Constants.ADMINISTRATIVE_INFO);
			if (adminInfoElement == null)
			{
				Utilities.displayAndLogMessage("Error: XML file " + xmlFileName + " invalid: No AdministrativeInfo element found", true);
				continue;
			}
			final String organizationName = Utilities.getOrganizationName(adminInfoElement, Constants.ORGANIZATION_NAME);
			if (organizationName == null)
			{
				if (isCommunityProfile)
					Utilities.displayAndLogMessage("Error: Community Name not found in XML File: " + xmlFileName, true);
				else
					Utilities.displayAndLogMessage("Error: Partner Name not found in XML File: " + xmlFileName, true);
				continue;
			}
			JMenuItem profile = new JMenuItem(organizationName);
			importMenu.add(profile);
			profile.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					profileImport_actionPerformed(xmlFile, organizationName, isCommunityProfile);
				}
			});
		}
	}

	private void addGetCommands()
	{
		for (String aFileName : Utilities.getProperty(Constants.GET_FILE))
		{
			final File xmlFile = Utilities.verifyXMLFile(aFileName);
			if (xmlFile == null)
				continue;
			final Document doc = Utilities.readFile(xmlFile, aFileName);
			if (doc == null)
				continue;
			final String pluggableCommandName = Utilities.getPluggableCommand(doc, aFileName);
			if (pluggableCommandName == null)
				continue;
			final String artifactName = Utilities.findArtifactNameInGetXML(doc);
			String displayName;
			if (artifactName == null)
				displayName = pluggableCommandName;
			else
				displayName = pluggableCommandName + " - " + artifactName;
			JMenuItem jMenuItem = new JMenuItem(displayName);
			getCommands.add(jMenuItem);
			final CommandAndDocument getCommandAndDocument = new CommandAndDocument(pluggableCommandName, doc, artifactName);
			jMenuItem.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					String aActionCommand = e.getActionCommand();
					Utilities.displayAndLogMessage("Command Selected: " + aActionCommand, false);
					processCommand_actionPerformed(getCommandAndDocument);
				}
			});
		}
	}

	private void addSetCommands()
	{
		for (String aFileName : Utilities.getProperty(Constants.SET_FILE))
		{
			final File xmlFile = Utilities.verifyXMLFile(aFileName);
			if (xmlFile == null)
				continue;
			final Document doc = Utilities.readFile(xmlFile, aFileName);
			if (doc == null)
				continue;
			final String pluggableCommandName = Utilities.getPluggableCommand(doc, aFileName);
			if (pluggableCommandName == null)
				continue;
			JMenuItem jMenuItem = new JMenuItem(xmlFile.getName());
			setCommands.add(jMenuItem);
			final CommandAndDocument setCommandAndDocument = new CommandAndDocument(pluggableCommandName, doc, null);
			jMenuItem.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					String aActionCommand = e.getActionCommand();
					Utilities.displayAndLogMessage("Command Selected: " + aActionCommand, false);
					processCommand_actionPerformed(setCommandAndDocument);
				}
			});
		}
	}

	private void addDeleteCommands()
	{
		for (String aFileName : Utilities.getProperty(Constants.DELETE_FILE))
		{
			final File xmlFile = Utilities.verifyXMLFile(aFileName);
			if (xmlFile == null)
				continue;
			final Document doc = Utilities.readFile(xmlFile, aFileName);
			if (doc == null)
				continue;
			final String pluggableCommandName = Utilities.getPluggableCommand(doc, aFileName);
			if (pluggableCommandName == null)
				continue;
			final String artifactNameInGetXML = Utilities.findArtifactNameInGetXML(doc);
			String displayName;
			if (artifactNameInGetXML == null)
				displayName = pluggableCommandName;
			else
				displayName = pluggableCommandName + " - " + artifactNameInGetXML;
			JMenuItem jMenuItem = new JMenuItem(displayName);
			deleteCommands.add(jMenuItem);
			final CommandAndDocument deleteCommandAndDocument = new CommandAndDocument(pluggableCommandName, doc, null);
			jMenuItem.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					String aActionCommand = e.getActionCommand();
					Utilities.displayAndLogMessage("Command Selected: " + aActionCommand, false);
					processCommand_actionPerformed(deleteCommandAndDocument);
				}
			});
		}
	}

	private void createTheFrame()
	{
		frame = new JFrame(product);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = new Dimension(screenSize.width / 2, screenSize.height / 2);
		int x = frameSize.width / 2;
		int y = frameSize.height / 2;
		frame.setBounds(x, y, frameSize.width, frameSize.height);
		frame.addWindowListener(new java.awt.event.WindowAdapter()
		{
				@Override
				public void windowClosing(java.awt.event.WindowEvent evt)
				{
					//exitForm(evt);
				}
		});
	}

	private void createTheFileMenu()
	{
		fileMenu = new JMenu();
		JMenuItem exitMenuItem = new JMenuItem();
		fileMenu.setText(Constants.COMMAND);
		exitMenuItem.setText(Constants.EXIT);
		fileMenu.add(exitMenuItem);
		exitMenuItem.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				exitMenuItem_actionPerformed(e);
			}
		}
		);
	}

	private void createTheActionMenu()
	{
		actionMenu = new JMenu();
		actionMenu.setText(Constants.ACTION);

		communityProfileImport = new JMenu();
		communityProfileImport.setText(Constants.UI_COMMUNITY_PROFILE_IMPORT);
		actionMenu.add(communityProfileImport);

		exportCommunity = new JMenu();
		exportCommunity.setText(Constants.UI_EXPORT_COMMUNITIES);
		actionMenu.add(exportCommunity);

		communityProfileDelete = new JMenu();
		communityProfileDelete.setText(Constants.UI_COMMUNITY_PROFILE_DELETE);
		actionMenu.add(communityProfileDelete);

		partnerProfileImport = new JMenu();
		partnerProfileImport.setText(Constants.UI_PARTNER_PROFILE_IMPORT);
		actionMenu.add(partnerProfileImport);

		exportPartnerProfile = new JMenu();
		exportPartnerProfile.setText(Constants.UI_EXPORT_PARTNERS);
		actionMenu.add(exportPartnerProfile);

		partnerProfileDelete = new JMenu();
		partnerProfileDelete.setText(Constants.UI_PARTNER_PROFILE_DELETE);
		actionMenu.add(partnerProfileDelete);

		setCommands = new JMenu();
		setCommands.setText(Constants.UI_SET_COMMANDS);
		actionMenu.add(setCommands);

		getCommands = new JMenu();
		getCommands.setText(Constants.UI_GET_COMMANDS);
		actionMenu.add(getCommands);

		deleteCommands = new JMenu();
		deleteCommands.setText(Constants.UI_DELETE_COMMANDS);
		actionMenu.add(deleteCommands);

		JMenuItem clearMenuItem = new JMenuItem();
		clearMenuItem.setText("Clear Console");
		actionMenu.add(clearMenuItem);
		clearMenuItem.addActionListener(this);
	}

	private void redirectSTDOUT_STDERR()
	{
		try
		{
			PipedOutputStream pout = new PipedOutputStream(this.pin);
			System.setOut(new PrintStream(pout, true));
		}
		catch (java.io.IOException io)
		{
			textArea.append("Couldn't redirect STDOUT to this console\n" + io.getMessage());
		}
		catch (SecurityException se)
		{
			textArea.append("Couldn't redirect STDOUT to this console\n" + se.getMessage());
		}
		try
		{
			PipedOutputStream pout2 = new PipedOutputStream(this.pin2);
			System.setErr(new PrintStream(pout2, true));
		}
		catch (java.io.IOException io)
		{
			textArea.append("Couldn't redirect STDERR to this console\n" + io.getMessage());
		}
		catch (SecurityException se)
		{
			textArea.append("Couldn't redirect STDERR to this console\n" + se.getMessage());
		}
	}

}
