// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi;

import com.cyclonecommerce.collaboration.profile.ProfileConstant;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Community;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.QueryResult;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.SearchBy;
import com.cyclonecommerce.util.io.IoUtil;
import com.cyclonecommerce.xml.util.XMLUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class Utilities
{
	private static final Logger logger = LogManager.getLogger(Utilities.class);

	private static Map<String, Document> importedCommunityProfiles = new HashMap<String, Document>();
	private static Map<String, Document> exportedCommunityProfiles = new HashMap<String, Document>();
	private static Map<String, Document> importedPartnerProfiles = new HashMap<String, Document>();
	private static Map<String, Document> exportedPartnerProfiles = new HashMap<String, Document>();
	private static List<CommandAndDocument> setProcessingStep = new ArrayList<CommandAndDocument>();
	private static List<CommandAndDocument> getProcessingStep = new ArrayList<CommandAndDocument>();
	private static List<String> importReturnValues = new ArrayList<String>();
	private static List<String> exportReturnValues = new ArrayList<String>();

	private Utilities()
	{
		//utility classes should not have a public or default constructor
	}

	protected static Element getInterChangeCommunityProfileRootElement(Document doc, String fileName)
	{
		if (doc == null)
			return null;

		String rootName = doc.getRootElement().getName();
		if (rootName == null || !rootName.equalsIgnoreCase(Constants.INTERCHANGE_COMMUNITY_PROFILE))
		{
			displayAndLogMessage("Error: Invalid XML Document" + (fileName != null ? " in file " + fileName : "") +
					". Expecting " + Constants.INTERCHANGE_COMMUNITY_PROFILE, true);
			return null;
		}

		return doc.getRootElement();
	}

	protected static Element getInterChangePartnerProfileRootElement(Document doc, String fileName)
	{
		if (doc == null)
			return null;

		String rootName = doc.getRootElement().getName();
		if (rootName == null || !rootName.equalsIgnoreCase(Constants.ORGANIZATION_PROFILE))
		{
			displayAndLogMessage("Error: Invalid XML Document" + (fileName != null ? " in file " + fileName : "") +
					". Expecting " + Constants.ORGANIZATION_PROFILE, true);
			return null;
		}
		return doc.getRootElement();
	}

	protected static Element getElement(Element rootElement, String elementName)
	{
		if (rootElement == null || elementName == null)
			return null;
		String aRootElement = null;
		List elements = rootElement.elements();
		if (rootElement.getName().equalsIgnoreCase(Constants.INTERCHANGE_COMMUNITY_PROFILE))
			aRootElement = Constants.INTERCHANGE_COMMUNITY_PROFILE;
		else if (rootElement.getName().equalsIgnoreCase(Constants.ORGANIZATION_PROFILE))
			aRootElement = Constants.ORGANIZATION_PROFILE;

		for (Object obj1 : elements)
		{
			Element aElement = (Element)obj1;
			if (Constants.INTERCHANGE_COMMUNITY_PROFILE.equalsIgnoreCase(aRootElement))
			{
				@SuppressWarnings({"unchecked"})
				Iterator<Element> orgProfileElements = aElement.elements().iterator();
				if (orgProfileElements.hasNext())
					return getOrganizationalProfileElement(orgProfileElements.next(), elementName);
			}
			else if (Constants.ORGANIZATION_PROFILE.equalsIgnoreCase(aRootElement))
				return getOrganizationalProfileElement(aElement, elementName);
		}
		return null;
	}

	protected static Element getOrganizationalProfileElement(Element aElement, String elementName)
	{
		Element returnElement = null;

		if (aElement.getName().equalsIgnoreCase(Constants.ADMINISTRATIVE_INFO) &&
			elementName.equalsIgnoreCase(Constants.ADMINISTRATIVE_INFO))
			returnElement = aElement;
		else if (aElement.getName().equalsIgnoreCase(Constants.ROUTING_IDS) &&
			elementName.equalsIgnoreCase(Constants.ROUTING_IDS))
			returnElement = aElement;
		else if (aElement.getName().equalsIgnoreCase(Constants.TRANSPORTS) &&
			elementName.equalsIgnoreCase(Constants.TRANSPORTS))
			returnElement = aElement;
		else if (aElement.getName().equalsIgnoreCase(Constants.BUSINESS_PROTOCOLS) &&
			elementName.equalsIgnoreCase(Constants.BUSINESS_PROTOCOLS))
			returnElement = aElement;

		return returnElement;
	}

	protected static String getOrganizationName(Element adminInfoElement, String elementName)
	{
		if (adminInfoElement == null || elementName == null)
			return null;
		if (!adminInfoElement.getName().equalsIgnoreCase(Constants.ADMINISTRATIVE_INFO))
			return null;
		String organizationName = null;
		List elements = adminInfoElement.elements();
		for (Object obj1 : elements)
		{
			Element element = (Element)obj1;
			String aName = element.getName();
			if (Constants.ORGANIZATION_NAME.equalsIgnoreCase(aName) && elementName.equalsIgnoreCase(Constants.ORGANIZATION_NAME))
			{
				organizationName = element.getStringValue();
				break;
			}
		}
		return organizationName;
	}

	protected static boolean checkForOptionalAdminInfoElement(Element adminInfoElement, String elementName)
	{
		List elements = adminInfoElement.elements();
		for (Object obj1 : elements)
		{
			Element element = (Element)obj1;
			if (element.getName().equalsIgnoreCase(Constants.COUNTRY_CODE) &&
				(elementName.equalsIgnoreCase(Constants.COUNTRY_CODE)))
				return true;
			else if (element.getName().equalsIgnoreCase(Constants.COUNTRY_CODE_NAME) &&
				(elementName.equalsIgnoreCase(Constants.COUNTRY_CODE_NAME)))
				return true;
			else if (element.getName().equalsIgnoreCase(Constants.POSTAL_ADDRESS) &&
				(elementName.equalsIgnoreCase(Constants.POSTAL_ADDRESS)))
				return true;
			else if (element.getName().equalsIgnoreCase(Constants.NOTES) &&
				(elementName.equalsIgnoreCase(Constants.NOTES)))
				return true;
		}
		return false;
	}

	protected static boolean checkForOptionalElement(Element element)
	{
		if (element == null)
			return false;
		List elements = element.elements();
		return (elements != null && elements.size() > 0);
	}

	protected static void getAdminInfoValues(Element element, String elementName, String direction)
	{
		if (!parametersOK(element, elementName, direction))
			return;
		storeResults(element, elementName, direction);
	}

	protected static void getRoutingIDValues(Element element, String elementName, String direction)
	{
		if (!parametersOK(element, elementName, direction))
			return;
		storeResults(element, elementName, direction);
	}

	protected static void getTransportValues(Element element, String elementName, String direction)
	{
		if (!parametersOK(element, elementName, direction))
			return;
		storeResults(element, elementName, direction);
	}

	protected static void getBusinessProtocolValues(Element element, String elementName, String direction)
	{
		if (!parametersOK(element, elementName, direction))
			return;
		List elements = element.elements();
		for (Object obj1 : elements)
		{
			Element businessProtocolsElement = (Element)obj1;
			storeResults(businessProtocolsElement, elementName, direction);
		}
	}

	@SuppressWarnings({"SimplifiableIfStatement"})
	protected static boolean parametersOK(Element element, String elementName, String direction)
	{
		if (element == null || elementName == null || direction == null)
			return false;
		return element.getName().equalsIgnoreCase(elementName);
	}

	protected static String getPluggableCommand(Document doc, String fileName)
	{
		if (doc == null)
		{
			displayAndLogMessage("Error: null XML Document " + fileName, true);
			return null;
		}
		if (doc.getRootElement() == null || doc.getRootElement().getName() == null)
		{
			displayAndLogMessage("Error: No root element or root element name found in XML file " + fileName, true);
			return null;
		}
		else if (!doc.getRootElement().getName().equalsIgnoreCase(Constants.PLUGGABLE_COMMAND))
		{
			displayAndLogMessage("Error: File " + fileName + " does not contain PluggableCommand element", true);
			return null;
		}
		String commandAttr = doc.getRootElement().attributeValue("command");
		if (commandAttr == null)
			displayAndLogMessage("Error: File " + fileName + " does not contain a command in the PluggableCommand element", true);

		return commandAttr;
	}

	/** return name attribute of the first known element */
	protected static String findArtifactNameInGetXML(Document doc)
	{
		//noinspection unchecked
		for (Element element : (List<Element>)doc.getRootElement().elements())
		{
			String elementName = element.getName();

			if (elementName.equalsIgnoreCase(Constants.DOCUMENT_SERVICE_NAME) ||
				elementName.equalsIgnoreCase(Constants.META_DATA_PROFILE_NAME) ||
				elementName.equalsIgnoreCase(Constants.APPLICATION_EXTENSION_PROFILE_NAME) ||
				elementName.equalsIgnoreCase(Constants.PROCESSING_STEP_NAME) ||
				elementName.equalsIgnoreCase(Constants.METADATA_TEMPLATE_NAME) ||
				elementName.equalsIgnoreCase(Constants.PROPERTY_TEMPLATE) ||
				elementName.equalsIgnoreCase(Constants.METADATA_ATTRIBUTE_NAME))
			{
				return element.attributeValue(Constants.nAME);
			}
		}
		return null;
	}

	protected static String findArtifactNameInSetXML(Document doc)
	{
		String name = null;
		List dataElements = doc.getRootElement().elements();
		for (Object obj1 : dataElements)
		{
			Element aElement = (Element)obj1;
			Element docService = aElement.element(Constants.DOCUMENT_SERVICE);
			if (docService != null)
			{
				Element docServiceName = docService.element(Constants.nAME);
				if (docServiceName != null && docServiceName.getName() != null)
				{
					name = docServiceName.getStringValue();
					break;
				}
				else
					break;
			}
			Element metadataProfile = aElement.element(Constants.META_DATA_PROFILE);
			if (metadataProfile != null)
			{
				name = metadataProfile.attributeValue(Constants.NAME);
				break;
			}
			Element eInvoiceSvcParameters = aElement.element(Constants.E_INVOICE_SERVICE_PARAMETERS);
			if (eInvoiceSvcParameters != null)
			{
				name = eInvoiceSvcParameters.attributeValue(Constants.PARTY_NAME);
				break;
			}
			Element processingStep = aElement.element(Constants.PROCESSING_STEP);
			if (processingStep != null)
			{
				name = processingStep.attributeValue(Constants.nAME);
				break;
			}
			Element applicationExtension = aElement.element(Constants.APPLICATION_EXTENSION);
			if (applicationExtension != null)
			{
				name = applicationExtension.attributeValue(Constants.nAME);
				break;
			}
		}
		return name;
	}

	public static Document readFile(File userFile, String fileName)
	{
		FileReader reader = null;
		Document doc = null;
		SAXReader saxReader = new SAXReader();
		try
		{
			reader = new FileReader(userFile);
			doc = saxReader.read(reader);
		}
		catch (FileNotFoundException e)
		{
			displayAndLogMessage("Error: FileRead threw FileNotFoundException for file: " + fileName, true);
			return null;
		}
		catch (DocumentException e)
		{
			displayAndLogError("Error: Unable to read file " + fileName + ".  DocumentException from SAXReader.", e);
			return null;
		}
		finally
		{
            try
            {
                if (reader != null)
                    reader.close();
            }
            catch(IOException e)
            {
				//do nothing
            }
		}
		return doc;
	}

	@SuppressWarnings({"SimplifiableIfStatement"})
	public static boolean verifyPropertiesFile(String[] args)
	{
		String fileName = args[1];
		File userFile = new File(fileName);
		if (!userFile.exists())
			return displayAndLogMessageWithReturn("Error: Properties File does not exist: " + fileName, true, false);
		else if (userFile.isDirectory())
			return displayAndLogMessageWithReturn("Error: Properties File cannot be a directory: " + fileName, true, false);
		else
			return true;
	}

	public static List<String> getProperty(String propertyKey)
	{
		Map<String, String> values = PropertiesFile.getInstance().getExportImportValues();
		List<String> aList = new ArrayList<String>();
		for (Map.Entry entry : values.entrySet())
		{
			String key = (String)entry.getKey();
			if (key.contains(propertyKey))
			{
				String keyValue = (String)entry.getValue();
				aList.add(keyValue);
			}
		}
		return aList;
	 }

	public static File verifyXMLFile(String fileName)
	{
		File xmlFile = null;
		if (fileName != null)
		{
			xmlFile = new File(fileName);
			if (!xmlFile.exists())
			{
				displayAndLogMessage("Error: File " + fileName + " does not exist", true);
				return null;
			}
		}
		else
			displayAndLogMessage("Error: fileName is null", true);

		return xmlFile;
	}

	public static String extractMissingCommunities(String[] allCommunities, List<Community> communities)
	{
		StringBuilder builder = new StringBuilder();
		for (String communityName : allCommunities)
		{
			if (!communityNameExistsInHost(communityName, communities))
			{
				if (builder.length() > 0)
					builder.append(", ");
				builder.append(communityName);
			}
		}
		return builder.toString();
	}

	private static boolean communityNameExistsInHost(String communityName, List<Community> communities)
	{
		for (Community foundCommunity : communities)
		{
			if (communityName.equalsIgnoreCase(foundCommunity.getCommunityName()))
				return true;
		}
		return false;
	}

	public static void putImportedOrganization(String organizationName, Document doc, boolean isCommunity)
	{
		if (isCommunity)
			importedCommunityProfiles.put(organizationName, doc);
		else
			importedPartnerProfiles.put(organizationName, doc);
	}

	public static Document getImportedOrganizations(String organizationName, boolean isCommunity)
	{
		if (isCommunity)
			return importedCommunityProfiles.get(organizationName);
		else
			return importedPartnerProfiles.get(organizationName);
	}

	public static void removeImportedOrganizations(String organizationName, boolean isCommunity)
	{
		if (isCommunity)
			importedCommunityProfiles.remove(organizationName);
		else
			importedPartnerProfiles.remove(organizationName);
	}

	public static void putExportedOrganizations(String organizationName, Document doc, boolean isCommunity)
	{
		if (isCommunity)
			exportedCommunityProfiles.put(organizationName, doc);
		else
			exportedPartnerProfiles.put(organizationName, doc);
	}

	public static Document getExportedOrganizations(String organizationName, boolean isCommunity)
	{
		if (isCommunity)
			return exportedCommunityProfiles.get(organizationName);
		else
			return exportedPartnerProfiles.get(organizationName);
	}

	public static void removeExportedOrganizations(String organizationName, boolean isCommunity)
	{
		if (isCommunity)
			exportedCommunityProfiles.remove(organizationName);
		else
			exportedPartnerProfiles.remove(organizationName);
	}

	public static void addSetCommandDocument(CommandAndDocument doc)
	{
		setProcessingStep.add(doc);
	}

	public static void clearSetCommandDocuments()
	{
		setProcessingStep.clear();
	}

	public static void addGetCommandDocument(CommandAndDocument doc)
	{
		getProcessingStep.add(doc);
	}

	public static void clearGetCommandDocuments()
	{
		getProcessingStep.clear();
	}

	public static List<String> getImportReturnValues()
	{
		return importReturnValues;
	}

	public static List<String> getExportReturnValues()
	{
		return exportReturnValues;
	}

	// Currently, this validation method only validates ProcessingSteps because they are the only element contained in
	// the CycloneOrganizationProfile schema
	public static boolean validateCommands()
	{
		if (getProcessingStep.size() == 0)
		{
			displayAndLogMessage("Validation: No Exported documents from Get Commands found.  Validation not performed", false);
			return true;
		}
		else if (setProcessingStep.size() == 0)
		{
			displayAndLogMessage("Validation: No Imported documents from Set Commands found.  Validation not performed", false);
			return true;
		}
		// For each SetProcessingStep, scan all GetProcessingSteps since there may or may not be a one to one
		// correspondence between the Get and Set commands.
		boolean validationResult = false;
		for (CommandAndDocument setDoc : setProcessingStep)
		{
			if (Constants.SET_PROCESSING_STEP.equalsIgnoreCase(setDoc.getCommand()))
			{
				for (CommandAndDocument getDoc : getProcessingStep)
				{
					if (Constants.GET_PROCESSING_STEP.equalsIgnoreCase(getDoc.getCommand()))
					{
						if (!validateProcessingSteps(setDoc, getDoc))
							break;
						else
							validationResult = true;
					}
				}
				if (!validationResult)
					break;
			}
		}
		return validationResult;
	}

	private static boolean validateProcessingSteps(CommandAndDocument setDoc,
					CommandAndDocument getDoc)
	{
		if (setDoc == null || getDoc == null)
			return false;
		Element userProcessingStepsElement = setDoc.getUserDoc().getRootElement().element(Constants.PROCESSING_STEPS);
		List<Element> allUserProcessingSteps = extractProcessingSteps(userProcessingStepsElement);
		Element hostProcessingStepsElement = getDoc.getHostReturnedDoc().getRootElement();
		List<Element> allHostProcessingSteps = extractProcessingSteps(hostProcessingStepsElement);
		if (!matching_processingSteps(allUserProcessingSteps, allHostProcessingSteps))
		{
			StringBuilder builder = new StringBuilder();
			builder.append("Validation not performed for ").append(getDoc.getCommand()).append(" ");
			if (getDoc.getArtifactName() != null)
				builder.append(getDoc.getArtifactName());
			builder.append(" because no matching processing steps could be found.");
			displayAndLogMessage(builder.toString(), false);
			return true;
		}
		return validateProcessingStep(allUserProcessingSteps, allHostProcessingSteps);
	}

	private static List<Element> extractProcessingSteps(Element processingSteps)
	{
		if (processingSteps == null)
			return null;
		List<Element> allProcessingSteps = new ArrayList<Element>();
		List steps = processingSteps.elements();
		for (Object obj : steps)
		{
			Element step = (Element)obj;
			allProcessingSteps.add(step);
		}
		return allProcessingSteps;
	}

	// Match the Processing steps returned from host with the Processing Steps sent by the user.
	// Return false if no matches are detected
	private static boolean matching_processingSteps(List<Element> userProcessingSteps, List<Element> hostProcessingSteps)
	{
		boolean match = false;
		if (userProcessingSteps.size() == 0 || hostProcessingSteps.size() == 0)
			return false;
		String[] userProcessingStepNames = new String[userProcessingSteps.size()];
		String[] hostProcessingStepNames = new String[hostProcessingSteps.size()];
		for (int x = 0; x < userProcessingSteps.size(); x++)
		{
			Element userProcessingStep = userProcessingSteps.get(x);
			userProcessingStepNames[x] = userProcessingStep.attributeValue(Constants.nAME);
		}
		for (int x = 0; x < hostProcessingSteps.size(); x++)
		{
			Element hostProcessingStep = hostProcessingSteps.get(x);
			hostProcessingStepNames[x] = hostProcessingStep.attributeValue(Constants.nAME);
		}
		List<String> aList = Arrays.asList(userProcessingStepNames);
		for (String hostProcessingStepName : hostProcessingStepNames)
		{
			if (aList.contains(hostProcessingStepName))
				match = true;
		}
		return match;
	}

	// At this point we know matching processingStep names exist, so just pair them and then validate.
	private static boolean validateProcessingStep(List<Element> userProcessingSteps, List<Element> hostProcessingSteps)
	{
		boolean validationResult = true;
		for (Element userProcessingStep : userProcessingSteps)
		{
			for (Element hostProcessingStep : hostProcessingSteps)
			{
				String hostPSName = hostProcessingStep.attributeValue(Constants.nAME);
				String userPSName = userProcessingStep.attributeValue(Constants.nAME);
				if (userPSName.equalsIgnoreCase(hostPSName))
				{
					displayAndLogMessage("Validating Processing Step " + userPSName, false);
					String hostPSType = hostProcessingStep.attributeValue(Constants.TYPE);
					String userPSType = userProcessingStep.attributeValue(Constants.TYPE);
					if (userPSType.equalsIgnoreCase(hostPSType))
					{
						if (!validateProcessingStepComponent(userProcessingStep, hostProcessingStep))
						{
							validationResult = false;
							break;
						}
					}
					else
					{
						displayAndLogMessage("Validation: Processing Step type not equal. User type: " + userPSType + " Host type: " + hostPSType, true);
						validationResult = false;
						break;
					}
				}
			}
			if (!validationResult)
				break;
		}
		return validationResult;
	}

	@SuppressWarnings({"unchecked", "SimplifiableIfStatement"})
	private static boolean validateProcessingStepComponent(Element userProcessingStep, Element hostProcessingStep)
	{
		// CycloneOrganizationProfile schema documents 0 or 1 ProcessingStepComponent are allowed
		List<Element> userPSComponents = userProcessingStep.elements();
		List<Element> hostPSComponents = hostProcessingStep.elements();
		if (!validateElementSize(userPSComponents, hostPSComponents, "ProcessingStepComponent", true))
			return false;

		Element userProcessStepComponent = userPSComponents.get(0);
		Element hostProcessStepComponent = hostPSComponents.get(0);

		// Validate all the attributes for ProcessingStepComponent
		List<Attribute> userAttributes = userProcessStepComponent.attributes();
		List<Attribute> hostAttributes = hostProcessStepComponent.attributes();
		for (Attribute aUserAttribute : userAttributes)
			importReturnValues.add(aUserAttribute.getStringValue());
		for (Attribute aHostAttribute : hostAttributes)
			exportReturnValues.add(aHostAttribute.getStringValue());
		if (!checkIfElementValuesMatch(false, false, " ProcessingStepComponent "))
			return false;
		clearResults(Constants.EXPORT);
		clearResults(Constants.IMPORT);

		if (Constants.DETECTOR.equals(userProcessingStep.attributeValue(Constants.TYPE)))
			return validateComponentParameterSets(userProcessStepComponent.elements(), hostProcessStepComponent.elements());
		else
			return true;
	}

	@SuppressWarnings({"unchecked"})
	// CycloneOrganizationProfile schema documents 0 or 1 ComponentParameterSets are allowed
	private static boolean validateComponentParameterSets(List<Element> userComponentParamSets, List<Element> hostComponentParamSets)
	{
		if (!validateElementSize(userComponentParamSets, hostComponentParamSets, "ComponentParameterSets", true))
			return false;

		Element userComponentParameterSet = userComponentParamSets.get(0);
		Element hostComponentParameterSet = hostComponentParamSets.get(0);

		return validateComponentParameterStep(userComponentParameterSet.elements(), hostComponentParameterSet.elements());
	}

	@SuppressWarnings({"unchecked"})
	private static boolean validateComponentParameterStep(List<Element> userComponentParameterSteps, List<Element> hostComponentParameterSteps)
	{
		if (!validateElementSize(userComponentParameterSteps, hostComponentParameterSteps, "ComponentParameterStep", false))
			return false;

		boolean attributesValidated;
		// Validate the attributes for each ComponentParameterStep
		for (Element userComponentParameterStep : userComponentParameterSteps)
		{
			List<Attribute> userAttributes = userComponentParameterStep.attributes();
			attributesValidated = false;
			for (Element hostComponentParameterStep : hostComponentParameterSteps)
			{
				List<Attribute> hostAttributes = hostComponentParameterStep.attributes();
				for (Attribute aUserAttribute : userAttributes)
					importReturnValues.add(aUserAttribute.getStringValue());
				for (Attribute aHostAttribute : hostAttributes)
					exportReturnValues.add(aHostAttribute.getStringValue());
				if (checkIfElementValuesMatch(false, true, " ComponentParameterStep "))
				{
					if (!validateParameterSetArguments(userComponentParameterStep.elements(), hostComponentParameterStep.elements()))
						return false;
					attributesValidated = true;
				}
				clearResults(Constants.EXPORT);
				clearResults(Constants.IMPORT);
			}
			if (!attributesValidated)
				return displayAndLogMessageWithReturn("Attributes do not match for ComponentParameterStep element", true, false);
		}
		return true;
	}

	@SuppressWarnings({"unchecked"})
	private static boolean validateParameterSetArguments(List<Element> userParameterSetArguments, List<Element> hostParameterSetArguments)
	{
		if (!validateElementSize(userParameterSetArguments, hostParameterSetArguments, "ParameterSetArguments", true))
			return false;

		boolean attributesValidated = false;
		clearResults(Constants.EXPORT);
		clearResults(Constants.IMPORT);
		for (Element userParameterSetArgument : userParameterSetArguments)
		{
			List<Attribute> userAttributes = userParameterSetArgument.attributes();
			for (Element hostParameterSetArgument : hostParameterSetArguments)
			{
				List<Attribute> hostAttributes = hostParameterSetArgument.attributes();
				for (Attribute aUserAttribute : userAttributes)
					importReturnValues.add(aUserAttribute.getStringValue());
				for (Attribute aHostAttribute : hostAttributes)
					exportReturnValues.add(aHostAttribute.getStringValue());
				if (checkIfElementValuesMatch(false, true, " ComponentParameterStep "))
				{
					if (!validateParameterSetArgument(userParameterSetArgument.elements(), hostParameterSetArgument.elements()))
						return false;
					attributesValidated = true;
				}
				clearResults(Constants.EXPORT);
				clearResults(Constants.IMPORT);
			}
			if (!attributesValidated)
				return displayAndLogMessageWithReturn("Attributes do not match for ComponentParameterStep element", true, false);
		}
		return true;
	}

	@SuppressWarnings({"unchecked"})
	private static boolean validateParameterSetArgument(List<Element> userListOfParameterSetArguments, List<Element> hostListOfParameterSetArguments)
	{
		if (!validateElementSize(userListOfParameterSetArguments, hostListOfParameterSetArguments, "ParameterSetArgument", false))
			return false;
		List<Element> userListOfParameterSetArgumentPossibleValues = new ArrayList<Element>();
		List<Element> hostListOfParameterSetArgumentPossibleValues = new ArrayList<Element>();
		// For remaining XML, validate that number of XML elements match
		for (Element userParameterSetArgumentPossibleValues : userListOfParameterSetArguments)
			userListOfParameterSetArgumentPossibleValues = userParameterSetArgumentPossibleValues.elements();
		for (Element hostParameterSetArgumentPossibleValues : hostListOfParameterSetArguments)
			hostListOfParameterSetArgumentPossibleValues = hostParameterSetArgumentPossibleValues.elements();

		return validateParameterSetArgumentPossibleValues(userListOfParameterSetArgumentPossibleValues, hostListOfParameterSetArgumentPossibleValues);
	}

	@SuppressWarnings({"unchecked"})
	private static boolean validateParameterSetArgumentPossibleValues(List<Element> userParameterSetArgumentPossibleValues, List<Element> hostParameterSetArgumentPossibleValues)
	{
		if (!validateElementSize(userParameterSetArgumentPossibleValues, hostParameterSetArgumentPossibleValues, "ParameterSetArgumentPossibleValues", true))
			return false;

		List<Element> aUserListOfParameterSetArgumentPossibleValue = new ArrayList<Element>();
		List<Element> aHostListOfParameterSetArgumentPossibleValue = new ArrayList<Element>();
		// For remaining XML, validate that number of XML elements match
		for (Element aUserParameterSetArgumentPossibleValue : userParameterSetArgumentPossibleValues)
			aUserListOfParameterSetArgumentPossibleValue = aUserParameterSetArgumentPossibleValue.elements();
		for (Element aHostParameterSetArgumentPossibleValue : hostParameterSetArgumentPossibleValues)
			aHostListOfParameterSetArgumentPossibleValue = aHostParameterSetArgumentPossibleValue.elements();

		return validateElementSize(aUserListOfParameterSetArgumentPossibleValue, aHostListOfParameterSetArgumentPossibleValue, "ParameterSetArgumentPossibleValue", false);
	}

	// Only return false if a Validation Error is detected.  Otherwise, make a log entry of elements not found.
	private static boolean validateElementSize(List<Element> userXML, List<Element> hostXML, String message, boolean zeroOrOneAllowed)
	{
		if (userXML.size() == 0 && hostXML.size() > 0)
			return displayAndLogMessageWithReturn("Validation Error: Missing " + message + " in user Set xml", true, false);
		else if (hostXML.size() == 0 && userXML.size() > 0)
			return displayAndLogMessageWithReturn("Validation Error: Missing " + message + " in host returned Get xml", true, false);
		else if (zeroOrOneAllowed)
		{
			if (userXML.size() == 0 && hostXML.size() == 0)
				logMessage("No " + message + " found is allowed per schema." ,false);
			else if (userXML.size() != 1 && hostXML.size() != 1)
				return displayAndLogMessageWithReturn("Validation Error: More than one " + message + " found. Schema allows only one.", true, false);
		}
		else if (userXML.size() == 0 && hostXML.size() == 0)
			logMessage("No " + message + " found.", false);

		return true;
	}

	public static boolean validateProfiles(boolean isCommunity)
	{
		Map<String, Document> importedProfiles = (isCommunity)? importedCommunityProfiles : importedPartnerProfiles;
		Map<String, Document> exportedProfiles = (isCommunity)? exportedCommunityProfiles : exportedPartnerProfiles;

		Set<String> importKeys = importedProfiles.keySet();
		if (importKeys.isEmpty())
		{
			displayAndLogMessage("Validation: No Imported Profiles found.  Validation not performed", false);
			return true;
		}
		Iterator importIterator = importKeys.iterator();
		List<String> validatedKeys = new ArrayList<String>();
		boolean validationResult = false;
		while (importIterator.hasNext())
		{
			String importKey = (String)importIterator.next();
			// Verify that a corresponding organization has been exported
			Document exportDoc = exportedProfiles.get(importKey);
			if (exportDoc == null)
			{
				displayAndLogMessage("Validation: Exported Organization not found for " + importKey + ". ", false);
				continue;
			}
			// Get the imported organization and validate it against the exported organization
			Document importDoc = importedProfiles.get(importKey);
			if (validateProfiles_ElementsAndAttributes(importDoc, exportDoc, isCommunity))
			{
				displayAndLogMessage("Validation successful for organization: " + importKey, false);
				validationResult = true;
				validatedKeys.add(importKey);
			}
			else
				displayAndLogMessage("Validation unsuccessful", true);
		}
		// remove only those organizations that were successfully validated.
		removeOrganizations(validatedKeys, isCommunity);
		return validationResult;
	}

	private static boolean validateProfiles_ElementsAndAttributes(Document importDoc, Document exportDoc, boolean isCommunity)
	{
		Element rootElement = (isCommunity)? Utilities.getInterChangeCommunityProfileRootElement(importDoc, null) :
				Utilities.getInterChangePartnerProfileRootElement(importDoc, null);

		// Validate Admin Info Element  (Schema required)
		if (!validateProfiles_AdminInfoElement(rootElement, exportDoc))
			return false;

		// Validate RoutingIds  (Schema required)
		if (!validateProfiles_RoutingIds(rootElement, exportDoc))
			return false;

		// Validate Transports  (Not Schema required)
		if (!validateProfiles_Transports(rootElement, exportDoc))
			return false;

		// Validate BusinessProtocols (Not Schema required)
		return validateProfiles_BusinessProtocols(rootElement, exportDoc);
	}

	protected static boolean validateProfiles_AdminInfoElement(Element rootElement, Document exportDoc)
	{
		// Validate AdminInfo (Schema required)
		Element importAdminInfoElement = Utilities.getElement(rootElement, Constants.ADMINISTRATIVE_INFO);
		Element exportAdminInfoElement = Utilities.getElement(exportDoc.getRootElement(), Constants.ADMINISTRATIVE_INFO);

		Utilities.getAdminInfoValues(importAdminInfoElement, Constants.ADMINISTRATIVE_INFO, clearResults(Constants.IMPORT));
		Utilities.getAdminInfoValues(exportAdminInfoElement, Constants.ADMINISTRATIVE_INFO, clearResults(Constants.EXPORT));
		return checkIfElementValuesMatch(false, false, Constants.ERR_ADMIN_INFO);
	}

	protected static boolean validateProfiles_RoutingIds(Element rootElement, Document exportDoc)
	{
		// Validate RoutingIds (Schema required)
		Element importRoutingIDsElement = Utilities.getElement(rootElement, Constants.ROUTING_IDS);
		Utilities.getRoutingIDValues(importRoutingIDsElement, Constants.ROUTING_IDS, clearResults(Constants.IMPORT));
		Element exportRoutingIDsElement = Utilities.getElement(exportDoc.getRootElement(), Constants.ROUTING_IDS);
		Utilities.getRoutingIDValues(exportRoutingIDsElement, Constants.ROUTING_IDS, clearResults(Constants.EXPORT));
		return checkIfElementValuesMatch(false, false, Constants.ERR_ROUTING_IDS);
	}

	protected static boolean validateProfiles_Transports(Element rootElement, Document exportDoc)
	{
		//Validate Transports (Not Schema required)
		Element importTransportsElement = Utilities.getElement(rootElement, Constants.TRANSPORTS);
		Element exportTransportsElement = Utilities.getElement(exportDoc.getRootElement(), Constants.TRANSPORTS);

		// Check if Transports Element exists (Not required in Schema)
		if (checkForOptionalElement(importTransportsElement))
		{
			Utilities.getTransportValues(importTransportsElement, Constants.TRANSPORTS, clearResults(Constants.IMPORT));
			Utilities.getTransportValues(exportTransportsElement, Constants.TRANSPORTS, clearResults(Constants.EXPORT));
			if (!checkIfElementValuesMatch(false, false, Constants.ERR_TRANSPORTS))
				return false;
		}
		else
		{
			if (checkForOptionalElement(exportTransportsElement))
				return displayAndLogMessageWithReturn(Constants.VALIDATION_ERROR + " Transports Element found in export profile and not import profile.", true, false);
		}
		return true;
	}

	protected static boolean validateProfiles_BusinessProtocols(Element rootElement, Document exportDoc)
	{
		 //Validate BusinessProtocols (Not Schema required)
		Element importBusinessProtocolsElement = Utilities.getElement(rootElement, Constants.BUSINESS_PROTOCOLS);
		Element exportBusinessProtocolsElement = Utilities.getElement(exportDoc.getRootElement(), Constants.BUSINESS_PROTOCOLS);

		// Check if BusinessProtocols Element exists (Not required in Schema)
		if (checkForOptionalElement(importBusinessProtocolsElement))
		{
			Utilities.getBusinessProtocolValues(importBusinessProtocolsElement, Constants.BUSINESS_PROTOCOLS, clearResults(Constants.IMPORT));
			Utilities.getBusinessProtocolValues(exportBusinessProtocolsElement, Constants.BUSINESS_PROTOCOLS, clearResults(Constants.EXPORT));
			if (!checkIfElementValuesMatch(false, false, Constants.BUSINESS_PROTOCOLS))
				return false;
		}
		else
		{
			if (checkForOptionalElement(exportBusinessProtocolsElement))
				return displayAndLogMessageWithReturn(Constants.VALIDATION_ERROR + " Business Protocols Element found in export profile and not import profile.", true, false);
		}

		return true;
	}

	protected static void removeOrganizations(List<String> validatedKeys, boolean isCommunity)
	{
		for (String importKey : validatedKeys)
		{
			Utilities.removeExportedOrganizations(importKey, isCommunity);
			Utilities.removeImportedOrganizations(importKey, isCommunity);
		}
	}

	public static void logMessage(String message, boolean logError)
	{
		if (logError)
			logger.error(message);
		else
			logger.info(message);
	}

	public static void displayAndLogMessage(String message, boolean logError)
	{
		System.out.println(message);
		logMessage(message, logError);
	}

	public static boolean displayAndLogMessageWithReturn(String message, boolean logError, boolean returnValue)
	{
		displayAndLogMessage(message, logError);
		return returnValue;
	}

	public static void displayAndLogError(String message, Exception e)
	{
		System.out.println(message);
		e.printStackTrace();
		logger.error(message, e);
	}

	public static boolean displayAndLogErrorWithReturn(String message, Exception e, boolean returnValue)
	{
		displayAndLogError(message, e);
		return returnValue;
	}

	@SuppressWarnings({"SimplifiableIfStatement"})
	private static boolean checkIfElementValuesMatch(boolean schemaRequired, boolean isSearchingEnabled, String errorMsg)
	{
		boolean compareValue = true;
		int sizeOfImportValues = importReturnValues.size();
		int sizeOfExportValues = exportReturnValues.size();
		if (sizeOfImportValues == 0 && sizeOfExportValues == 0)
		{
			if (schemaRequired)
				return displayAndLogMessageWithReturn(Constants.VALIDATION_ERROR + errorMsg + " are both null and are required elements. ", true, false);
			else
				return true;
		}
		if (sizeOfImportValues == 0 && sizeOfExportValues > 0 ||
			sizeOfImportValues > 0 && sizeOfExportValues == 0 ||
			sizeOfImportValues != sizeOfExportValues)
			return displayAndLogMessageWithReturn(Constants.VALIDATION_ERROR + errorMsg + " unequal number of elements/attributes detected. Exported Values: " + exportReturnValues + "\n" +
					" Imported Values: " + importReturnValues, true, false);
		for (int x = 0; x < sizeOfImportValues; x++)
		{
			String importValue = importReturnValues.get(x);
			String exportValue = exportReturnValues.get(x);
			if (!importValue.equalsIgnoreCase(exportValue))
			{
				if (isSearchingEnabled)
					return false;
				else
					return displayAndLogMessageWithReturn(Constants.VALIDATION_ERROR +  errorMsg + "do not match." + " A Imported Value of " + importValue +
						" does not match with a Exported Value of: " + exportValue + "\n" +
						" Imported Values: " + importReturnValues + "\n" + " Exported Values: " + exportReturnValues, true, false);
			}
		}
		return compareValue;
	}

	private static void storeResults(Element element, String elementName, String direction)
	{
		if (Constants.ADMINISTRATIVE_INFO.equalsIgnoreCase(elementName))
		{
			storeAdminInfoResults(element, direction);
		}
		else if (Constants.ROUTING_IDS.equalsIgnoreCase(elementName))
		{
			storeRoutingIdResults(element, direction);
		}
		else if (Constants.TRANSPORTS.equalsIgnoreCase(elementName))
		{
			storeTransportResults(element, direction);
		}
		else if (Constants.BUSINESS_PROTOCOLS.equalsIgnoreCase(elementName))
		{
			storeBusinessProtocolsResults(element, direction);
		}
	}

	protected static void storeAdminInfoResults(Element element, String direction)
	{
		for (Object object : element.elements())
		{
			Element innerElement = (Element)object;
			String innerElementName = innerElement.getName();
			if (Constants.ORGANIZATION_NAME.equalsIgnoreCase(innerElementName) ||
				Constants.COUNTRY_CODE.equalsIgnoreCase(innerElementName) ||
				Constants.COUNTRY_CODE_NAME.equalsIgnoreCase(innerElementName))
			{
				if (direction.equalsIgnoreCase(Constants.EXPORT))
				{
					exportReturnValues.add(innerElementName);
					exportReturnValues.add(innerElement.getStringValue());
				}
				else
				{
					importReturnValues.add(innerElementName);
					importReturnValues.add(innerElement.getStringValue());
				}
			}
			else if (Constants.POSTAL_ADDRESS.equalsIgnoreCase(innerElementName))
			{
				for (Object obj : innerElement.elements())
				{
					Element postalAddressElement = (Element)obj;
					String postalAddressName = postalAddressElement.getName();
					if (direction.equalsIgnoreCase(Constants.EXPORT))
					{
						exportReturnValues.add(postalAddressName);
						exportReturnValues.add(postalAddressElement.getStringValue());
					}
					else
					{
						importReturnValues.add(postalAddressName);
						importReturnValues.add(postalAddressElement.getStringValue());
					}
				}
			}
			else if (Constants.CONTACTS.equalsIgnoreCase(innerElementName))
			{
				for (Object obj : innerElement.elements())
				{
					Element contact = (Element)obj;
					if (contact.getName().equalsIgnoreCase(Constants.CONTACT))
					{
						for (Object obj1 : contact.elements())
						{
							Element contactElement = (Element)obj1;
							String contactElementName = contactElement.getName();
							if (direction.equalsIgnoreCase(Constants.EXPORT))
							{
								exportReturnValues.add(contactElementName);
								exportReturnValues.add(contactElement.getStringValue());
							}
							else
							{
								importReturnValues.add(contactElementName);
								importReturnValues.add(contactElement.getStringValue());
							}
							if (Constants.EMAIL.equalsIgnoreCase(contactElementName))
							{
								String attribute = contactElement.attributeValue(Constants.TYPE);
								if (direction.equalsIgnoreCase(Constants.EXPORT) && attribute != null)
									exportReturnValues.add(attribute);
								else if (direction.equalsIgnoreCase(Constants.IMPORT) && attribute != null )
									importReturnValues.add(attribute);
							}
						}
					}
				}
			}
		}
	}

	protected static void storeRoutingIdResults(Element element,String direction)
	{
		//noinspection unchecked
		List<Element> elements = element.elements();
		for (Object obj1 : elements)
		{
			Element routingIDElement = (Element)obj1;
			if (routingIDElement.getName().equalsIgnoreCase(Constants.ROUTINGID))
			{
				String attribute = routingIDElement.attributeValue(Constants.TYPE);
				if (direction.equalsIgnoreCase(Constants.EXPORT))
				{
					exportReturnValues.add(routingIDElement.getName());
					exportReturnValues.add(routingIDElement.getStringValue());
					if (attribute != null)
						exportReturnValues.add(attribute);
				}
				else
				{
					importReturnValues.add(routingIDElement.getName());
					importReturnValues.add(routingIDElement.getStringValue());
					if (attribute != null)
						importReturnValues.add(attribute);
				}
			}
		}
	}

	protected static void storeTransportResults(Element element, String direction)
	{
		String preferred = element.attributeValue(Constants.PREFERRED_TRANSPORT_REF);
		if (preferred != null)
		{
			if (direction.equalsIgnoreCase(Constants.EXPORT))
				exportReturnValues.add(preferred);
			else
				importReturnValues.add(preferred);
		}
		for (Object obj1 : element.elements())
		{
			Element transportElement = (Element)obj1;
			if (direction.equalsIgnoreCase(Constants.EXPORT))
				exportReturnValues.add(transportElement.getName());
			else
				importReturnValues.add(transportElement.getName());
			for (Iterator i = transportElement.attributeIterator(); i.hasNext();)
			{
				Attribute attribute = (Attribute) i.next();
				if (direction.equalsIgnoreCase(Constants.EXPORT))
				{
					exportReturnValues.add(attribute.getName());
					exportReturnValues.add(attribute.getStringValue());
				}
				else
				{
					importReturnValues.add(attribute.getName());
					importReturnValues.add(attribute.getStringValue());
				}
			}
			for (Object obj : transportElement.elements())
			{
				Element transportChild = (Element)obj;
				if (direction.equalsIgnoreCase(Constants.EXPORT))
				{
					exportReturnValues.add(transportChild.getName());
					exportReturnValues.add(transportChild.getStringValue());
				}
				else
				{
					importReturnValues.add(transportChild.getName());
					importReturnValues.add(transportChild.getStringValue());
				}
			}
		}
	}

	protected static void storeBusinessProtocolsResults(Element element, String direction)
	{
		if (direction.equalsIgnoreCase(Constants.EXPORT))
			exportReturnValues.add(element.getName());
		else
			importReturnValues.add(element.getName());
		for (Iterator i = element.attributeIterator(); i.hasNext();)
		{
			Attribute attribute = (Attribute) i.next();
			if (direction.equalsIgnoreCase(Constants.EXPORT))
			{
				exportReturnValues.add(attribute.getName());
				exportReturnValues.add(attribute.getStringValue());
			}
			else
			{
				importReturnValues.add(attribute.getName());
				importReturnValues.add(attribute.getStringValue());
			}
		}
		for (Object obj : element.elements())
		{
			Element transportChild = (Element)obj;
			if (direction.equalsIgnoreCase(Constants.EXPORT))
			{
				exportReturnValues.add(transportChild.getName());
				exportReturnValues.add(transportChild.getStringValue());
			}
			else
			{
				importReturnValues.add(transportChild.getName());
				importReturnValues.add(transportChild.getStringValue());
			}
		}
	}

	protected static String clearResults(String direction)
	{
		if (Constants.EXPORT.equalsIgnoreCase(direction))
			exportReturnValues.clear();
		else if (Constants.IMPORT.equalsIgnoreCase(direction))
			importReturnValues.clear();
		return direction;
	}

	public static ClientSession createSession(String userId, String password, String aURL)
		throws AuthenticationException
	{
		Map<String, String> authData = new HashMap<String, String>();
		authData.put("organization", "Service Provider");
		authData.put("administrator", userId);
		authData.put("password", password);
		URL url;
		try
		{
			url = new URL(aURL);
		}
		catch (MalformedURLException e)
		{
			displayAndLogError("Could not create URL for spec: " + aURL + "." + e.getMessage(), e);
			return null;
		}
		return ClientSession.createSession("OrgAdminPassword", authData, url);
	}

	public static String writeProfile(File directory, org.w3c.dom.Element orgProfileElem, String command)
		throws IOException, TransformerException
	{

		NodeList nl = orgProfileElem.getElementsByTagNameNS("*", Constants.ORGANIZATION_NAME);
		String orgName;

		if (nl.getLength() > 0
			&& ProfileConstant.ADMINISTRATIVE_INFO.getValue().equals(nl.item(0).getParentNode().getNodeName())
			&& !StringUtils.isBlank(nl.item(0).getTextContent()))
		{
			if (command != null)
				orgName = command + "_" + nl.item(0).getTextContent();
			else
				orgName = nl.item(0).getTextContent();
		}
		else
		{
			if (command != null)
				orgName = command + System.currentTimeMillis();
			else
				orgName = "Unknown_" + System.currentTimeMillis();
		}

		String encodedName = orgName.replace(' ', '_');
		encodedName = URLEncoder.encode(encodedName, "UTF-8");
		String fileName = encodedName + ".xml";
		File file = new File(directory, fileName);

		org.dom4j.Element dom4jElement = XMLUtil.convertW3cToDom4j(orgProfileElem);

		OutputFormat outputFormat = new OutputFormat();
		outputFormat.setNewlines(true);
		outputFormat.setIndent("\t");
		FileOutputStream fileOutputStream = null;
		XMLWriter xmlWriter = null;
		try
		{
			fileOutputStream = new FileOutputStream(file);
			xmlWriter = new XMLWriter(fileOutputStream, outputFormat);
			xmlWriter.write(dom4jElement);
			xmlWriter.flush();
		}
		finally
		{
			if (xmlWriter != null)
				xmlWriter.close();
			IoUtil.close(fileOutputStream);
		}

		return file.getCanonicalFile().toString();
	}

	public static String getOrganizationId(ProfileManagementApiStub service, String orgName)
			throws RemoteException
	{
		OrganizationQuery orgQuery = new OrganizationQuery();
		SearchBy searchBy = new SearchBy();
		searchBy.setOrganizationName(orgName);
		orgQuery.setSearchBy(searchBy);

		QueryResult result = service.findOrganizationsEx(orgQuery);
		if (result == null)
			displayAndLogMessage("QueryResult was not returned as expected.", true);
		else
		{
			String[] orgIds = result.getOrganizationIds();
			// Only do a Log entry here for a known Server bug of returning multiple id's with single orgName (Query doing LIKE operation)
			if (orgIds != null && orgIds.length > 0)
			{
				displayAndLogMessage("Number of organizationIDs returned: " + orgIds.length + " for organization: " + orgName, false);
				return orgIds[0];
			}
		}

		return null;
	}

	public static Element getProfileRootElement(Document doc, String xmlFileName, boolean isCommunityProfile)
	{
		if (isCommunityProfile)
			return Utilities.getInterChangeCommunityProfileRootElement(doc, xmlFileName);
		else
			return Utilities.getInterChangePartnerProfileRootElement(doc, xmlFileName);
	}

}
