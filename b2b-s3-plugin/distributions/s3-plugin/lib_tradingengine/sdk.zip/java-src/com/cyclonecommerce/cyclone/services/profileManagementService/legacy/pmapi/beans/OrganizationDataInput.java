// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.util.List;

public class OrganizationDataInput
{
    private String organizationId;
    private org.w3c.dom.Element organizationData;

    public OrganizationDataInput()
    {
        super();
    }

    public OrganizationDataInput(Element root)
    {
        setOrganizationId(root.attributeValue(PmapiConstants.ORGANIZATION_ID_ATT));
        List children = root.elements();
        if (!children.isEmpty())
        {
            Element child = (Element)children.get(0);
            setOrganizationData(ElementUtil.toDomElement(child));
        }
    }

    public String getOrganizationId()
    {
        return organizationId;
    }

    public void setOrganizationId(String organizationId)
    {
        this.organizationId = organizationId;
    }

    public org.w3c.dom.Element getOrganizationData()
    {
        return organizationData;
    }

    public void setOrganizationData(org.w3c.dom.Element organizationData)
    {
        this.organizationData = organizationData;
    }

    public Element toElement()
    {
        QName qname = new QName(PmapiConstants.ORGANIZATION_DATA_INPUT_LIST, PmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (organizationId != null)
            root.addAttribute(PmapiConstants.ORGANIZATION_ID_ATT, organizationId);

        if (organizationData != null)
        {
            Element child = ElementUtil.toDom4JElement(organizationData);
            root.add(child);
        }
        return root;
    }
}
