// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.util.ArrayList;
import java.util.Iterator;

public class OrganizationDataInputList
{
    private OrganizationDataInput[] organizationDataInput;

    public OrganizationDataInputList()
    {
        super();
    }

    public OrganizationDataInputList(Element root)
    {
        ArrayList<OrganizationDataInput> list = new ArrayList<OrganizationDataInput>();
        Iterator it = root.elementIterator(PmapiConstants.ORGANIZATION_DATA_INPUT);
        while (it.hasNext())
        {
            list.add(new OrganizationDataInput((Element) it.next()));
        }

        OrganizationDataInput[] array = new OrganizationDataInput[list.size()];
        list.toArray(array);
        setOrganizationDataInput(array);
    }

    public OrganizationDataInput[] getOrganizationDataInput()
    {
        return organizationDataInput;
    }

    public void setOrganizationDataInput(OrganizationDataInput[] organizationDataInput)
    {
        this.organizationDataInput = organizationDataInput;
    }

    public Element toElement()
    {
        QName qname = new QName(PmapiConstants.ORGANIZATION_DATA_INPUT_LIST, PmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (organizationDataInput != null)
        {
            for (OrganizationDataInput orgDataInput : organizationDataInput)
                root.add(orgDataInput.toElement());
        }

        return root;
    }
}
