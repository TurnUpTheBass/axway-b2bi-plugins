// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.BapiConstants;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.util.List;

public class OrganizationDataOutput
{
    private String organizationId;
    private org.w3c.dom.Element organizationData;
    private Disposition disposition;

    public OrganizationDataOutput()
    {
        super();
    }

    public OrganizationDataOutput(Element root)
    {
        setOrganizationId(root.attributeValue(PmapiConstants.ORGANIZATION_ID_ATT));
        Element dispostionElem = root.element(BapiConstants.QN_DISPOSITION);
        if (dispostionElem != null)
        {
            setDisposition(new Disposition(dispostionElem));
        }
        else
        {
            List children = root.elements();
            if (!children.isEmpty())
            {
                Element child = (Element)children.get(0);
                setOrganizationData(ElementUtil.toDomElement(child));
            }
        }
    }

    public String getOrganizationId()
    {
        return organizationId;
    }

    public void setOrganizationId(String organizationId)
    {
        this.organizationId = organizationId;
    }

    public org.w3c.dom.Element getOrganizationData()
    {
        return organizationData;
    }

    public void setOrganizationData(org.w3c.dom.Element organizationData)
    {
        this.organizationData = organizationData;
    }

    public Disposition getDisposition()
    {
        return disposition;
    }

    public void setDisposition(Disposition disposition)
    {
        this.disposition = disposition;
    }

    public Element toElement()
    {
        QName qname = new QName(PmapiConstants.ORGANIZATION_DATA_OUTPUT, PmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (organizationId != null)
            root.addAttribute(PmapiConstants.ORGANIZATION_ID_ATT, organizationId);

        if (disposition != null)
        {
            root.add(disposition.toElement());
        }
        else if (organizationData != null)
        {
            Element child = ElementUtil.toDom4JElement(organizationData);
            root.add(child);
        }
        return root;
    }
}
