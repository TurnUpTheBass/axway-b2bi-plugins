// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.util.ArrayList;
import java.util.Iterator;

public class OrganizationDataOutputList
{
    private OrganizationDataOutput[] organizationDataOutput;

    public OrganizationDataOutputList()
    {
        super();
    }

    public OrganizationDataOutputList(Element root)
    {
        ArrayList<OrganizationDataOutput> list = new ArrayList<OrganizationDataOutput>();
        Iterator it = root.elementIterator(PmapiConstants.ORGANIZATION_DATA_OUTPUT);
        while (it.hasNext())
        {
            list.add(new OrganizationDataOutput((Element) it.next()));
        }

        OrganizationDataOutput[] array = new OrganizationDataOutput[list.size()];
        list.toArray(array);
        setOrganizationDataOutput(array);
    }

    public OrganizationDataOutput[] getOrganizationDataOutput()
    {
        return organizationDataOutput;
    }

    public void setOrganizationDataOutput(OrganizationDataOutput[] organizationDataOutput)
    {
        this.organizationDataOutput = organizationDataOutput;
    }

    public Element toElement()
    {
        QName qname = new QName(PmapiConstants.ORGANIZATION_DATA_OUTPUT_LIST, PmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (organizationDataOutput != null)
        {
            for (OrganizationDataOutput orgDataInput : organizationDataOutput)
                root.add(orgDataInput.toElement());
        }

        return root;
    }
}
