// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.BapiConstants;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.util.ArrayList;
import java.util.Iterator;


public class OrganizationIdList
{
    private String[] organizationIds;

    public OrganizationIdList()
    {
        super();
    }

    public OrganizationIdList(Element root)
    {
        ArrayList<String> list = new ArrayList<String>();
        Iterator it = root.elementIterator(BapiConstants.ORGANIZATION_ID);
        while (it.hasNext())
        {
            Element elem = (Element)it.next();
            list.add(elem.getText());
        }

        String[] array = new String[list.size()];
        list.toArray(array);
        setOrganizationIds(array);
    }

    public String[] getOrganizationIds()
    {
        return organizationIds;
    }

    public void setOrganizationIds(String[] organizationIds)
    {
        this.organizationIds = organizationIds;
    }

    public Element toElement()
    {
        QName qname = new QName(BapiConstants.ORGANIZATION_ID_LIST, BapiConstants.NS_BAPI);
        Element root = DocumentHelper.createElement(qname);
        if (organizationIds!= null)
        {
            for (String id : organizationIds)
                root.addElement(BapiConstants.ORGANIZATION_ID).setText(id);
        }

        return root;
    }
}
