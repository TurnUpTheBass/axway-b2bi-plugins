// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.BapiConstants;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Cursor;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.InvalidQueryException;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.io.Serializable;

public class OrganizationQuery
        implements Serializable
{
    private Integer max;
    private Cursor cursor;
    private SearchBy searchBy;
    private SortBy sortBy;

    public OrganizationQuery()
    {
        super();
    }

    public OrganizationQuery(Element root)
            throws InvalidQueryException
    {
        String sMax = root.attributeValue("max");
        if (sMax != null)
        {
            try
            {
                setMax(new Integer(sMax));
            }
            catch (NumberFormatException e)
            {
                //
            }
        }

        Element cursorElem = root.element(BapiConstants.QN_CURSOR);
        if (cursorElem != null)
            setCursor(new Cursor(cursorElem));

        Element elem = root.element(PmapiConstants.SEARCH_BY);
        if (elem != null)
            setSearchBy(new SearchBy(elem));

        elem = root.element(PmapiConstants.SORT_BY);
        if (elem != null)
            setSortBy(new SortBy(elem));

    }
    public Integer getMax()
    {
        return max;
    }

    public void setMax(Integer max)
    {
        this.max = max;
    }

    public Cursor getCursor()
    {
        return cursor;
    }

    public void setCursor(Cursor cursor)
    {
        this.cursor = cursor;
    }

    public SearchBy getSearchBy()
    {
        return searchBy;
    }

    public void setSearchBy(SearchBy searchBy)
    {
        this.searchBy = searchBy;
    }

    public SortBy getSortBy()
    {
        return sortBy;
    }

    public void setSortBy(SortBy sortBy)
    {
        this.sortBy = sortBy;
    }

    public Element toElement()
    {
        QName qname = new QName(PmapiConstants.ORGANIZATION_QUERY, PmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);

        if (max != null)
            root.addAttribute("max", max.toString());
        if (cursor != null)
            root.add(cursor.toElement());
        if (searchBy != null)
            root.add(searchBy.toElement());
        if (sortBy != null)
            root.add(sortBy.toElement());

        return root;
    }
}
