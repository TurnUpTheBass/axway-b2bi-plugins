// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.InvalidQueryException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class OrganizationState
        implements Serializable
{
    private static final Logger logger = LogManager.getLogger(OrganizationState.class);

	private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";

    // These constants would be a classic case for an "enum", but I can't get AXIS 1.3 to generate stubs with them (Bob K.)
    private static final int ORGANIZATION_STATUS_NEW = 0;
    private static final int ORGANIZATION_STATUS_MODIFIED = 1;
    private static final int ORGANIZATION_STATUS_REMOVED = 2;

    private static final String[] ORGANIZATION_STATUS_NAMES = {PmapiConstants.STATUS_NEW, PmapiConstants.STATUS_MODIFIED, PmapiConstants.STATUS_REMOVED};

    private Date changedSince;
    private int[] organizationStatusCodes;

    public OrganizationState()
    {
        super();
        setChangedSince(new Date());
    }

    public OrganizationState(Element root) throws InvalidQueryException
    {
        try
        {
            String s = root.elementText(PmapiConstants.CHANGED_SINCE);
			SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
            setChangedSince(dateFormat.parse(s));
            List elemList = root.elements(PmapiConstants.STATUS);
            int[] statusArray = new int[elemList.size()];
            for (int i = 0; i < elemList.size(); i++)
            {
                Element elem = (Element)elemList.get(i);
                String status = elem.getText();
                int code = 0;
                if (PmapiConstants.STATUS_NEW.equals(status))
                    code = ORGANIZATION_STATUS_NEW;
                else  if (PmapiConstants.STATUS_MODIFIED.equals(status))
                    code = ORGANIZATION_STATUS_MODIFIED;
                else  if (PmapiConstants.STATUS_REMOVED.equals(status))
                    code = ORGANIZATION_STATUS_REMOVED;
                statusArray[i] = code;
            }
            setOrganizationStatusCodes(statusArray);
        }
        catch (Exception e)
        {
            logger.error("Unable to parse OrganizationState element.", e);
            throw new InvalidQueryException(e.getLocalizedMessage());
        }

        if (getChangedSince() == null)
            throw new InvalidQueryException("Organization state changed since value is not specified");

        if (getOrganizationStatusCodes() == null || getOrganizationStatusCodes().length == 0)
            throw new InvalidQueryException("Must specify one or more organization state status codes.");
    }

    public Date getChangedSince()
    {
        return changedSince;
    }

    public void setChangedSince(Date changedSince)
    {
        this.changedSince = changedSince;
    }

    public int[] getOrganizationStatusCodes()
    {
        return organizationStatusCodes;
    }

    public void setOrganizationStatusCodes(int[] organizationStatusCodes)
    {
        this.organizationStatusCodes = organizationStatusCodes;
    }

    public Element toElement()
    {
        QName qname = new QName(PmapiConstants.ORGANIZATION_STATE, PmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);

        if (changedSince != null)
		{
			SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
            root.addElement(PmapiConstants.CHANGED_SINCE).setText(dateFormat.format(changedSince));
		}

        if (organizationStatusCodes != null)
        {
            for (int index : organizationStatusCodes)
                root.addElement(PmapiConstants.STATUS).setText(ORGANIZATION_STATUS_NAMES[index]);
        }

        return root;
    }
}
