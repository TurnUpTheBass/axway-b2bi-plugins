// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import org.dom4j.Namespace;

public interface PmapiConstants
{
    public static final String ORGANIZATION_QUERY = "OrganizationQuery";
    public static final String MAX_ORGS = "maxOrgs";
    public static final String SEARCH_BY = "SearchBy";
    public static final String MY_ORGANIZATION_ID = "MyOrganizationId";
    public static final String MY_PARTNERS = "MyPartners";
    public static final String ORGANIZATION_NAME = "OrganizationName";
    public static final String COMMUNITIES = "Communities";
    public static final String COMMUNITY = "Community";
    public static final String ORGANIZATION_STATE = "OrganizationState";
    public static final String CHANGED_SINCE = "changedSince";
    public static final String STATUS = "Status";
    public static final String STATUS_NEW = "new";
    public static final String STATUS_MODIFIED = "modified";
    public static final String STATUS_REMOVED = "removed";
    public static final String XPATH = "XPath";
    public static final String SORT_BY = "SortBy";
    public static final String MODIFIED_DATE = "ModifiedDate";
    public static final String ASCENDING = "isAscending";
    public static final String QUERY_RESULT = "QueryResult";
    public static final String ORGANIZATION_DATA_OUTPUT_LIST = "OrganizationDataOutputList";
    public static final String ORGANIZATION_DATA_OUTPUT = "OrganizationDataOutput";
    public static final String ORGANIZATION_DATA_INPUT_LIST = "OrganizationDataInputList";
    public static final String ORGANIZATION_DATA_INPUT = "OrganizationDataInput";
    public static final String ORGANIZATION_ID_ATT = "organizationId";

    public static final String URI_PMAPI = "http://www.cyclonecommerce.com/Schemas/2001/07/pmapi";

    public static final Namespace NS_UNQUAL = Namespace.get(URI_PMAPI);
    public static final Namespace NS_QUAL = Namespace.get("pmapi", URI_PMAPI);
}

