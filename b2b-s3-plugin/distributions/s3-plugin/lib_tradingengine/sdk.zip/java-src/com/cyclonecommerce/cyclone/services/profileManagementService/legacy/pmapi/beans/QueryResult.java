// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.BapiConstants;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Cursor;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.util.ArrayList;
import java.util.Iterator;

public class QueryResult
{
    private Cursor cursor;
    private String[] organizationIds;

    public QueryResult()
    {
        super();
    }

    public QueryResult(Element root)
    {
        Element cursorElem = root.element(BapiConstants.QN_CURSOR);
        if (cursorElem != null)
            setCursor(new Cursor(cursorElem));

        ArrayList<String> list = new ArrayList<String>();
        Iterator it = root.elementIterator(BapiConstants.ORGANIZATION_ID);
        while (it.hasNext())
        {
            Element elem = (Element)it.next();
            list.add(elem.getText());
        }

        String[] array = new String[list.size()];
        list.toArray(array);
        setOrganizationIds(array);
    }

    public Cursor getCursor()
    {
        return cursor;
    }

    public void setCursor(Cursor cursor)
    {
        this.cursor = cursor;
    }

    public String[] getOrganizationIds()
    {
        return organizationIds;
    }

    public void setOrganizationIds(String[] organizationIds)
    {
        this.organizationIds = organizationIds;
    }

    public Element toElement()
    {
        QName qname = new QName(PmapiConstants.QUERY_RESULT, PmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (cursor != null)
            root.add(cursor.toElement());
        if (organizationIds != null)
        {
            for (String id : organizationIds)
                root.addElement(BapiConstants.ORGANIZATION_ID).setText(id);
        }

        return root;
    }
}
