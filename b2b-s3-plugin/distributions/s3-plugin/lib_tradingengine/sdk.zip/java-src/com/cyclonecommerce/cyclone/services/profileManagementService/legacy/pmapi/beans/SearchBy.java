// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.InvalidQueryException;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;


public class SearchBy
        implements Serializable
{
    // These constants would be a classic case for an "enum", but I can't get AXIS 1.3 to generate stubs with them (Bob K.)
    public static final int SEARCH_TYPE_MY_ORGANIZATION_ID = 0;
    public static final int SEARCH_TYPE_MY_PARTNERS = 1;
    public static final int SEARCH_TYPE_ADVANCED = 2;

    private int searchType;
    private String organizationName;
    private String[] communities;
    private OrganizationState organizationState;
    private String[] xpaths;

    public SearchBy()
    {
        super();
    }

    public SearchBy(Element root) throws InvalidQueryException
    {
        if (root.element(PmapiConstants.MY_ORGANIZATION_ID) != null)
        {
            setSearchType(SEARCH_TYPE_MY_ORGANIZATION_ID);
        }
        else if (root.element(PmapiConstants.MY_PARTNERS) != null)
        {
            setSearchType(SEARCH_TYPE_MY_PARTNERS);
        }
        else
        {
            setSearchType(SEARCH_TYPE_ADVANCED);
            Element elem = root.element(PmapiConstants.ORGANIZATION_NAME);
            if (elem != null)
                setOrganizationName(elem.getText());

            elem = root.element(PmapiConstants.COMMUNITIES);
            if (elem != null)
            {
                ArrayList<String> list = new ArrayList<String>();
                Iterator it = root.elementIterator(PmapiConstants.COMMUNITY);
                while (it.hasNext())
                {
                    elem = (Element)it.next();
                    list.add(elem.getText());
                }
                String[] array = new String[list.size()];
                list.toArray(array);
                setCommunities(array);
            }

            elem = root.element(PmapiConstants.ORGANIZATION_QUERY);
            if (elem != null)
            {
                setOrganizationState(new OrganizationState(elem));
            }

            ArrayList<String> list = new ArrayList<String>();
            Iterator it = root.elementIterator(PmapiConstants.XPATH);
            while (it.hasNext())
            {
                elem = (Element)it.next();
                list.add(elem.getText());
            }
            String[] array = new String[list.size()];
            list.toArray(array);
            setXpaths(array);
        }
    }

    public int getSearchType()
    {
        return searchType;
    }

    public void setSearchType(int searchType)
    {
        if (searchType < SEARCH_TYPE_MY_ORGANIZATION_ID || searchType > SEARCH_TYPE_ADVANCED)
            throw new IllegalArgumentException("Invalid search type argument, value=" + searchType + ".");

        this.searchType = searchType;
    }

    public String getOrganizationName()
    {
        return organizationName;
    }

    public void setOrganizationName(String organizationName)
    {
        if (organizationName != null)
            setSearchType(SEARCH_TYPE_ADVANCED);
        this.organizationName = organizationName;
    }

    public String[] getCommunities()
    {
        return communities;
    }

    public void setCommunities(String[] communities)
    {
        if (communities != null && communities.length > 0)
            setSearchType(SEARCH_TYPE_ADVANCED);
        this.communities = communities;
    }

    public OrganizationState getOrganizationState()
    {
        return organizationState;
    }

    public void setOrganizationState(OrganizationState organizationState)
    {
        if (organizationState != null)
            setSearchType(SEARCH_TYPE_ADVANCED);
        this.organizationState = organizationState;
    }

    public String[] getXpaths()
    {
        return xpaths;
    }

    public void setXpaths(String[] xpaths)
    {
        if (xpaths != null && xpaths.length > 0)
            setSearchType(SEARCH_TYPE_ADVANCED);
        this.xpaths = xpaths;
    }

    public Element toElement()
    {
        QName qname = new QName(PmapiConstants.SEARCH_BY, PmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);

        if (searchType == SEARCH_TYPE_MY_ORGANIZATION_ID)
            root.addElement(PmapiConstants.MY_ORGANIZATION_ID);
        else if (searchType == SEARCH_TYPE_MY_PARTNERS)
            root.addElement(PmapiConstants.MY_PARTNERS);
        else
        {
            if (organizationName != null)
            {
                root.addElement(PmapiConstants.ORGANIZATION_NAME).setText(organizationName);
            }
            if (communities != null && communities.length > 0)
            {
                Element elem = root.addElement(PmapiConstants.COMMUNITIES);
                for (String community : communities)
                    elem.addElement(PmapiConstants.COMMUNITY).setText(community);
            }
            if (organizationState != null)
            {
                root.add(organizationState.toElement());
            }
            if (xpaths != null)
            {
                for (String xpath : xpaths)
                    root.addElement(PmapiConstants.XPATH).setText(xpath);
            }

        }

       return root;
    }
}
