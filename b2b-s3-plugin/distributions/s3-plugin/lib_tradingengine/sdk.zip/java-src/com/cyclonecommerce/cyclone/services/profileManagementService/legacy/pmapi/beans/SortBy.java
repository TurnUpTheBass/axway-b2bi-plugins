// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;

import java.io.Serializable;

public class SortBy
        implements Serializable
{
    // These constants would be a classic case for an "enum", but I can't get AXIS 1.3 to generate stubs with them (Bob K.)
    public static final int SORT_TYPE_ORGANIZATION_NAME_ASC = 0;
    public static final int SORT_TYPE_ORGANIZATION_NAME_DESC = 1;
    public static final int SORT_TYPE_MODIFIED_DATE = 2;
    public static final int SORT_TYPE_XPATH = 3;

    private int sortType;

    public SortBy()
    {
        super();
    }

    public SortBy(Element root)
    {
        Element elem = root.element(PmapiConstants.ORGANIZATION_NAME);
        if (elem != null)
        {
            String asc = elem.attributeValue(PmapiConstants.ASCENDING);
            if ("false".equalsIgnoreCase(asc))
                setSortType(SORT_TYPE_ORGANIZATION_NAME_DESC);
            else
                setSortType(SORT_TYPE_ORGANIZATION_NAME_ASC);
        }
        elem = root.element(PmapiConstants.MODIFIED_DATE);
        if (elem != null)
        {
            setSortType(SORT_TYPE_MODIFIED_DATE);
        }
        elem = root.element(PmapiConstants.XPATH);
        if (elem != null)
        {
            setSortType(SORT_TYPE_XPATH);
        }
    }

    public int getSortType()
    {
        return sortType;
    }

    public void setSortType(int sortType)
    {
        if (sortType < SORT_TYPE_ORGANIZATION_NAME_ASC || sortType > SORT_TYPE_XPATH)
            throw new IllegalArgumentException("Invalid sort type argument, value=" + sortType + ".");
        this.sortType = sortType;
    }

    public Element toElement()
    {
        QName qname = new QName(PmapiConstants.SORT_BY, PmapiConstants.NS_UNQUAL);
        Element root = DocumentHelper.createElement(qname);
        if (sortType == SORT_TYPE_ORGANIZATION_NAME_ASC)
        {
            Element elem = root.addElement(PmapiConstants.ORGANIZATION_NAME);
            elem.addAttribute(PmapiConstants.ASCENDING, "true");
        }
        else if (sortType == SORT_TYPE_ORGANIZATION_NAME_DESC)
        {
            Element elem = root.addElement(PmapiConstants.ORGANIZATION_NAME);
            elem.addAttribute(PmapiConstants.ASCENDING, "false");
        }
        else if (sortType == SORT_TYPE_MODIFIED_DATE)
        {
            root.addElement(PmapiConstants.MODIFIED_DATE);
        }
        else if (sortType == SORT_TYPE_XPATH)
        {
            root.addElement(PmapiConstants.XPATH);
        }

        return root;
    }

}
