// Copyright (c) Axway Software. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ebics;

public class EbicsCertificateElement
{
    private String certificateId;
    private String certificateFriendlyName;
    private String certificateSubjectName;
    private String certificateSerialNumber;
    private String certificateUsage;

    public EbicsCertificateElement()
    {}


    public String getCertificateId()
    {
        return certificateId;
    }

    public void setCertificateId(String certificateId)
    {
        this.certificateId = certificateId;
    }

    public String getCertificateFriendlyName()
    {
        return certificateFriendlyName;
    }

    public void setCertificateFriendlyName(String certificateFriendlyName)
    {
        this.certificateFriendlyName = certificateFriendlyName;
    }

    public String getCertificateSubjectName()
    {
        return certificateSubjectName;
    }

    public void setCertificateSubjectName(String certificateSubjetName)
    {
        this.certificateSubjectName = certificateSubjetName;
    }

    public String getCertificateSerialNumber()
    {
        return certificateSerialNumber;
    }

    public void setCertificateSerialNumber(String certificateSerialNumber)
    {
        this.certificateSerialNumber = certificateSerialNumber;
    }

    public String getCertificateUsage()
    {
        return certificateUsage;
    }

    public void setCertificateUsage(String certificateUsage)
    {
        this.certificateUsage = certificateUsage;
    }
}
