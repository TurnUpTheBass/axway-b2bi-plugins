// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ebics;


public class EbicsElement
{
    private EbicsGetElement ebicsGetElement;

    public EbicsGetElement getEbicsGetElement()
    {
        return ebicsGetElement;
    }

    public void setEbicsGetElement(EbicsGetElement ebicsGetElement)
    {
        this.ebicsGetElement = ebicsGetElement;
    }
}
