// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ebics;

import java.util.List;

public class EbicsGetElement
{
    private List<EbicsPartyElement> partyList;
    private List<EbicsUserElement> ebicsUserList;
    EbicsUserInfoElement ebicsUserInfo;
    private List<EbicsCertificateElement> ebicsCertificateList;

    public EbicsGetElement()
    {

    }

    public EbicsGetElement(List<EbicsPartyElement> partyList)
    {
        this.partyList = partyList;
    }

    public List<EbicsPartyElement> getPartyList()
    {
        return partyList;
    }

    public void setPartyList(List<EbicsPartyElement> partyList)
    {
        this.partyList = partyList;
    }

    public List<EbicsUserElement> getEbicsUserList()
    {
        return ebicsUserList;
    }

    public void setEbicsUserList(List<EbicsUserElement> ebicsUserList)
    {
        this.ebicsUserList = ebicsUserList;
    }

    public EbicsUserInfoElement getEbicsUserInfo()
    {
        return ebicsUserInfo;
    }

    public void setEbicsUserInfo(EbicsUserInfoElement ebicsUserInfo)
    {
        this.ebicsUserInfo = ebicsUserInfo;
    }

    public List<EbicsCertificateElement> getEbicsCertificateList()
    {
        return ebicsCertificateList;
    }

    public void setEbicsCertificateList(List<EbicsCertificateElement> ebicsCertificateList)
    {
        this.ebicsCertificateList = ebicsCertificateList;
    }
}
