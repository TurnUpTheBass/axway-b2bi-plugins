// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ebics;

import java.util.List;

public class EbicsPartyElement
{
    private String partyId;
    private String partyName;
    private List<String> partyRoutingIds;

    public EbicsPartyElement()
    {
        super();
    }

    public EbicsPartyElement(String partyId, String partyName, List<String> partyRoutingIds)
    {
        this.partyId = partyId;
        this.partyName = partyName;
        this.partyRoutingIds = partyRoutingIds;
    }

    public String getPartyId()
    {
        return partyId;
    }

    public void setPartyId(String partyId)
    {
        this.partyId = partyId;
    }

    public String getPartyName()
    {
        return partyName;
    }

    public void setPartyName(String partyName)
    {
        this.partyName = partyName;
    }

    public List<String> getPartyRoutingIds()
    {
        return partyRoutingIds;
    }

    public void setPartyRoutingIds(List<String> partyRoutingIds)
    {
        this.partyRoutingIds = partyRoutingIds;
    }
}
