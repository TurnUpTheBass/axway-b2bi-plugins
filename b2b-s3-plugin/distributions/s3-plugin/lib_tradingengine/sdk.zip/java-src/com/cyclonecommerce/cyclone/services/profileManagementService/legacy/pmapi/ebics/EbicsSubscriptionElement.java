// Copyright (c) Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ebics;

import com.cyclonecommerce.collaboration.transport.ebics.users.EbicsSubscription;

public class EbicsSubscriptionElement
{
    private EbicsPartyElement ebicsPartyElement;
    private String subscriptionState;
    private String subscriptionOID;
    private String hostId;
    private String customerId;
    private String protocolVersion;
    private String signatureVersion;
    private String authenticationVersion;
    private String encryptionVersion;
    private String signatureCertId;
    private String authenticationCertId;
    private String encryptionCertId;

    public EbicsSubscriptionElement(EbicsPartyElement ebicsPartyElement, EbicsSubscription subscription)
    {
        this.ebicsPartyElement = ebicsPartyElement;
        this.subscriptionState = Integer.toString(subscription.getState());
        this.subscriptionOID = subscription.getObjectIdAsString();
        this.hostId = subscription.getHostId();
        this.customerId = subscription.getCustomerId();
        this.signatureVersion = subscription.getSignatureVersion().name();
        this.protocolVersion = subscription.getProtocolSubversion().name();
        this.authenticationVersion = subscription.getAuthenticationVersion();
        this.encryptionVersion = subscription.getEncryptionVersion();
        this.signatureCertId = subscription.getPersCertId().toString();
        this.authenticationCertId = subscription.getAuthCertId().toString();
        this.encryptionCertId = subscription.getEncrCertId().toString();
    }

    public EbicsPartyElement getEbicsPartyElement()
    {
        return ebicsPartyElement;
    }

    public void setEbicsPartyElement(EbicsPartyElement ebicsPartyElement)
    {
        this.ebicsPartyElement = ebicsPartyElement;
    }

    public String getSubscriptionState()
    {
        return subscriptionState;
    }

    public void setSubscriptionState(String subscriptionState)
    {
        this.subscriptionState = subscriptionState;
    }

    public String getSubscriptionOID()
    {
        return subscriptionOID;
    }

    public void setSubscriptionOID(String subscriptionOID)
    {
        this.subscriptionOID = subscriptionOID;
    }

    public String getHostId()
    {
        return hostId;
    }

    public void setHostId(String hostId)
    {
        this.hostId = hostId;
    }

    public String getCustomerId()
    {
        return customerId;
    }

    public void setCustomerId(String customerId)
    {
        this.customerId = customerId;
    }

    public String getProtocolVersion()
    {
        return protocolVersion;
    }

    public void setProtocolVersion(String protocolVersion)
    {
        this.protocolVersion = protocolVersion;
    }

    public String getSignatureVersion()
    {
        return signatureVersion;
    }

    public void setSignatureVersion(String signatureVersion)
    {
        this.signatureVersion = signatureVersion;
    }

    public String getAuthenticationVersion()
    {
        return authenticationVersion;
    }

    public void setAuthenticationVersion(String authenticationVersion)
    {
        this.authenticationVersion = authenticationVersion;
    }

    public String getEncryptionVersion()
    {
        return encryptionVersion;
    }

    public void setEncryptionVersion(String encryptionVersion)
    {
        this.encryptionVersion = encryptionVersion;
    }

    public String getSignatureCertId()
    {
        return signatureCertId;
    }

    public void setSignatureCertId(String signatureCertId)
    {
        this.signatureCertId = signatureCertId;
    }

    public String getAuthenticationCertId()
    {
        return authenticationCertId;
    }

    public void setAuthenticationCertId(String authenticationCertId)
    {
        this.authenticationCertId = authenticationCertId;
    }

    public String getEncryptionCertId()
    {
        return encryptionCertId;
    }

    public void setEncryptionCertId(String encryptionCertId)
    {
        this.encryptionCertId = encryptionCertId;
    }
}
