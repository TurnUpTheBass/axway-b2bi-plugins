// Copyright (c) Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ebics;


public class EbicsUserElement
{
    private String userId;
    private String userName;
    private String ebicsId;
    private boolean isEnabled;
    private boolean isTransport;

    public EbicsUserElement(String userId, String userName, String ebicsId)
    {
        this(userId, userName, ebicsId, true, false);
    }

    public EbicsUserElement(String userId, String userName, String ebicsId, boolean enabled, boolean isTransport)
    {
        this.userId = userId;
        this.userName = userName;
        this.ebicsId = ebicsId;
        this.isEnabled = enabled;
        this.isTransport = isTransport;
    }

    public String getUserId()
    {
        return userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getUserName()
    {
        return userName;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getEbicsId()
    {
        return ebicsId;
    }

    public void setEbicsId(String ebicsId)
    {
        this.ebicsId = ebicsId;
    }

    public void isTransport(boolean isTransport)
    {
        this.isTransport = isTransport;
    }

    public boolean isTransport()
    {
        return this.isTransport;
    }

    public void isEnabled(boolean enabled)
    {
        this.isEnabled = enabled;
    }

    public boolean isEnabled()
    {
        return this.isEnabled;
    }

}
