// Copyright (c) 1996-2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ebics;

import java.util.List;

public class EbicsUserInfoElement
{

    private EbicsUserElement ebicsUserElement;
    private List<EbicsSubscriptionElement> ebicsSubscriptionElementList;

    public EbicsUserInfoElement()
    {

    }

    public EbicsUserInfoElement(EbicsUserElement ebicsUserElement, List<EbicsSubscriptionElement> ebicsSubscriptionElementList)
    {
        this.ebicsUserElement = ebicsUserElement;
        this.ebicsSubscriptionElementList = ebicsSubscriptionElementList;
    }

    public EbicsUserElement getEbicsUserElement()
    {
        return ebicsUserElement;
    }

    public void setEbicsUserElement(EbicsUserElement ebicsUserElement)
    {
        this.ebicsUserElement = ebicsUserElement;
    }

    public List<EbicsSubscriptionElement> getEbicsSubscriptionElementList()
    {
        return ebicsSubscriptionElementList;
    }

    public void setEbicsSubscriptionElementList(List<EbicsSubscriptionElement> ebicsSubscriptionElementList)
    {
        this.ebicsSubscriptionElementList = ebicsSubscriptionElementList;
    }
}
