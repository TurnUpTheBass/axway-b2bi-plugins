// Copyright (c) $smartDate Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.io.DOMReader;
import org.dom4j.io.DOMWriter;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.List;

public class ElementUtil
{
	private static final Logger logger = LogManager.getLogger(ElementUtil.class);

	private static TransformerFactory tFactory = TransformerFactory.newInstance();
	private static final ThreadLocal<Transformer> transformers = new ThreadLocal<Transformer>();

	public static Element toDom4JElement(org.w3c.dom.Element domElement)
	{
		DOMElementReader reader = new DOMElementReader();
		return reader.read(domElement);
	}

	public static org.w3c.dom.Element toDomElement(Element elem)
	{
		org.w3c.dom.Element element;
		try
		{
			DOMWriter domWriter = new DOMWriter();
			Document doc = DocumentHelper.createDocument(elem.createCopy());
			element = domWriter.write(doc).getDocumentElement();
		}
		catch (Exception e)
		{
			throw new RuntimeException("asDOMNode caught Exception", e);
		}
		return element;
	}

	public static void write(Element elem, OutputStream out) throws IOException
	{
		OutputFormat format = OutputFormat.createPrettyPrint();
		format.setSuppressDeclaration(true);
		XMLWriter writer = new XMLWriter(out, format);
		writer.write(elem);
	}

	public static void write(Element elem, Writer writer) throws IOException
	{
		OutputFormat format = OutputFormat.createPrettyPrint();
		format.setSuppressDeclaration(true);
		XMLWriter xmlWriter = new XMLWriter(writer, format);
		xmlWriter.write(elem);
	}

	public static void write(org.w3c.dom.Element elem, OutputStream out) throws IOException
	{
		DOMSource source = new DOMSource(elem);
		StreamResult result = new StreamResult(out);
		try
		{
			getTransformer().transform(source, result);
		}
		catch (TransformerException e)
		{
			String msg = "Unable to write element to output stream, cause: " + e;
			logger.warn(msg, e);
			throw new IOException(msg, e);
		}
	}

	public static void write(org.w3c.dom.Element elem, Writer writer) throws IOException
	{
		DOMSource source = new DOMSource(elem);
		StreamResult result = new StreamResult(writer);
		try
		{
			getTransformer().transform(source, result);
		}
		catch (TransformerException e)
		{
			String msg = "Unable to write element to output stream, cause: " + e;
			logger.warn(msg, e);
			throw new IOException(msg, e);
		}
	}

	public static void setNamespace(Element root, Namespace ns)
	{
		Namespace currentNs = root.getNamespace();
		if (currentNs != null)
			root.remove(currentNs);
		root.add(ns);
		Iterator it = root.elementIterator();
		while (it.hasNext())
		{
			Element element = (Element)it.next();
			if (element.getNamespace() == currentNs)
				setNamespace(element, ns);
		}
	}

	public static Object createFromElement(Element elem)
	{
		String clsName = elem.attributeValue("class");
		if (clsName == null || clsName.trim().length() == 0)
			return null;
		try
		{
			Class cls = Class.forName(clsName);
			List children = elem.elements();
			if (!children.isEmpty())
			{
				Element paramElem = (Element)children.get(0);
				Class[] params = new Class[]{Element.class};
				try
				{
					Constructor c = cls.getDeclaredConstructor(params);
					return c.newInstance(paramElem);
				}
				catch (NoSuchMethodException e)
				{
					return cls.newInstance();
				}
			}
			else
			{
				return cls.newInstance();
			}
		}
		catch (ClassNotFoundException e)
		{
			logger.error("Class: '" + clsName + "' not found.", e);
			return null;
		}
		catch (Exception e)
		{
			logger.error("Could not instantiate class: '" + clsName + "'.", e);
			return null;
		}
	}

	/**
	 * Inner class used to convert org.w3c.dom Elements to DOM4J elements.
	 */
	private static class DOMElementReader extends DOMReader
	{
		public DOMElementReader()
		{
			super();
		}

		public Element read(org.w3c.dom.Node domNode)
		{
			if (domNode instanceof Element)
			{
				return (Element)domNode;
			}

			Document document = DOMElementReader.this.createDocument();
			clearNamespaceStack();
			readTree(domNode, document);

			return document.getRootElement();
		}
	}

	private static Transformer getTransformer()
	{
		Transformer transformer = transformers.get();
		if (transformer == null)
		{
			try
			{
				transformer = tFactory.newTransformer();
				transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.setOutputProperty(OutputKeys.METHOD, "xml");
				transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
				transformers.set(transformer);
			}
			catch (TransformerConfigurationException e)
			{
				String msg = "Unable to create a transformer to output XML data, cause: " + e;
				logger.error(msg, e);
				throw new RuntimeException(msg, e);
			}
		}
		return transformer;
	}

	private ElementUtil()
	{
		super();
	}
}
