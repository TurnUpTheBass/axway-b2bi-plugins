/**
 * SessionService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.sessionService;

public interface SessionService extends java.rmi.Remote {

    /**
     * Create a new user session with Interchange and return the Session
     * Cookie. Idle sessions will be closed by Interchange after a configurable
     * timeout.
     */
    public byte[] login(java.lang.String userId, java.lang.String password) throws java.rmi.RemoteException, com.cyclonecommerce.cyclone.services.sessionService.InvalidCredentialsException;

    /**
     * Close an open Interchange session. All open sessions should
     * be closed!
     */
    public void logout(byte[] cookie) throws java.rmi.RemoteException, com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException;

    /**
     * Refresh an open session. Calling refresh will reset the automatic
     * logout of an idle session. The default idle session time out is 30
     * minutes. In general
     *             it is not good leave sessions idle.
     */
    public void refreshSession(byte[] cookie) throws java.rmi.RemoteException, com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException;
}
