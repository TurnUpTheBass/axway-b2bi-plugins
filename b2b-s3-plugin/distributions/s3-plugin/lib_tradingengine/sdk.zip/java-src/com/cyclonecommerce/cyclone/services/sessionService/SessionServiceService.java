/**
 * SessionServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.sessionService;

public interface SessionServiceService extends javax.xml.rpc.Service {

/**
 * Interchange Webservice for opening user's sessions with an Interchange
 * Control Node Instance.
 */
    public java.lang.String getSessionServiceAddress();

    public com.cyclonecommerce.cyclone.services.sessionService.SessionService getSessionService() throws javax.xml.rpc.ServiceException;

    public com.cyclonecommerce.cyclone.services.sessionService.SessionService getSessionService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
