/**
 * SessionServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2 May 03, 2005 (02:20:24 EDT) WSDL2Java emitter.
 */

package com.cyclonecommerce.cyclone.services.sessionService;

public class SessionServiceServiceLocator extends org.apache.axis.client.Service implements com.cyclonecommerce.cyclone.services.sessionService.SessionServiceService {

/**
 * Interchange Webservice for opening user's sessions with an Interchange
 * Control Node Instance.
 */

    public SessionServiceServiceLocator() {
    }


    public SessionServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public SessionServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for SessionService
    private java.lang.String SessionService_address = "http://localhost:6080/cyclone/services/SessionService";

    public java.lang.String getSessionServiceAddress() {
        return SessionService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String SessionServiceWSDDServiceName = "SessionService";

    public java.lang.String getSessionServiceWSDDServiceName() {
        return SessionServiceWSDDServiceName;
    }

    public void setSessionServiceWSDDServiceName(java.lang.String name) {
        SessionServiceWSDDServiceName = name;
    }

    public com.cyclonecommerce.cyclone.services.sessionService.SessionService getSessionService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(SessionService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getSessionService(endpoint);
    }

    public com.cyclonecommerce.cyclone.services.sessionService.SessionService getSessionService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub _stub = new com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getSessionServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setSessionServiceEndpointAddress(java.lang.String address) {
        SessionService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.cyclonecommerce.cyclone.services.sessionService.SessionService.class.isAssignableFrom(serviceEndpointInterface)) {
                com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub _stub = new com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub(new java.net.URL(SessionService_address), this);
                _stub.setPortName(getSessionServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("SessionService".equals(inputPortName)) {
            return getSessionService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/sessionService", "SessionServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://cyclonecommerce.com/cyclone/services/sessionService", "SessionService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        if ("SessionService".equals(portName)) {
            setSessionServiceEndpointAddress(address);
        }
        else { // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
