// Copyright (c) 1996-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.inlineprocess;

import com.cyclonecommerce.collaboration.MetadataDictionary;
import com.cyclonecommerce.api.inlineprocessing.Message;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;
import java.util.Iterator;

/**
 * In-line processor that prints information about the Message being processed to log4j debug output.  The information
 * displayed contains the message Id, the metadata available at the point the process method is called, and the parameter
 * configured in the UI.  This in-line processor can be configured at either the consuming exchange point, the message handler,
 * or the production exchange point.  In either place, the same code is used.
 *
 * <p>All in-line processor implementations must implement the MessageProcessor interface.
 *
 * <p>The container dynamically creates an instance of this class using the default constructor, initializes
 * it by calling <code>setParameters</code>, and passes the <code>Message</code> object being processed.  Care should
 * be taken not to perform long-running processes as this might have affect the performance of message processing.
 *
 * <p>
 * Sample output:<pre>
 2004-08-20 16:29:26 - [Worker4-7] DEBUG (DisplayMessageInfo.process:?) - Information for message#JAPPLEGATE-T40_te1093044565169.312@JAPPLEGATE-T40 - from message handler<br>
	 CsosSigningAlgorithm - "SHA1"
	 RejectedReason - null
	 ProductionFilename - "ZZoffice_TO_ZZredfish_11017.edi"
	 ContentMimeType - "application/x-csos-signed-order"
	 ediint.IsMDN - "false"
	 DocumentType - "CSOS Purchase Order"
	 EdiControlId - null
	 ReceiverRoutingIdType - null
	 Rejected - "false"
	 BusinessProtocolVersion - "1.0"
	 CsosOrderSchedule - "7e"
	 SenderRoutingIdType - null
	 IsDuplicate - "false"
	 ConsumptionExchangePointId - "70510"
	 CoreId - "JAPPLEGATE-T40_te1093044565169.312@JAPPLEGATE-T40"
	 IntegrationId - null
	 ConsumptionFilename - "ZZoffice_TO_ZZredfish_11017.edi"
	 ReceiverRoutingId - null
	 CsosSigningCertificateId - "C1092788275498.2703@JAPPLEGATE-T40"
	 SenderRoutingId - null
	 BusinessProtocol - "ASx"
	 CsosPoNumber - "04X000028"
	 ProductionUrl - null
	 IsSignedOrder - "true"
	 SenderPartyId - "2525"
	 ReceiverPartyId - "610"
	 from message handler - "from message handler"
	 CsosDeaRegistrationNumber - "CD2345678"
 </pre>
 *
 * <br>
 * <p>To configure DisplayMessageInfo as an inline processor at either a consumer or producer exchange point, edit that
 * exchange point and click on the "Inline Process" tab.
 *
 * <p>To configure DisplayMessageInfo to run in the Message Handler, click on the Message Handler icon on the Community
 * configuration page.  Add a Message Processing Action to be invoked based on some criteria.  For example,
 * "isReceipt == false".
 *
 * <p>In either case, provide the name of this class (examples.inlineprocess.DisplayMessageInfo) and a parameter.  The
 * parameter will be displayed in the message info.
 *
 * <p>Using log4j2
 * <ul>
 * <li>You can use log4j2 to log error, warning, informational, and debug messages.
 * <li>Placing the following in conf/log4j2.xml will activate logging for all examples (no need to restart):  <code><Logger name="examples" level="DEBUG" /></code>
 * <li>You can also turn logging on/off for a particular subpackage.  Refer to conf/log4j2.xml for more information how to configure the logging
 * <li>The control node and the trading engine node may both potentially instantiate your client, so you should
 * look for log messages in both <machine_name>_cn.log and <machine_name>_te<n>.log.
 * </ul>
 * <br>
 *
 *
 *
 */
public class DisplayMessageInfo implements com.cyclonecommerce.api.inlineprocessing.MessageProcessor {

	/** this is how you get the log4J logger instance for this class */
	private static Logger logger = LogManager.getLogger(examples.inlineprocess.DisplayMessageInfo.class);

	/** this is the parameter passed in from the UI */
	private String param = null;

	/**
	 * Default constructor - the only constructor used by Interchange
	 */
	public DisplayMessageInfo() {
		// nothing to do
	}

	/**
	 * Accepts the parameter configured in the UI and stores it locally for later use
	 * @param param the parameter configured in the UI for the in-line processor
s	 */
	public void setParameters(String param) {
		// store the parameter if it's not null or empty
		if (param!=null && param.length()!=0)
			this.param = param;
	}

	/**
	 * Displays information about the Message being processed in the log4j logs.
	 *
	 * @param message the message being processed
	 */
	public void process(Message message) {
		// should never happen but you never know
		if (message == null)
			throw new IllegalArgumentException("Message parameter cannot be null");

		try {
			// this is how you set metadata in the message class
			message.setMetadata(param, param);

			// get all metadata items and iterate over them appending the info to a StringBuffer
			Map metadata = message.getMetadata();
			Iterator i = metadata.keySet().iterator();
			String messageId = message.getMetadata(MetadataDictionary.CORE_ID);
			StringBuffer sb = new StringBuffer("Information for message#").append(messageId).append(" - ").append(param).append("\n");
			while (i.hasNext()) {
				String key = (String)i.next();
				String val = message.getMetadata(key);
				if ( val != null ) {
					sb.append("\t").append(key).append(" - \"").append(val).append("\"\n");
				} else {
					sb.append("\t").append(key).append(" - null\n");
				}
			}
			// send the StringBuffer to log4j
			logger.debug(sb.toString());

		} catch (Exception e) {
			// always catch your Exceptions
			logger.debug("Failed to display the message information", e);
		}
	}

}
