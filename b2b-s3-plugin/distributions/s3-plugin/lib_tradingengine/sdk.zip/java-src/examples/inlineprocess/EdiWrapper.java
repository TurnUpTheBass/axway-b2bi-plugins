// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.inlineprocess;

import com.axway.util.StringUtil;
import com.cyclonecommerce.api.inlineprocessing.Message;
import com.cyclonecommerce.api.splitter.SplitAbortReason;
import com.cyclonecommerce.api.splitter.Splitter;
import com.cyclonecommerce.api.splitter.SplitterDestinationFactory;
import com.cyclonecommerce.api.splitter.SplitterException;
import com.cyclonecommerce.collaboration.MetadataDictionary;
import com.cyclonecommerce.splitter.EdiSplitter;
import com.cyclonecommerce.splitter.SplitterConfiguration;
import com.cyclonecommerce.util.VirtualData;
import com.cyclonecommerce.util.VirtualDataInputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

/**
 * In-line processor that forces an EDI file to be writen in a specific format.
 *
 * There are four properties that can be set for the format:  LineEnder,
 * LineEnderAfterSegTerm, LineEnderCol, and AddLF.
 *
 * These  properties can be specified both globally and on a receiver-
 * specific basis.  The receiver-specific ones include a dot followed by
 * the receiver ID at the end of the name.  For example, LineEnder.abc
 * would specify the LineEnder value for all interchanges having receiver
 * ID abc in the header segment.  It would override any global values
 * which may have been specified.
 *
 * If the receiver's ID contains spaces, equals signs (=) or colons (:),
 * they must be prefixed by backslashes.  For example, if the receiver ID
 * is "Big Beets", you would specify LineEnder.Big\ Beets as the property
 * name.
 *
 * The receiver ID is determined by looking at field 8 of the ISA (or field
 * 3, subfield 1 of the UNB) and stripping any leading and trailing white
 * space.  Note:  Case is respected.
 *
 * It is only necessary to define output format properties for receivers
 * which require a specific output format.  For all other receivers you
 * can allow the global values to take effect.  Or if you want all the
 * output files to be in the same format as the input files, you do not
 * need to specify any output formatting properties at all, because the
 * default behavior is to write the output files in the same format as
 * the input files.
 *
 * LineEnder
 * Hex character to be used as a line ender.  For Unix-based receivers
 * you would typically specify 0A (and AddLF as 0).  For Windows-based
 * receivers you would typically specify 0D (and AddLF as 1).
 *
 * To simply use the line ender from the input data (whatever it may be),
 * specify "-1".  If you specify -1 and the input file has no line ender,
 * yet the output file needs one because of the setting of
 * LineEnderAfterSegTerm or LineEnderCol, a line feed will be used as
 * the default line ender.
 *
 * Examples:
 * LineEnder=0D
 *
 * LineEnderAfterSegTerm
 * This property determines whether the specified receiver requires a
 * line ender character after each segment terminator (sometimes referred
 * to as "unwrapped" format).  Possible values:
 *
 *	0	do NOT insert a line ender after the segment terminator
 *	1	insert a line ender after the segment terminator
 *	-1	use same behavior as input data (default)
 *
 * Examples:
 * LineEnderAfterSegTerm=1
 *
 * LineEnderCol
 * This property is used to specify a fixed column in which a line ender
 * character is to be inserted.  Effectively it enforces a right margin
 * in output files bound for the specified receiver.  Normally this
 * property is used to create "wrapped" files, although if used in
 * conjunction with the LineEnderAfterSegTerm property it can be used to
 * create unwrapped files in which long lines are wrapped at a fixed
 * right margin.  Possible values:
 *
 *	0	no right margin ("pure" or "stream" output)
 *	81	insert line ender in column 81
 *	133	insert line ender in column 133
 *	-1	use same behavior as input data (default)
 *
 * Note: Fixed column positions other than 81 and 133 are NOT supported.
 *
 * Examples:
 * LineEnderCol=81
 *
 * AddLF
 * This property specifies whether a line feed is to be inserted
 * following the line ender if the line ender is a carriage return.
 * Normally you would specify "1" for Windows-based receivers.
 * Possible values:
 *
 *	0	do not add a line feed
 *	1	add a line feed (if the line ender is a carriage return)
 *	-1	use same behavior as input data (default)
 *
 * Examples:
 * AddLF=1
 *
 *
 * <p>All in-line processor implementations must implement the MessageProcessor interface.
 *
 * <p>The container dynamically creates an instance of this class using the default constructor, initializes
 * it by calling <code>setParameters</code>, and passes the <code>Message</code> object being processed.  Care should
 * be taken not to perform long-running processes as this might have affect the performance of message processing.
 *
 * <p>To configure EdiWrapper as an inline processor at either a consumer or producer exchange point, edit that
 * exchange point and click on the "Inline Process" tab.
 *
 * <p>To configure EdiWrapper to run in the Message Handler, click on the Message Handler icon on the Community
 * configuration page.  Add a Message Processing Action to be invoked based on some criteria.  For example,
 * "lineEnder=0D; lineEnderAfterSegTerm=0; lineEnderCol=81; addLF=1".
 *
 * <p>In either case, provide the name of this class (examples.inlineprocess.EdiWrapper) and a parameter.  The
 * parameter will be displayed in the message info.
 *
 * <p>Using log4j2
 * <ul>
 * <li>You can use log4j2 to log error, warning, informational, and debug messages.
 * <li>Placing the following in conf/log4j2.xml will activate logging for all examples (no need to restart):  <code><Logger name="examples" level="DEBUG" /></code>
 * <li>You can also turn logging on/off for a particular subpackage.  Refer to conf/log4j2.xml for more information how to configure the logging
 * <li>The control node and the trading engine node may both potentially instantiate your client, so you should
 * look for log messages in both <machine_name>_cn.log and <machine_name>_te<n>.log.
 * </ul>
 * <br>
 *
 */
public class EdiWrapper
		implements com.cyclonecommerce.api.inlineprocessing.MessageProcessor
{
	private static Logger logger = LogManager.getLogger(EdiWrapper.class);

	private final String LINE_ENDER = "lineEnder";
	private final String LINE_ENDER_AFTER_SEG_TERM = "lineEnderAfterSegTerm";
	private final String LINE_ENDER_COL = "lineEnderCol";
	private final String ADD_LF = "addLF";
	private final String DELIMITER = ";";

	private int lineEnder;
	private int lineEnderAfterSegTerm;
	private int lineEnderCol;
	private int addLF;

	/**
	 * Default constructor
	 */
	public EdiWrapper()
	{
	}

	/**
	 * Sets the parameters for this MessageProcessor instance.  This method is called prior immediately after
	 * the class is instantiated and just prior to invocation of process(). The parameter argument to this
	 * method is optional data provided by the Application Administrator when configuring an In-line Processor.
	 * The is a single String value.  If multiple parameters are desired, you could have this String contain multiple
	 * comma-separated values or reference an external configuration file.
	 *
	 * @param parameters a <code>String</code> containing the parameters for this message processor instance;
	 * may be <code>null</code>
	 */
	public void setParameters(String params)
	{
		if (!StringUtil.isNullEmptyOrBlank(params))
		{
			try
			{
				params = params.trim() + DELIMITER;

				int index = params.indexOf(LINE_ENDER);
				if (index == -1)
				{
					logger.warn("Parameter " + LINE_ENDER + " not set for inline processor EdiWrapper");
					throw new IllegalArgumentException("Parameter not set: " + LINE_ENDER);
				}
				String value = params.substring(index + LINE_ENDER.length() + 1, params.indexOf(DELIMITER, index));
				lineEnder = Integer.parseInt(value.trim(), 16);

				index = params.indexOf(LINE_ENDER_AFTER_SEG_TERM);
				if (index == -1)
				{
					logger.warn("Parameter " + LINE_ENDER_AFTER_SEG_TERM + " not set for inline processor EdiWrapper");
					throw new IllegalArgumentException("Parameter not set:" + LINE_ENDER_AFTER_SEG_TERM);
				}
				value = params.substring(index + LINE_ENDER_AFTER_SEG_TERM.length() + 1, params.indexOf(DELIMITER, index));
				lineEnderAfterSegTerm = Integer.parseInt(value.trim());

				index = params.indexOf(LINE_ENDER_COL);
				if (index == -1)
				{
					logger.warn("Parameter " + LINE_ENDER_COL + " not set for inline processor EdiWrapper");
					throw new IllegalArgumentException("Parameter not set: " + LINE_ENDER_COL);
				}
				value = params.substring(index + LINE_ENDER_COL.length() + 1, params.indexOf(DELIMITER, index));
				lineEnderCol = Integer.parseInt(value.trim());

				index = params.indexOf(ADD_LF);
				if (index == -1)
				{
					logger.warn("Parameter " + ADD_LF + " not set for inline processor EdiWrapper");
					throw new IllegalArgumentException("Parameter not set: " + ADD_LF);
				}
				value = params.substring(index + ADD_LF.length() + 1, params.indexOf(DELIMITER, index));
				addLF = Integer.parseInt(value.trim());

			}
			catch (Exception e)
			{
				throw new IllegalArgumentException("Invalid parameters string.");
			}
		}
	}

	/**
	 * Invokes this message processor instance to process a given {@link com.cyclonecommerce.api.inlineprocessing.Message}.
	 * Thisis where custom processing logic is implemented. The parameter to this method provides access to the payload
	 * and contains all the meta-data gathered to this point. The developer is free to read/modify the document, or
	 * add replace the exisitng content as needed. Any changes made to the document will automatically be persisted
	 * to Cyclone Interchange's persistent store after the process() method returns.
	 *
	 * @param message the <code>Message</code> to process
	 */
	public void process(Message message)
	{
		if (message == null)
			throw new IllegalArgumentException("Message parameter cannot be null");

		try
		{
			String contentMimeType = message.getMetadata(MetadataDictionary.CONTENT_MIME_TYPE);
			Splitter splitter = SplitterConfiguration.getInstance().getSplitter(contentMimeType);

			if (splitter == null)
			{
				if (logger.isDebugEnabled())
					logger.debug("Unable to construct splitter to wrap " + contentMimeType + " document");
			}
			else
			{
				BufferedInputStream bufin = new BufferedInputStream(new VirtualDataInputStream(message.getData()));
				MyDestinationFactory factory = new MyDestinationFactory();

				splitter.setInput(bufin);
				((EdiSplitter)splitter).setWrappingParameters(lineEnder, lineEnderAfterSegTerm, lineEnderCol, addLF);
				splitter.setDestinationFactory(factory);
				try
				{
					if (logger.isDebugEnabled())
						logger.debug("Attempting wrap of " + contentMimeType + " document");
					splitter.split();
					message.setData(new VirtualData((byte[])factory.getResults().get(0)));
				}
				catch (SplitterException e)
				{
					logger.warn("Unexpected exception from splitter " + splitter.getClass().getName(), e);
				}
				catch (IOException e)
				{
					logger.error("Unexpected exception from splitter " + splitter.getClass().getName(), e);
				}
			}
		}
		catch (Exception e)
		{
			logger.debug("Error", e);
		}
	}

	protected class MyDestinationFactory
			implements SplitterDestinationFactory
	{
		private ArrayList<byte[]> results = new ArrayList<byte[]>();
		private ArrayList<SplitAbortReason> abortedReasons = new ArrayList<SplitAbortReason>();

		public MyDestinationFactory()
		{
		}

		public OutputStream openOutputStream(int streamNumber) throws IOException
		{
			return new ByteArrayOutputStream();
		}

		public void abortedSplit(OutputStream out, SplitAbortReason reason) throws IOException
		{
			out.close();
			abortedReasons.add(reason);
		}

		public void successfulSplit(OutputStream out) throws IOException
		{
			out.close();
			results.add(((ByteArrayOutputStream)out).toByteArray());
		}

		public ArrayList getResults()
		{
			return results;
		}

		public ArrayList getAbortedReasons()
		{
			return abortedReasons;
		}
	}
}
