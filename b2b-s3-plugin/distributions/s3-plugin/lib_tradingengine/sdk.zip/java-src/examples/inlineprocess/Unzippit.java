// Copyright (c) 1996-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.inlineprocess;

import com.cyclonecommerce.collaboration.MetadataDictionary;
import com.cyclonecommerce.api.inlineprocessing.Message;
import com.cyclonecommerce.util.VirtualData;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

/**
 * In-line processor that execs an external batch script to unZIP the current payload.  The unzipped payload is added
 * to the message as the current content.  This in-line processor implementation implements the MessageProcessor interface.
 * <p>There are a couple assumptions:
 * <ul>
 * <li>the payload is a zipped archive containing a single file
 * <li>the archive filename has a .zip extension (as it was consumed into CI)
 * <li>the file contained in the archive has the same name as the archive minus the .zip extension
 * <li>there is a batch script called unzip.bat placed in CI's bin directory
 * </ul>
 *
 * <p>This class requires a batch script in CI's bin directory called "unzip.bat" that looks something like the
 * following.  There are slight differences between using pkzip and winzip.
 *
 * <p>Example of using PKZIP
 * <pre>
 echo off
 REM
 REM  This script unzips the specified archive using the password provided
 REM
 REM  param1 = directory where archive is located
 REM  param2 = filename of the archive
 REM  param3 = password to unlock the archive
 REM
 cd %1
 c:\\pkzip32\\pkzip25 -NoZipExtension -pass=%3 -ext -over=all -silent %2 >> c:\\cyclone\\b920\logs\\unzip_%2.log 2>&1
 </pre>
 * <p>Example of using WINZIP
 * <pre>
 echo off
 REM
 REM  This script unzips the specified archive using the password provided
 REM
 REM  param1 = directory where archive is located
 REM  param2 = filename of the archive
 REM  param3 = password to unlock the archive
 REM
 cd %1
 c:\\progra~1\\winzip\\wzunzip -O -s%3 %2 >> c:\\cyclone\\b920\\logs\\unzip_%2.log 2>&1
 </pre>

 * <p>As you can see there are three parameters passed to the script.  Look at the code in the process() method to see
 * how the command line for the exec is dynamically constructed.
 * <p>Do the following to set this example up:
 * <ol>
 * <li>Configure this class as an in-line processor.  This class unzips a payload so you'll want to configure this for
 * inbound documents.  You can configure this at the Delivery Exchange or in the Message Handler
 * <ul>
 * <li>The class name is <code>examples.inlineprocess.Unzippit</code>
 * <li>As a parameter, provide a password to use when unzipping the payload
 * </ul>
 * <li>Create a "unzip.bat" in CI's bin directory.  Choose one of the scripts provided above.
 * <li>Submit an inbound .zip file through CI.  You can either consume a message that has been packaged using the
 * in-line processing <code>examples.inlineprocess.Zippit</code> or just use a ZIPing utility to manually create a
 * file for testing.  Don't forget to secure it with a password.  It's easy to tell that this worked by:
 * <ul>
 * <li>Looking at the debug statements in the log4j log file
 * <li>You can use the "view content" feature in the UI to look at the payload.  It's easiest to see the result if you
 * use a business protocol such as Secure File that doesn't package the payload into a different form.
 * </ul>
 * </ol>
 *
 */
public class Unzippit implements com.cyclonecommerce.api.inlineprocessing.MessageProcessor {

	/** this is how you get the log4J logger instance for this class */
	private static Logger logger = LogManager.getLogger(examples.inlineprocess.Unzippit.class);

	/** this is the parameter passed in from the UI */
	private String param = null;

	public static final String BATCH_FILENAME = "unzip.bat";

	/**
	 * Default constructor - the only constructor used by Interchange
	 */
	public Unzippit() {
		// nothing to do
	}

	/**
	 * Accepts the parameter configured in the UI and stores it locally for later use
	 * @param param the parameter configured in the UI for the in-line processor
	 s	 */
	public void setParameters(String param) {
		// store the parameter if it's not null or empty
		if (param != null && param.length() != 0)
			this.param = param;
	}

	/**
	 * Makes a system exec call to an unzip batch file passing the required parameters
	 *
	 * @param message the message being processed
	 */
	public void process(Message message) {

		// make sure there is a password supplied via the paramter
		if (param == null)  {
			message.reject("Password parameter to the Unzippit in-line process cannot be null");
			return;
		}

		try {
			// ensure the original filename ended with .zip
			String originalFilename = message.getMetadata(MetadataDictionary.CONSUMPTION_FILENAME);
			if (!originalFilename.endsWith(".zip")) {
				message.reject("the original filename \"" + originalFilename + "\" does not have the required .zip extension");
			}

			// parse paylaod filename
			File payload = message.getData().toFile();
			String payloadPath = payload.getParent();
			String payloadFilename = payload.getName();

			// create the filename of the file unzipped from the archive
			String unzippedFilename = originalFilename.substring(0, originalFilename.length() - 4);
			File resultFile = new File(payloadPath, unzippedFilename);

			// construct the command line
			String cmdLine = new StringBuffer(BATCH_FILENAME).append(" ").append(payloadPath).append(" ").append(payloadFilename).append(" ").append(param).toString();
			logger.debug("calling system exec with cmd line \"" + cmdLine + "\"");

			// the call to the batch script is synchronized to prevent any collisions that may happen
			int result = Integer.MAX_VALUE;
			long startTime = 0;
			synchronized (logger) {
				startTime = System.currentTimeMillis();
				Process proc = Runtime.getRuntime().exec(cmdLine);
				result = proc.waitFor();
			}

			long duration = System.currentTimeMillis() - startTime;
			logger.debug("system exe returned resultFile code: " + result + " in " + duration + " millis");

			// look for the result file and add it as the new content
			if (resultFile.exists() && resultFile.isFile()) {
				logger.debug("the payload has been unzipped to " + resultFile.getPath());
				VirtualData d = new VirtualData(resultFile, true);
				message.setData(d);
			} else {
				message.reject("cannot find resultant file from unzipping " + originalFilename);
				return;
			}


		} catch (Exception e) {
			// always catch your Exceptions
			message.reject("Failure calling system exec:" + e.getMessage());
			return;
		}
	}

}
