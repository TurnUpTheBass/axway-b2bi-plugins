// Copyright (c) 1996-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.inlineprocess;

import com.cyclonecommerce.collaboration.MetadataDictionary;
import com.cyclonecommerce.api.inlineprocessing.Message;
import com.cyclonecommerce.util.VirtualData;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

/**
 * In-line processor that execs an external batch script to ZIP the current payload and add the zipped file as the
 * new contant.  The new file becomes the content produced to the destination.  This in-line processor implementation
 * implements the MessageProcessor interface.
 * <p>There are a couple assumptions:
 * <ul>
 * <li>the archive filename is the name of the origional filename (as consumed by CI) plus a .zip extension
 * <li>there is a batch script called zip.bat placed in CI's bin directory
 * </ul>
 *
 * <p>This class requires a batch script in CI's bin directory called "zip.bat" that looks something like the
 * following.  There are slight differences between using pkzip and winzip.
 *
 * <p>Example of using PKZIP
 * <pre>
 echo off
 REM
 REM  This script uses PKZIP to zip the specified file using the password provided
 REM
 REM  param1 = directory where payload file is located
 REM  param2 = filename of the newly created archive
 REM  param3 = password to unlock the archive
 REM  param4 = filename of the payload file
 REM
 cd %1
 c:\\pkzip32\\pkzip25 -add -pass=%3 %2 %4 >> c:\\cyclone\\b920\\logs\\zip_%2.log 2>&1
 </pre>
 * <p>Example of using WINZIP
 * <pre>
 echo off
 REM
 REM  This script uses WINZIP to zip the specified file using the password provided
 REM
 REM  param1 = directory where payload file is located
 REM  param2 = filename of the newly created archive
 REM  param3 = password to unlock the archive
 REM  param4 = filename of the payload file
 REM
 cd %1
 c:\\progra~1\\winzip\\wzzip %2 -s%3 %4 >> c:\\cyclone\\b920\\logs\\zip_%2.log 2>&1
 </pre>

 * <p>There are four parameters passed to the script.  Look at the code in the process() method to see
 * how the command line for the exec is dynamically constructed.
 *
 * <p>Do the following to set this example up:
 * <ol>
 * <li>Configure this class as an in-line processor.  This class zips a payload so you'll want to configure this for
 * outbound documents.  You can configure this at the Message Handler or on the Exchange Point for a specific trading partner.
 * There is a slight difference in which you choose.  Using this at the Message Handler will zip the clear-text payload.
 * Using this at the trading partner's exchange point will zip the "packaged" message.  There are uses for either case.
 * <ul>
 * <li>The class name is <code>examples.inlineprocess.Zippit</code>
 * <li>As a parameter, provide a password to use when zipping the payload
 * </ul>
 * <li>Create a "zip.bat" in CI's bin directory.  Choose one of the scripts provided above.
 * <li>Submit an outbound document through CI.  It's easy to tell that this worked by:
 * <ul>
 * <li>Looking at the debug statements in the log4j log file
 * <li>You can use the "view content" feature in the UI to look at the payload.  It's easiest to see the result if you
 * use a business protocol such as Secure File that doesn't package the payload into a different form.
 * </ul>
 * </ol>
 *
 */
public class Zippit implements com.cyclonecommerce.api.inlineprocessing.MessageProcessor {

	/** this is how you get the log4J logger instance for this class */
	private static Logger logger = LogManager.getLogger(examples.inlineprocess.Zippit.class);

	/** this is the parameter passed in from the UI */
	private String param = null;

	public static final String BATCH_FILENAME = "zip.bat";

	/**
	 * Default constructor - the only constructor used by Interchange
	 */
	public Zippit() {
		// nothing to do
	}

	/**
	 * Accepts the parameter configured in the UI and stores it locally for later use
	 * @param param the parameter configured in the UI for the in-line processor
	 s	 */
	public void setParameters(String param) {
		// store the parameter if it's not null or empty
		if (param != null && param.length() != 0)
			this.param = param;
	}

	/**
	 * Makes a system exec call to an zip batch file passing the required parameters
	 *
	 * @param message the message being processed
	 */
	public void process(Message message) {

		// make sure there is a password supplied via the paramter
		if (param == null)  {
			message.reject("Password parameter to the Zippit in-line process cannot be null");
			return;
		}

		try {
			// parse paylaod filename
			File payload = message.getData().toFile();
			String payloadPath = payload.getParent();
			String payloadFilename = payload.getName();
			File resultFile = new File(payloadPath, payloadFilename + ".zip");

			// construct cmd line
			String cmdLine = new StringBuffer(BATCH_FILENAME).append(" ").append(payloadPath).append(" ").append(resultFile.getName()).append(" ").append(param).append(" ").append(payloadFilename).toString();
			logger.debug("calling system exec with cmd line \"" + cmdLine + "\"");

			// the call to the batch script is synchronized to prevent any collisions that may happen
			int result = Integer.MAX_VALUE;
			long startTime = 0;
			synchronized (logger) {
				startTime = System.currentTimeMillis();
				Process proc = Runtime.getRuntime().exec(cmdLine);
				result = proc.waitFor();
			}

			long duration = System.currentTimeMillis() - startTime;
			logger.debug("system exe returned resultFile code: " + result + " in " + duration + " millis");

			// add the zipped file to the message model as the current content
			if (resultFile.exists() && resultFile.isFile()) {
				logger.debug("the payload has been zipped to " + resultFile.getPath());
				VirtualData d = new VirtualData(resultFile, true);
				message.setData(d);
				message.setMetadata(MetadataDictionary.PRODUCTION_FILENAME, resultFile.getName());
			} else {
				message.reject("cannot find resultant file from zipping " + payload.getPath());
				return;
			}

		} catch (Exception e) {
			// always catch your Exceptions
			message.reject("Failure calling system exec:" + e.getMessage());
			return;
		}
	}

}
