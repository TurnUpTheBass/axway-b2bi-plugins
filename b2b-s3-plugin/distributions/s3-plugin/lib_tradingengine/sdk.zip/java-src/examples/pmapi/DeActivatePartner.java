// Copyright (c) $smartDate Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.pmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.CommunityManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Community;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Subscription;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.SubscriptionList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.SubscriptionOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ProfileManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.QueryResult;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.SearchBy;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;
import org.dom4j.Element;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

//
// This is sample client code for deactivating a Partner profile from a host community. To deActivate, create an
// instance of this class with the appropriate arguments and then call the public method 'deActivatePartnerFromCommunity'.
//
public class DeActivatePartner
{
    private static final String AUTHENTICATION_MODE = "OrgAdminPassword";

	private URL serverUrl;
	private String userId;
    private String password;
    private String partnerId = null;
    private String partnerName = null;
    private String communityName = null;
    private Community community = null;

    //
    // DeActivate partner from Interchange community
    // @param serverUrl The Interchange server URL
    // @param userId The Interchange userId
    // @param password The Interchange password
    // @param partnerName The partner's name
    // @param communityName The Interchange communityName
    // @param partnerXmlFile The file object representing the partner's XML
    //
    public DeActivatePartner(String serverUrl, String userId, String password,
			String partnerName, String communityName)
    {
        if (isNullEmptyOrBlank(serverUrl))
            throw new IllegalArgumentException(("Illegal null or empty value for serverUrl argument"));
        else
		{
            try
			{
				this.serverUrl = new URL(serverUrl);
			}
			catch (MalformedURLException e)
			{
				throw new IllegalArgumentException("Invalid server URL.", e);
			}
		}

		if (isNullEmptyOrBlank(userId))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.userId = userId;

		if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;

        if (isNullEmptyOrBlank(partnerName))
            throw new IllegalArgumentException(("Illegal null or empty value for partnerName argument"));
        else
            this.partnerName = partnerName;

        if (isNullEmptyOrBlank(communityName))
            throw new IllegalArgumentException(("Illegal null or empty value for communityName argument"));
        else
            this.communityName = communityName;
    }

    public void deActivatePartnerFromCommunity()
    {
        System.out.println("DeActivating Partner : " + partnerName);
        try
        {
            queryForPartner();
            queryForCommunity();
            deActivatePartner();
        }
        catch (Exception e)
        {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void queryForPartner() throws Exception
    {
		System.out.println("Query for partner: " + partnerName);

		ClientSession clientSession = createSession();
		try
		{
			OrganizationQuery organizationQuery = new OrganizationQuery();
			SearchBy searchBy = new SearchBy();
			searchBy.setOrganizationName(partnerName);
			organizationQuery.setSearchBy(searchBy);

			printElement("Query for partner request", organizationQuery.toElement());

			ProfileManagementApiStub pmApi = new ProfileManagementApiStub(clientSession);
			QueryResult queryResult = pmApi.findOrganizationsEx(organizationQuery);

			printElement("Query for partner response", queryResult.toElement());

			String[] orgIds = queryResult.getOrganizationIds();
			partnerId = orgIds.length == 1 ? orgIds[0] : null;
			if (partnerId == null)
				throw new Exception("Partner " + partnerName + " not found in host");
			else
				System.out.println("Partner " + partnerName + " found in host with partner ID of " + partnerId);
		}
		finally
		{
			clientSession.close();
		}
	}

    private ClientSession createSession() throws AuthenticationException
    {
        Map<String,String> authenticationData = new HashMap<String,String>();
        authenticationData.put("organization", "Service Provider");
        authenticationData.put("administrator", userId);
        authenticationData.put("password", password);
        return ClientSession.createSession(AUTHENTICATION_MODE, authenticationData, serverUrl);
    }

    private void queryForCommunity()  throws Exception
    {
        System.out.println("Query for Community " + communityName);

		ClientSession clientSession = createSession();
		try
		{
			CommunityQuery communityQuery = new CommunityQuery();
			communityQuery.setCommunityName(communityName);

			printElement("Query for community request", communityQuery.toElement());

			CommunityManagementApiStub cmApi = new CommunityManagementApiStub(clientSession);
			CommunityList communityList = cmApi.findCommunitiesEx(communityQuery);

			printElement("Query for community response", communityList.toElement());

			Community[] communities = communityList.getCommunities();
			community = communities.length == 1 ? communities[0] : null;
			if (community == null)
				throw new Exception("Community " + communityName + " not found in host");
			else
				System.out.println("Community " + communityName + " found in host with community ID of " + community.getCommunityId());
		}
		finally
		{
			clientSession.close();
		}
    }

    private void deActivatePartner() throws Exception
    {
        ClientSession clientSession = createSession();
        try
        {
            SubscriptionList subscriptionList = new SubscriptionList();

            Subscription[] subscriptions = new Subscription[] {new Subscription()};
			subscriptions[0].setCommunityId(community.getCommunityId());
            subscriptions[0].setCommunityName(community.getCommunityName());
            subscriptions[0].setOrganizationId(partnerId);
            subscriptions[0].setState("REVOKED");
            subscriptionList.setSubscriptions(subscriptions);

            printElement("Set subscription request", subscriptionList.toElement());

            CommunityManagementApiStub cmApiStub = new CommunityManagementApiStub(clientSession);
            SubscriptionOutputList subscriptionOutputList = cmApiStub.setSubscriptionsEx(subscriptionList);

            printElement("Set subscription response", subscriptionOutputList.toElement());

            Subscription subscription = subscriptionOutputList.getSubscriptions()[0];
			Disposition disposition = subscription.getDisposition();
			if (disposition.getId().startsWith("00"))
				System.out.println("Subscription successful.");
			else
				throw new Exception("Subscription failed with reason: (" + disposition.getId() + ") " + disposition.getTitle());
        }
        finally
		{
			clientSession.close();
		}
    }

    private static boolean isNullEmptyOrBlank(String string)
	{
		return string == null || string.trim().length() == 0;
	}

	private static void printElement(String title, Element element)
	{
		System.out.println(title);
		System.out.println("--------------------------------------------------");
		try
		{
			ElementUtil.write(element, System.out);
		}
		catch (IOException e)
		{
			// won't happen
		}
		System.out.println();
		System.out.println("--------------------------------------------------");
		System.out.println();
	}

	public static void main(String[] args)
	{
		// Change the parameter values below to suit your environment.

		String serverUrl = "http://localhost:6080/cyclone/services/ProfileManagementService";
		String userId = "admin";
		String password = "Secret1";
		String partnerName = "A_Partner1";  // The partner name to deactivate.
		String communityName = "A_Community";  // The name of the community to unSubscribe from.

		DeActivatePartner deActivatePartner = new DeActivatePartner(serverUrl, userId, password,
				partnerName, communityName);
		deActivatePartner.deActivatePartnerFromCommunity();
	}
}
