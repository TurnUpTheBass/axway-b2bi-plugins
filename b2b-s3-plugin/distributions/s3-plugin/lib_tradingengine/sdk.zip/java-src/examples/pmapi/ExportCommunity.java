package examples.pmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.CommunityManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Community;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ProfileManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.w3c.dom.NodeList;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class ExportCommunity
{
    private String communityName = null;
    private File exportDirectory = null;
    private File getCommunityXmlFile = null;
    private URL serverUrl;
	private String userId;
    private String password;
    private String communityId = null;
    private static final String AUTHENTICATION_MODE = "OrgAdminPassword";
    private static final String ICP = "InterchangeCommunityProfile";
    //
    //  Export partner profile from Interchange into a defined directory
    //  @param serverUrl The Interchange server URL
    //  @param userId The Interchange userId
    //  @param password The Interchange password
    //  @param communityName The partner's name
    //  @param exportDirectory The file object representing the users target directory
    //
    public ExportCommunity(String serverUrl, String userId, String password,
			String communityName, File getCommunityXmlFile, File exportDirectory)
    {
        if (isNullEmptyOrBlank(serverUrl))
            throw new IllegalArgumentException(("Illegal null or empty value for serverUrl argument"));
        else
        {
            try
            {
                this.serverUrl = new URL(serverUrl);
            }
            catch (MalformedURLException e)
            {
                throw new IllegalArgumentException("Invalid server URL.", e);
            }
        }
        if (isNullEmptyOrBlank(userId))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.userId = userId;

        if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;

        if (isNullEmptyOrBlank(communityName))
            throw new IllegalArgumentException(("Illegal null or empty value for communityName argument"));
        else
            this.communityName = communityName;

        if (getCommunityXmlFile == null)
             throw new IllegalArgumentException(("Illegal null value for getCommunityXmlFile argument"));
        else if (!getCommunityXmlFile.exists())
             throw new IllegalArgumentException("GetCommunityXmlFile does not exist: " + getCommunityXmlFile.toString());
        else if (!getCommunityXmlFile.isFile())
             throw new IllegalArgumentException(("GetCommunityXmlFile argument is not a file"));
        else
             this.getCommunityXmlFile = getCommunityXmlFile;

        if (exportDirectory == null)
            throw new IllegalArgumentException(("Illegal null or empty value for exportDirectory argument"));
        else if (!exportDirectory.exists())
             throw new IllegalArgumentException("The ExportDirectory does not exist: " + exportDirectory.toString());
        else if (!exportDirectory.isDirectory())
            throw new IllegalArgumentException(("The ExportDirectory is not a directory"));
        else
            this.exportDirectory = exportDirectory;
    }

    public void exportCommunityProfile()
    {
        System.out.println("Exporting Community: " + communityName);
        try
        {
            Element rootElement = loadCommunityProfileRequest();
            queryForCommunity();
            File profileDir = new File(exportDirectory, communityName);
            if (!profileDir.exists())
            {
                if (!profileDir.mkdirs())
                {
                    throw new Exception("Error when creating directory " + exportDirectory.getAbsolutePath());
                }
            }
            persistProfile(rootElement, profileDir, communityId);
        }
        catch (Exception e)
        {
            System.out.println("Error: " + e.getMessage());
        }
    }

   private void queryForCommunity()  throws Exception
   {
        System.out.println("Query for Community " + communityName);

        ClientSession clientSession = createSession();
        try
        {
            CommunityQuery communityQuery = new CommunityQuery();
            communityQuery.setCommunityName(communityName);

            printElement("Query for community request", communityQuery.toElement());

            CommunityManagementApiStub cmApi = new CommunityManagementApiStub(clientSession);
            CommunityList communityList = cmApi.findCommunitiesEx(communityQuery);

            printElement("Query for community response", communityList.toElement());

            Community[] communityIds = communityList.getCommunities();
            communityId = communityIds.length == 1 ? communityIds[0].getCommunityId() : null;
            if (communityId == null)
                System.out.println("Community " + communityName + " not found in host");
            else
                System.out.println("Community " + communityName + " found in host with community ID of " + communityId);
        }
        finally
        {
            clientSession.close();
        }
    }

    private void persistProfile(Element rootElement, File outputDir, String orgId) throws Exception
	{
        ClientSession clientSession = createSession();
		try
		{
			ProfileManagementApiStub pmApi = new ProfileManagementApiStub(clientSession);
            OrganizationDataInput orgDataInput = new OrganizationDataInput();
			orgDataInput.setOrganizationId(orgId);
			orgDataInput.setOrganizationData(ElementUtil.toDomElement(rootElement));
			OrganizationDataInputList orgDataInputList = new OrganizationDataInputList();
			orgDataInputList.setOrganizationDataInput(new OrganizationDataInput[]{orgDataInput});

            printElement("Get community data request", orgDataInputList.toElement());
            OrganizationDataOutputList ol = pmApi.getOrganizationDataEx2(orgDataInputList, "InterchangeCommunityProfile");
            if (ol != null)
			    printElement("Get community data response", ol.toElement());
            else
                throw new Exception("The getOrganizationDataEx2 response did not return OrganizationDataOutputList as expected.");
            OrganizationDataOutput[] orgOutput = ol.getOrganizationDataOutput();
            if (orgOutput.length == 0)
                throw new Exception("The getOrganizationDataEx2 response did not return OrganizationDataOutput as expected.");
            for (OrganizationDataOutput organizationDataOutput : orgOutput)
			{
				if (organizationDataOutput.getDisposition() == null)
				{
			        org.w3c.dom.Element orgProfileElem = orgOutput[0].getOrganizationData();
			        writeProfile(outputDir, orgProfileElem);
                }
                else
                {
                    Disposition disposition = organizationDataOutput.getDisposition();
                    disposition.toElement();
				    throw new Exception("Unexpected disposition received when getting community data");
                }
            }
        }
        finally
		{
			clientSession.close();
		}
	}

    private static void writeProfile(File directory, org.w3c.dom.Element orgProfileElem)
			throws Exception
	{
        NodeList nl = orgProfileElem.getElementsByTagNameNS("*", "OrganizationName");
        String orgName;
		if (nl.getLength() == 0)
			orgName = "Unknown_" + System.currentTimeMillis();
		else
			orgName = nl.item(0).getTextContent();
		String encoded = orgName.replace(' ', '_');
		encoded = URLEncoder.encode(encoded, "UTF-8");
		String fileName = encoded + ".xml";
		File file = new File(directory, fileName);

		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer t = tf.newTransformer();

		FileWriter fw = null;
		try
		{
			fw = new FileWriter(file);
			t.transform(new DOMSource(orgProfileElem), new StreamResult(fw));
		}
		finally
		{
			try
		    {
			    if (fw != null)
                    fw.close();
		    }
		    catch (IOException e)
		    {
			    throw new Exception("Error closing Writer: " + e.getMessage());
		    }
		}
        System.out.println("File " + file.getAbsolutePath() + " written");
	}

    private Element loadCommunityProfileRequest()throws Exception
	{
		FileInputStream fis = null;
		Element rootElement = null;
		try
		{
			fis = new FileInputStream(getCommunityXmlFile);
			SAXReader reader = new SAXReader();
			reader.setValidation(false);
			Document profileDocument = reader.read(fis);
            if (profileDocument.getRootElement().getName() == null || !profileDocument.getRootElement().getName().equalsIgnoreCase(ICP))
		    {
			    throw new Exception("Error: Invalid XML Document in file " + getCommunityXmlFile.getAbsolutePath() + " Expecting " + ICP);
		    }
		    rootElement = profileDocument.getRootElement();
		}
		finally
		{
			if (fis != null)
			{
				fis.close();
			}
		}
		return rootElement;
	}

   private ClientSession createSession() throws AuthenticationException
	{
		Map<String,String> authenticationData = new HashMap<String,String>();
		authenticationData.put("organization", "Service Provider");
		authenticationData.put("administrator", userId);
		authenticationData.put("password", password);
		return ClientSession.createSession(AUTHENTICATION_MODE, authenticationData, serverUrl);
	}

    private static boolean isNullEmptyOrBlank(String string)
	{
		return string == null || string.trim().length() == 0;
	}

    private static void printElement(String title, Element element)
	{
		System.out.println(title);
		System.out.println("--------------------------------------------------");
		try
		{
			ElementUtil.write(element, System.out);
		}
		catch (IOException e)
		{
			// won't happen
		}
		System.out.println();
		System.out.println("--------------------------------------------------");
		System.out.println();
	}

    public static void main(String[] args)
    {
        // Change the parameter values below to suit your environment.

        String serverUrl = "http://localhost:6080/cyclone/services/ProfileManagementService";
        String userId = "admin";
        String password = "Secret1";
        String communityName = "community";
        File exportDirectory = new File("java-src/examples/pmapi/sampleXmlFiles");
        File getCommunityXmlFile = new File("java-src/examples/pmapi/sampleXmlFiles/interchange/getCommunity.xml");

        ExportCommunity exportCommunity = new ExportCommunity(serverUrl, userId, password,
                communityName, getCommunityXmlFile, exportDirectory);
        exportCommunity.exportCommunityProfile();
    }
}
