// Copyright (c) $smartDate Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.pmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ProfileManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.SearchBy;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.QueryResult;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationIdList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;

import org.w3c.dom.NodeList;
import org.dom4j.Element;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.net.MalformedURLException;

//
// This is sample code for exporting an Interchange Partner from the community into a user defined directory.  To
// export, create an instance of this class and then call the public method 'exportPartnerProfile' with the
// appropriate arguments 'partnerName' and 'exportDirectory'.
//
public class ExportPartner
{
    private String partnerName = null;
    private File exportDirectory = null;
    private URL serverUrl;
	private String userId;
    private String password;
    private String partnerId = null;
    private static final String AUTHENTICATION_MODE = "OrgAdminPassword";
    //
    //  Export partner profile from Interchange into a defined directory
    //  @param serverUrl The Interchange server URL
    //  @param userId The Interchange userId
    //  @param password The Interchange password
    //  @param partnerName The partner's name
    //  @param exportDirectory The file object representing the users target directory
    //
    public ExportPartner(String serverUrl, String userId, String password,
			String partnerName, File exportDirectory)
    {
        if (isNullEmptyOrBlank(serverUrl))
            throw new IllegalArgumentException(("Illegal null or empty value for serverUrl argument"));
        else
        {
            try
            {
                this.serverUrl = new URL(serverUrl);
            }
            catch (MalformedURLException e)
            {
                throw new IllegalArgumentException("Invalid server URL.", e);
            }
        }
        if (isNullEmptyOrBlank(userId))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.userId = userId;

        if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;

        if (isNullEmptyOrBlank(partnerName))
            throw new IllegalArgumentException(("Illegal null or empty value for partnerName argument"));
        else
            this.partnerName = partnerName;

        if (exportDirectory == null)
            throw new IllegalArgumentException(("Illegal null or empty value for exportDirectory argument"));
        else if (!exportDirectory.exists())
            throw new IllegalArgumentException(("The ExportDirectory does not exist"));
        else if (!exportDirectory.isDirectory())
            throw new IllegalArgumentException(("The ExportDirectory is not a directory"));
        else
            this.exportDirectory = exportDirectory;
    }

    public void exportPartnerProfile()
    {
        System.out.println("Exporting Partner: " + partnerName);
        try
        {
            queryForPartner();
            File profileDir = new File(exportDirectory, partnerName);
            if (!profileDir.exists())
            {
                if (!profileDir.mkdirs())
                {
                    throw new Exception("Error when creating directory " + exportDirectory.getAbsolutePath());
                }
            }
            persistProfiles(profileDir, partnerId);
        }
        catch (Exception e)
        {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void queryForPartner() throws Exception
    {
		System.out.println("Query for partner: " + partnerName);

		ClientSession clientSession = createSession();
		try
		{
			OrganizationQuery organizationQuery = new OrganizationQuery();
			SearchBy searchBy = new SearchBy();
			searchBy.setOrganizationName(partnerName);
			organizationQuery.setSearchBy(searchBy);

			printElement("Query for partner request", organizationQuery.toElement());

			ProfileManagementApiStub pmApi = new ProfileManagementApiStub(clientSession);
			QueryResult queryResult = pmApi.findOrganizationsEx(organizationQuery);

			printElement("Query for partner response", queryResult.toElement());

			String[] orgIds = queryResult.getOrganizationIds();
			partnerId = orgIds.length == 1 ? orgIds[0] : null;
			if (partnerId == null)
				throw new Exception("Partner " + partnerName + " not found in host");
			else
				System.out.println("Partner " + partnerName + " found in host with partner ID of " + partnerId);
		}
		finally
		{
			clientSession.close();
		}
	}

    private void persistProfiles(File outputDir, String orgId) throws Exception
	{
		OrganizationIdList orgIdList = new OrganizationIdList();
		String[] ids = new String[1];
        ids[0] = orgId;
		orgIdList.setOrganizationIds(ids);
        ClientSession clientSession = createSession();
		try
		{
            printElement("Get partner data request", orgIdList.toElement());

			ProfileManagementApiStub pmApi = new ProfileManagementApiStub(clientSession);
			OrganizationDataOutputList ol = pmApi.getOrganizationDataEx(orgIdList, "CycloneOrganizationProfile_2001");
            if (ol != null)
			    printElement("Get partner data response", ol.toElement());
            else
                throw new Exception("The getOrganizationDataEx response did not return OrganizationDataOutputList as expected.");
            OrganizationDataOutput[] orgOutput = ol.getOrganizationDataOutput();
            if (orgOutput.length == 0)
                throw new Exception("The getOrganizationDataOutput response did not return OrganizationDataOutput as expected.");
            for (OrganizationDataOutput organizationDataOutput : orgOutput)
			{
				if (organizationDataOutput.getDisposition() == null)
				{
			        org.w3c.dom.Element orgProfileElem = orgOutput[0].getOrganizationData();
			        writeProfile(outputDir, orgProfileElem);
                }
                else
                {
                    Disposition disposition = organizationDataOutput.getDisposition();
                    disposition.toElement();
				    throw new Exception("Unexpected disposition received when getting partner data");
                }
            }
        }
        finally
		{
			clientSession.close();
		}
	}

    private static void writeProfile(File directory, org.w3c.dom.Element orgProfileElem)
			throws Exception
	{
        NodeList nl = orgProfileElem.getElementsByTagNameNS("http://www.cyclonecommerce.com/Schemas/2001/08/cop",
                "OrganizationName");
		String orgName;
		if (nl.getLength() == 0)
			orgName = "Unknown_" + System.currentTimeMillis();
		else
			orgName = nl.item(0).getTextContent();
		String encoded = orgName.replace(' ', '_');
		encoded = URLEncoder.encode(encoded, "UTF-8");
		String fileName = encoded + ".xml";
		File file = new File(directory, fileName);

		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer t = tf.newTransformer();

		FileWriter fw = null;
		try
		{
			fw = new FileWriter(file);
			t.transform(new DOMSource(orgProfileElem), new StreamResult(fw));
		}
		finally
		{
			try
		    {
			    if (fw != null)
                    fw.close();
		    }
		    catch (IOException e)
		    {
			    throw new Exception("Error closing Writer: " + e.getMessage());
		    }
		}
        System.out.println("File " + file.getAbsolutePath() + " written");
	}

   private ClientSession createSession() throws AuthenticationException
	{
		Map<String,String> authenticationData = new HashMap<String,String>();
		authenticationData.put("organization", "Service Provider");
		authenticationData.put("administrator", userId);
		authenticationData.put("password", password);
		return ClientSession.createSession(AUTHENTICATION_MODE, authenticationData, serverUrl);
	}

    private static boolean isNullEmptyOrBlank(String string)
	{
		return string == null || string.trim().length() == 0;
	}

    private static void printElement(String title, Element element)
	{
		System.out.println(title);
		System.out.println("--------------------------------------------------");
		try
		{
			ElementUtil.write(element, System.out);
		}
		catch (IOException e)
		{
			// won't happen
		}
		System.out.println();
		System.out.println("--------------------------------------------------");
		System.out.println();
	}

	public static void main(String[] args)
	{
		// Change the parameter values below to suit your environment.

		String serverUrl = "http://localhost:6080/cyclone/services/ProfileManagementService";
		String userId = "admin";
		String password = "Secret1";
		String partnerName = "A_Partner1";  // The partner name to import or update.
		File exportDirectory = new File("C:\\5.10.0.0.x\\myCommon"); // The location of the export directory

		ExportPartner exportPartner = new ExportPartner(serverUrl, userId, password,
				partnerName, exportDirectory);
		exportPartner.exportPartnerProfile();
	}
}
