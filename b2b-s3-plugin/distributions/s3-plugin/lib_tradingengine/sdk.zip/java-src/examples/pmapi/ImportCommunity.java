// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.pmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.CommunityManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Community;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ProfileManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class ImportCommunity
{

    private static final String AUTHENTICATION_MODE = "OrgAdminPassword";
    private URL serverUrl;
    private String userId;
    private String password;
    private String communityName = null;
    private String communityId = null;
    private File communityXmlFile = null;
    private Document communityDocument;
    //
    // Import community profile into Interchange
    // @param serverUrl The Interchange server URL
    // @param userId The Interchange userId
    // @param password The Interchange password
    // @param community The community's name
    // @param communityName The Interchange communityName
    // @param communityXmlFile The file object representing the community's XML
    //
    public ImportCommunity(String serverUrl, String userId, String password, String communityName, File communityXmlFile)
    {
        if (isNullEmptyOrBlank(serverUrl))
            throw new IllegalArgumentException(("Illegal null or empty value for serverUrl argument"));
        else
        {
            try
            {
                this.serverUrl = new URL(serverUrl);
            }
            catch (MalformedURLException e)
            {
                throw new IllegalArgumentException("Invalid server URL.", e);
            }
        }
        if (isNullEmptyOrBlank(userId))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.userId = userId;
        if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;

        if (isNullEmptyOrBlank(communityName))
            throw new IllegalArgumentException(("Illegal null or empty value for communityName argument"));
        else
             this.communityName = communityName;

        if (communityXmlFile == null)
             throw new IllegalArgumentException(("Illegal null value for communityXmlFile argument"));
        else if (!communityXmlFile.exists())
             throw new IllegalArgumentException("CommunityXmlFile does not exist: " + communityXmlFile.toString());
        else if (!communityXmlFile.isFile())
             throw new IllegalArgumentException(("CommunityXmlFile argument is not a file"));
        else
             this.communityXmlFile = communityXmlFile;
    }

    public void importCommunityProfile()
    {
        System.out.println("Importing Community : " + communityName);
        try
        {
            communityDocument = processFile(communityXmlFile);
            queryForCommunity();
            pushProfile();
         }
         catch (Exception e)
         {
             System.err.println("Error: " + e.getMessage());
             e.printStackTrace();
         }
    }

    private Document processFile(File xmlFile) throws DocumentException
    {
        org.dom4j.io.SAXReader reader = new SAXReader();
        reader.setValidation(false);
        try
        {
            return reader.read(xmlFile);
        }
        catch (DocumentException e)
        {
             System.out.println("Error reading file " + xmlFile);
             throw e;
        }
    }

    private ClientSession createSession() throws AuthenticationException
    {
        Map<String,String> authenticationData = new HashMap<String,String>();
        authenticationData.put("organization", "Service Provider");
        authenticationData.put("administrator", userId);
        authenticationData.put("password", password);
        return ClientSession.createSession(AUTHENTICATION_MODE, authenticationData, serverUrl);
    }

    private void pushProfile() throws Exception
    {
        System.out.println("Importing " + communityName);

        ClientSession clientSession = createSession();
        try
        {
            Element communityElement = communityDocument.getRootElement();

            OrganizationDataInputList organizationDataInputList = new OrganizationDataInputList();
            OrganizationDataInput[] organizationDataInputs = new OrganizationDataInput[] {new OrganizationDataInput()};
            organizationDataInputs[0].setOrganizationId(communityId);
            organizationDataInputs[0].setOrganizationData(ElementUtil.toDomElement(communityElement));
            organizationDataInputList.setOrganizationDataInput(organizationDataInputs);

            printElement("Import community request", organizationDataInputList.toElement());

            ProfileManagementApiStub pmApi = new ProfileManagementApiStub(clientSession);
            OrganizationDataOutputList organizationDataOutputList = pmApi.setOrganizationDataEx(organizationDataInputList);
            OrganizationDataOutput organizationDataOutput = organizationDataOutputList.getOrganizationDataOutput()[0];

            printElement("Import community response", organizationDataOutput.toElement());

            Disposition disposition = organizationDataOutput.getDisposition();
            if (disposition.getId().startsWith("00"))
                System.out.println("Import successful.");
            else
                throw new Exception("Import failed with reason: (" + disposition.getId() + ") " + disposition.getTitle());
        }
        finally
        {
            clientSession.close();
        }
   }

   private void queryForCommunity()  throws Exception
   {
        System.out.println("Query for Community " + communityName);

        ClientSession clientSession = createSession();
        try
        {
            CommunityQuery communityQuery = new CommunityQuery();
            communityQuery.setCommunityName(communityName);

            printElement("Query for community request", communityQuery.toElement());

            CommunityManagementApiStub cmApi = new CommunityManagementApiStub(clientSession);
            CommunityList communityList = cmApi.findCommunitiesEx(communityQuery);

            printElement("Query for community response", communityList.toElement());

            Community[] communityIds = communityList.getCommunities();
            communityId = communityIds.length == 1 ? communityIds[0].getCommunityId() : null;
            if (communityId == null)
                System.out.println("Community " + communityName + " not found in host");
            else
                System.out.println("Community " + communityName + " found in host with community ID of " + communityId);
        }
        finally
        {
            clientSession.close();
        }
    }

        private static boolean isNullEmptyOrBlank(String string)
        {
            return string == null || string.trim().length() == 0;
        }

        private static void printElement(String title, Element element)
        {
            System.out.println(title);
            System.out.println("--------------------------------------------------");
            try
            {
                ElementUtil.write(element, System.out);
            }
            catch (IOException e)
            {
                // won't happen
            }
            System.out.println();
            System.out.println("--------------------------------------------------");
            System.out.println();
        }

    public static void main(String[] args)
    {
        // Change the parameter values below to suit your environment.
        String serverUrl = "http://localhost:6080/cyclone/services/ProfileManagementService";
        String userId = "admin";
        String password = "Secret1";
        String communityName = "community";
        File communityXmlFile = new File("java-src/examples/pmapi/sampleXmlFiles/interchange/setCommunity.xml");

        ImportCommunity importCommunity = new ImportCommunity(serverUrl, userId, password, communityName, communityXmlFile);
        importCommunity.importCommunityProfile();
    }
}