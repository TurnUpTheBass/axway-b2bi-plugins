// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.pmapi;

import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.CommunityManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Community;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.CommunityQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.Subscription;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.SubscriptionList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.cmapi.beans.SubscriptionOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ProfileManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationQuery;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.QueryResult;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.SearchBy;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

//
// This is sample client code for importing a Partner profile to the host and then joining that Partner to a community.
// To import, create an instance of this class with the appropriate agruments and then call the public method
// 'importPartnerProfile'.
//
public class ImportPartnerAndActivate
{
	private static final String AUTHENTICATION_MODE = "OrgAdminPassword";

	private URL serverUrl;
	private String userId;
    private String password;
    private String partnerId = null;
    private String partnerName = null;
    private String communityName = null;
    private String communityId = null;
    private File partnerXmlFile = null;
    private Document partnerDocument = null;

    //
    // Import partner profile into Interchange
    // @param serverUrl The Interchange server URL
    // @param userId The Interchange userId
    // @param password The Interchange password
    // @param partnerName The partner's name
    // @param communityName The Interchange communityName
    // @param partnerXmlFile The file object representing the partner's XML
    //
    public ImportPartnerAndActivate(String serverUrl, String userId, String password,
			String partnerName, String communityName, File partnerXmlFile)
    {
		if (isNullEmptyOrBlank(serverUrl))
            throw new IllegalArgumentException(("Illegal null or empty value for serverUrl argument"));
        else
		{
            try
			{
				this.serverUrl = new URL(serverUrl);
			}
			catch (MalformedURLException e)
			{
				throw new IllegalArgumentException("Invalid server URL.", e);
			}
		}

		if (isNullEmptyOrBlank(userId))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.userId = userId;

		if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;

        if (isNullEmptyOrBlank(partnerName))
            throw new IllegalArgumentException(("Illegal null or empty value for partnerName argument"));
        else
            this.partnerName = partnerName;

        if (isNullEmptyOrBlank(communityName))
            throw new IllegalArgumentException(("Illegal null or empty value for communityName argument"));
        else
            this.communityName = communityName;

        if (partnerXmlFile == null)
            throw new IllegalArgumentException(("Illegal null value for partnerXmlFile argument"));
        else if (!partnerXmlFile.exists())
            throw new IllegalArgumentException(("PartnerXmlFile does not exist"));
        else if (!partnerXmlFile.isFile())
            throw new IllegalArgumentException(("PartnerXmlFile argument is not a file"));
        else
            this.partnerXmlFile = partnerXmlFile;
    }

    public void importPartnerProfile()
    {
        System.out.println("Importing Partner : " + partnerName);
        try
        {
            partnerDocument = processFile(partnerXmlFile);
            queryForPartner();
            pushProfile();
            activatePartnerToCommunity();
        }
        catch (Exception e)
        {
            System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
        }
    }

    private Document processFile(File xmlFile) throws DocumentException
    {
        org.dom4j.io.SAXReader reader = new SAXReader();
        reader.setValidation(false);
        try
        {
            return reader.read(xmlFile);
        }
        catch (DocumentException e)
        {
            System.out.println("Error reading file " + xmlFile);
            throw e;
        }
    }

	private ClientSession createSession() throws AuthenticationException
	{
		Map<String,String> authenticationData = new HashMap<String,String>();
		authenticationData.put("organization", "Service Provider");
		authenticationData.put("administrator", userId);
		authenticationData.put("password", password);
		return ClientSession.createSession(AUTHENTICATION_MODE, authenticationData, serverUrl);
	}

    private void queryForPartner() throws Exception
    {
		System.out.println("Query for partner: " + partnerName);

		ClientSession clientSession = createSession();
		try
		{
			OrganizationQuery organizationQuery = new OrganizationQuery();
			SearchBy searchBy = new SearchBy();
			searchBy.setOrganizationName(partnerName);
			organizationQuery.setSearchBy(searchBy);

			printElement("Query for partner request", organizationQuery.toElement());

			ProfileManagementApiStub pmApi = new ProfileManagementApiStub(clientSession);
			QueryResult queryResult = pmApi.findOrganizationsEx(organizationQuery);

			printElement("Query for partner response", queryResult.toElement());

			String[] orgIds = queryResult.getOrganizationIds();
			partnerId = orgIds.length == 1 ? orgIds[0] : null;
			if (partnerId == null)
				System.out.println("Partner " + partnerName + " not found in host");
			else
				System.out.println("Partner " + partnerName + " found in host with partner ID of " + partnerId);
		}
		finally
		{
			clientSession.close();
		}
	}

    private void pushProfile() throws Exception
    {
        System.out.println("Importing " + partnerName);

		ClientSession clientSession = createSession();
		try
		{
			Element partnerElement = partnerDocument.getRootElement();

			OrganizationDataInputList organizationDataInputList = new OrganizationDataInputList();
			OrganizationDataInput[] organizationDataInputs = new OrganizationDataInput[] {new OrganizationDataInput()};
			organizationDataInputs[0].setOrganizationId(partnerId);
			organizationDataInputs[0].setOrganizationData(ElementUtil.toDomElement(partnerElement));
			organizationDataInputList.setOrganizationDataInput(organizationDataInputs);

			printElement("Import partner request", organizationDataInputList.toElement());

			ProfileManagementApiStub pmApi = new ProfileManagementApiStub(clientSession);
			OrganizationDataOutputList organizationDataOutputList = pmApi.setOrganizationDataEx(organizationDataInputList);
			OrganizationDataOutput organizationDataOutput = organizationDataOutputList.getOrganizationDataOutput()[0];

			printElement("Import partner response", organizationDataOutput.toElement());

			Disposition disposition = organizationDataOutput.getDisposition();
			if (disposition.getId().startsWith("00"))
				System.out.println("Import successful.");
			else
				throw new Exception("Import failed with reason: (" + disposition.getId() + ") " + disposition.getTitle());
		}
		finally
		{
			clientSession.close();
		}
    }

    private void activatePartnerToCommunity() throws Exception
    {
        System.out.println("Activating partner " + partnerName + " to community " + communityName);

        queryForPartner();
        queryForCommunity();
        setSubscription();

        System.out.println("Partner " + partnerName + " successfully activated");
    }

    private void queryForCommunity()  throws Exception
    {
        System.out.println("Query for Community " + communityName);

		ClientSession clientSession = createSession();
		try
		{
			CommunityQuery communityQuery = new CommunityQuery();
			communityQuery.setCommunityName(communityName);

			printElement("Query for community request", communityQuery.toElement());

			CommunityManagementApiStub cmApi = new CommunityManagementApiStub(clientSession);
			CommunityList communityList = cmApi.findCommunitiesEx(communityQuery);

			printElement("Query for community response", communityList.toElement());

			Community[] communityIds = communityList.getCommunities();
			communityId = communityIds.length == 1 ? communityIds[0].getCommunityId() : null;
			if (communityId == null)
				throw new Exception("Community " + communityName + " not found in host");
			else
				System.out.println("Community " + communityName + " found in host with community ID of " + communityId);
		}
		finally
		{
			clientSession.close();
		}
    }

    private void setSubscription() throws Exception
    {
		System.out.println("Subscription for Partner " + partnerName + " in community " + communityName);

		ClientSession clientSession = createSession();
		try
		{
			SubscriptionList subscriptionList = new SubscriptionList();
			Subscription[] subscriptions = new Subscription[] {new Subscription()};
			subscriptions[0].setCommunityId(communityId);
			subscriptions[0].setOrganizationId(partnerId);
			subscriptions[0].setState("ACTIVE");
			subscriptionList.setSubscriptions(subscriptions);

			printElement("Set subscription request", subscriptionList.toElement());

			CommunityManagementApiStub cmApi = new CommunityManagementApiStub(clientSession);
			SubscriptionOutputList subscriptionOutputList = cmApi.setSubscriptionsEx(subscriptionList);

			printElement("Set subscription response", subscriptionOutputList.toElement());

			Subscription subscription = subscriptionOutputList.getSubscriptions()[0];
			Disposition disposition = subscription.getDisposition();
			if (disposition.getId().startsWith("00"))
				System.out.println("Subscription successful.");
			else
				throw new Exception("Subscription failed with reason: (" + disposition.getId() + ") " + disposition.getTitle());
		}
		finally
		{
			clientSession.close();
		}
    }

	private static boolean isNullEmptyOrBlank(String string)
	{
		return string == null || string.trim().length() == 0;
	}

	private static void printElement(String title, Element element)
	{
		System.out.println(title);
		System.out.println("--------------------------------------------------");
		try
		{
			ElementUtil.write(element, System.out);
		}
		catch (IOException e)
		{
			// won't happen
		}
		System.out.println();
		System.out.println("--------------------------------------------------");
		System.out.println();
	}

	public static void main(String[] args)
	{
		// Change the parameter values below to suit your environment.

		String serverUrl = "http://localhost:6080/cyclone/services/ProfileManagementService";
		String userId = "admin";
		String password = "Secret1";
		String partnerName = "A_Partner1";  // The partner name to import or update.
		String communityName = "A_Community";  // The name of the community to subscribe the trading partner to.
		File partnerXmlFile = new File("C:\\5.10.0.0.x\\conf\\A_Partner1.xml"); // The location of an exported partner XML file.

		ImportPartnerAndActivate importPartnerAndActivate = new ImportPartnerAndActivate(serverUrl, userId, password,
				partnerName, communityName, partnerXmlFile);
		importPartnerAndActivate.importPartnerProfile();
	}
}
