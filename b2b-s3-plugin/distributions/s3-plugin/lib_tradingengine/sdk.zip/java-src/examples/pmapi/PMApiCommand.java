// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.pmapi;

import com.axway.util.StringUtil;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.ClientSession;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.bapi.beans.Disposition;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.faults.AuthenticationException;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.ProfileManagementApiStub;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutput;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataOutputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.pmapi.beans.OrganizationDataInputList;
import com.cyclonecommerce.cyclone.services.profileManagementService.legacy.util.ElementUtil;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

//
// This is sample code for executing a XML command in Interchange and returning the results to an export directory.
// To execute the command, create an instance of this class and then call the public method 'executeCommand' with
// the appropriate arguments 'serverUrl', 'userId', 'password', 'commandName', 'exportDirectory' and 'b2biXMLFile'.
//
public class PMApiCommand
{
    private String commandName = null;
    private File exportDirectory = null;
    private File XMLFile = null;
    private URL serverUrl;
	private String userId;
    private String password;
    private Document XMLDocument = null;
    private static final String AUTHENTICATION_MODE = "OrgAdminPassword";

    public PMApiCommand(String serverUrl, String userId, String password, String commandName, File exportDirectory,
                      File XMLFile)
    {
        if (isNullEmptyOrBlank(serverUrl))
            throw new IllegalArgumentException(("Illegal null or empty value for serverUrl argument"));
        else
        {
            try
            {
                this.serverUrl = new URL(serverUrl);
            }
            catch (MalformedURLException e)
            {
                throw new IllegalArgumentException("Invalid server URL.", e);
            }
        }
        if (isNullEmptyOrBlank(userId))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.userId = userId;

        if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;

        if (isNullEmptyOrBlank(commandName))
            throw new IllegalArgumentException(("Illegal null or empty value for commandName argument"));
        else
            this.commandName = commandName;

        if (exportDirectory == null)
            throw new IllegalArgumentException(("Illegal null or empty value for exportDirectory argument"));
        else if (!exportDirectory.exists())
              throw new IllegalArgumentException("The ExportDirectory does not exist: " + exportDirectory.toString());
        else if (!exportDirectory.isDirectory())
            throw new IllegalArgumentException(("The ExportDirectory is not a directory"));
        else
            this.exportDirectory = exportDirectory;

        if (XMLFile == null)
            throw new IllegalArgumentException(("Illegal null value for partnerXmlFile argument"));
        else if (!XMLFile.exists())
              throw new IllegalArgumentException("PartnerXmlFile does not exist: " + XMLFile.toString());
        else if (!XMLFile.isFile())
            throw new IllegalArgumentException(("PartnerXmlFile argument is not a file"));
        else
            this.XMLFile = XMLFile;
    }

    public void executeCommand()
    {
        System.out.println("Executing XML command: " + commandName);
        try
        {
            XMLDocument = processFile(XMLFile);
            pushCommand();
        }
        catch (Exception e)
        {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void pushCommand() throws Exception
    {
        System.out.println("Sending " + commandName);

		ClientSession clientSession = createSession();
        OrganizationDataOutputList organizationDataOutputList = null;
		try
		{
            OrganizationDataInput orgInput = new OrganizationDataInput();
		    orgInput.setOrganizationData(ElementUtil.toDomElement(XMLDocument.getRootElement()));
    	    OrganizationDataInputList organizationDataInputList = new OrganizationDataInputList();
		    organizationDataInputList.setOrganizationDataInput(new OrganizationDataInput[]{orgInput});

            printElement("Send XML command ", organizationDataInputList.toElement());

            ProfileManagementApiStub profileManagementApiStub = new ProfileManagementApiStub(clientSession);
            try
            {
		        organizationDataOutputList = profileManagementApiStub.setOrganizationDataEx(organizationDataInputList);
            }
            catch (Exception e)
            {
                throw new Exception("Interchange server error: " + e.getMessage());
            }
            if (organizationDataOutputList != null)
			    printElement("XML command disposition response ", organizationDataOutputList.toElement());
            else
                throw new Exception("The setOrganizationDataEx response did not return organizationDataOutputList as expected.");
            OrganizationDataOutput[] organizationDataOutput = organizationDataOutputList.getOrganizationDataOutput();
	        if (organizationDataOutput == null || organizationDataOutput.length == 0)
	             throw new Exception("The getOrganizationDataOutput response did not return OrganizationDataOutput as expected.");
            Disposition disposition = organizationDataOutput[0].getDisposition();
			if (disposition == null)
                 throw new Exception("Disposition missing from host response");
            else if (!disposition.getId().startsWith("00"))
				throw new Exception("XML command failed with reason: (" + disposition.getId() + ") " + disposition.getTitle());

            Element data = organizationDataOutput[0].getOrganizationData();
            writeDataToFile(commandName, data, exportDirectory);

		}
		finally
		{
			clientSession.close();
		}
    }

    private ClientSession createSession() throws AuthenticationException
	{
		Map<String,String> authenticationData = new HashMap<String,String>();
		authenticationData.put("organization", "Service Provider");
		authenticationData.put("administrator", userId);
		authenticationData.put("password", password);
		return ClientSession.createSession(AUTHENTICATION_MODE, authenticationData, serverUrl);
	}

    private org.dom4j.Document processFile(File xmlFile) throws FileNotFoundException, DocumentException, IOException
    {
        FileReader reader = null;
        try
        {
		    reader = new FileReader(xmlFile);
		    SAXReader saxReader = new SAXReader();
		    return saxReader.read(reader);
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Error: File not found: ");
            throw e;
        }
        catch (DocumentException e)
        {
            System.out.println("Error reading xmlFile");
            throw e;
        }
        finally
        {
            try
		    {
			    if (reader != null)
                    reader.close();
		    }
		    catch (IOException e)
		    {
			    throw new IOException("Error closing reader: " + e.getMessage());
		    }
        }
    }

    private void writeDataToFile(String commandName, Element data, File exportDirectory)
    {
        if (data != null)
		{
		    try
            {
                NodeList nl = data.getElementsByTagNameNS("http://www.cyclonecommerce.com/Schemas/2001/08/cop",
                           "OrganizationName");
		        String orgName;
		        if (nl.getLength() == 0)
			        orgName = commandName + "_" + System.currentTimeMillis();
		        else
			        orgName = nl.item(0).getTextContent();
		        String encoded = orgName.replace(' ', '_');
		        encoded = URLEncoder.encode(encoded, "UTF-8");
		        String fileName = encoded + ".xml";
		        File file = new File(exportDirectory, fileName);
                System.out.println("Writing output to file..." + file.getAbsolutePath());
		        TransformerFactory tf = TransformerFactory.newInstance();
		        Transformer t = tf.newTransformer();
                FileWriter fw = null;
		        try
		        {
			        fw = new FileWriter(file);
			        t.transform(new DOMSource(data), new StreamResult(fw));
		        }
		        finally
		        {
			        try
		            {
			            if (fw != null)
                            fw.close();
		            }
		            catch (IOException e)
		            {
			            throw new IOException("Error closing fileWriter: " + e.getMessage());
		            }
		        }
			}
			catch (Exception e)
			{
			    System.out.println("Error: " + e.getMessage());
			}
		}
		else
        {
		    System.out.println("Disposition OK but no data returned");
		}
    }

    private static boolean isNullEmptyOrBlank(String string)
	{
		return string == null || string.trim().length() == 0;
	}

    private static void printElement(String title, org.dom4j.Element element)
	{
		System.out.println(title);
		System.out.println("--------------------------------------------------");
		try
		{
			ElementUtil.write(element, System.out);
		}
		catch (IOException e)
		{
			// won't happen
		}
		System.out.println();
		System.out.println("--------------------------------------------------");
		System.out.println();
	}

    public static void main(String[] args)
    {
        // Change the parameter values below to suit your environment.

        String serverUrl = "http://localhost:6080/cyclone/services/ProfileManagementService";
        String userId = "admin";
        String password = "Secret1";
        String commandName = "GetIntegrationDelivery";
        File xmlFile = new File("java-src/examples/pmapi/sampleXmlFiles/getintegrationdelivery.xml");  // The xml file
        File exportDirectory = new File("java-src/examples/pmapi/sampleXmlFiles"); // The location of the export directory

        PMApiCommand pmApiCommand = new PMApiCommand(serverUrl, userId, password, commandName, exportDirectory, xmlFile);
        pmApiCommand.executeCommand();
    }
}

