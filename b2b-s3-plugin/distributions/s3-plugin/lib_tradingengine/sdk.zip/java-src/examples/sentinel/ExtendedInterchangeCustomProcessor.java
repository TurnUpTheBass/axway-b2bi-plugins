// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package examples.sentinel;

import com.axway.trkapiua.TrkApiUA;
import com.axway.trkapiua.TrkMessageUA;
import com.cyclonecommerce.collaboration.events.MessageSnapshot;
import com.cyclonecommerce.events2.event.Event;
import com.cyclonecommerce.monitoring.sentinel.SentinelConfig;
import com.cyclonecommerce.monitoring.sentinel.router.processor.adapter.EventToTrkMessageUAAdapter;
import com.cyclonecommerce.monitoring.sentinel.router.processor.builder.SentinelProcessorBuilder;
import com.cyclonecommerce.monitoring.sentinel.router.processor.exception.TransportException;
import com.cyclonecommerce.monitoring.sentinel.router.processor.filter.InterchangeSentinelEventsFilter;
import com.cyclonecommerce.monitoring.sentinel.router.processor.sender.SentinelSender;
import com.cyclonecommerce.monitoring.sentinel.router.processor.sender.XFBTrkMessageUASender;
import com.cyclonecommerce.monitoring.sentinel.router.processor.util.SentinelConnector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Interchange normal processing calls uses:
 * - filter: {@link InterchangeSentinelEventsFilter}
 * - adapter: {@link EventToTrkMessageUAAdapter}
 * - sender: {@link XFBTrkMessageUASender}
 *
 * Those are plugged into interchange under a group named:
 * <SentinelProcessorGroup name="MESSAGE_ACTIVITY">
 * 	<SentinelProcessor builderClass="com.cyclonecommerce.monitoring.sentinel.router.processor.builder.SendBufferedEventToSentinelProcessorBuilder"/>
 * </SentinelProcessorGroup>
 *
 * This is defined in a configuration file:
 * [Interchange]\conf\sentinel\sentinelProcessorsGroups.xml
 *
 * The normal interchange processor can be replaced by a custom implementation just by replacing the interchange builder
 * mentioned in the xml from above - (SendBufferedEventToSentinelProcessorBuilder).
 *
 * <SentinelProcessorGroup name="MESSAGE_ACTIVITY">
 * 	<SentinelProcessor builderClass="examples.sentinel.ExtendedInterchangeCustomProcessor"/>
 * </SentinelProcessorGroup>
 *
 * So our own implementation is plugged in that will extend the Interchange one, provided by our class:
 * ExtendedInterchangeCustomProcessor
 *
 * We've defined our own filter, adapter and sender classes in this example:
 * - filter: CustomExtendedFilter -> ignores all the events related to messages that are not Outbound
 * - adapter: CustomExtendedAdapter -> adds additional attributes named UserData1 and UserData2 to each event
 * - sender: CustomSentinelSender -> sends to the sentinel instance configured in interchange and also to another
 * different sentinel server.
 *
 * @author ssmogos
 */
public class ExtendedInterchangeCustomProcessor extends SentinelProcessorBuilder<Event, TrkMessageUA>
{
	public ExtendedInterchangeCustomProcessor(SentinelConfig sentinelConfig)
	{
		super(sentinelConfig);
	}

	@Override
	public void configure()
	{
		//insert our custom filter that will allow us to only publish events around Outbound messages. The rest will be filtered
		filterWith(new CustomExtendedFilter());

		//insert custom implementation to add additional information to the sentinel events.
		adaptWith(new CustomExtendedAdapter(SentinelConnector.getInstance().getBuffered()));

		//send using custom sender
		sendWith(new CustomSentinelSender(SentinelConnector.getInstance().getBuffered()));
	}

	private static class CustomExtendedFilter extends InterchangeSentinelEventsFilter
	{
		@Override
		public boolean doesPass(Event event)
		{
			if (event.getMetadataContent()
				instanceof MessageSnapshot)//MessageSnapshot content is subject to change between versions. This is just an example.
			{
				MessageSnapshot messageSnapshot = (MessageSnapshot)event.getMetadataContent();

				//let's only care about Outbound messages, the rest we'll throw them away...
				if (!"Outbound".equals(messageSnapshot.getDirection()))
					return false;
			}

			//invoke interchange logic to further filter the events.
			return super.doesPass(event);
		}

		@Override
		public String toString()
		{
			return "CustomExtendedFilter{}";
		}
	}

	/**
	 * After the interchange logic was triggered to adapt the event, then we add an additional attribute, extending
	 * what interchange is usually publishing in its TO.
	 */
	private static class CustomExtendedAdapter extends EventToTrkMessageUAAdapter
	{

		public CustomExtendedAdapter(TrkApiUA trkApiUA)
		{
			super(trkApiUA);
		}

		@Override
		public void initialize(SentinelConfig sentinelConfig)
		{
			super.initialize(sentinelConfig);
		}

		@Override
		protected List<HashMap<String, String>> translateEventToMap(Event event)
		{
			// invoke interchange logic
			List<HashMap<String, String>> translatedEvents = super.translateEventToMap(event);

			//ADD CUSTOM LOGIC TO POPULATE EXTRA INFO
			for (HashMap<String, String> translatedData : translatedEvents)
			{
				translatedData.put("UserData1", "Custom group added data 1");
				translatedData.put("UserData2", "Custom group added data 2");
			}

			return translatedEvents;
		}

		@Override
		public String toString()
		{
			return "Custom Enhanced Adapter.";
		}
	}

	/**
	 * We just wrap up the normal interchange sentinel sender and add our own to also send the event to a
	 * different sentinel server.
	 *
	 * Will send to another sentinel after the event was sent to the Interchange configured sentinel.
	 */
	private static class CustomSentinelSender extends SentinelSender<TrkMessageUA>
	{

		private XFBTrkMessageUASender interchangeSender = null;
		private XFBTrkMessageUASender customSender = null;

		public CustomSentinelSender(TrkApiUA interchangeSentinelSender)
		{
			interchangeSender = new XFBTrkMessageUASender(interchangeSentinelSender);
		}

		@Override
		public void initialize(SentinelConfig sentinelConfig)
		{
			// build our new sentinel sender
			String myExtraHost = "localhost";
			int myExtraPort = 1305;
			String myExtraBackupHost = "anotherHost";
			int myExtraBackupPort = 1234;

			final TrkApiUA newBufferedSender =
				SentinelConnector.getInstance().getBuffered(myExtraHost, myExtraPort,
															myExtraBackupHost, myExtraBackupPort);

			customSender = new XFBTrkMessageUASender(newBufferedSender);
		}

		@Override
		public void send(List<TrkMessageUA> message)
			throws TransportException
		{
			// need to make a copy as as soon as a message is sent out, its ref is removed from the list
			// that allows us to see if just a part of the messages were sent and what's left, is what has not manged to send

			List<TrkMessageUA> copiedList = new ArrayList<>(message);
			//send them using the interchange sender
			try
			{
				interchangeSender.send(message);
			}
			catch (TransportException e)
			{
				//We can chose to treat the exception and only send to the second sender
				//if we couldn't send with the interchange one...
			}

			//then send to another sentinel
			customSender.send(copiedList);
		}

		@Override
		public boolean stop()
		{
			return interchangeSender.stop() || customSender.stop();
		}

		@Override
		public String toString()
		{
			return "CustomSentinelSender{}";
		}
	}
}

