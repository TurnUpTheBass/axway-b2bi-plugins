// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package examples.sentinel;

import com.axway.trkapiua.TrkApiUA;
import com.axway.trkapiua.TrkMessageUA;
import com.axway.trkapiua.TrkMessageUAEvent;
import com.axway.trkapiua.TrkMessageUALink;
import com.cyclonecommerce.monitoring.sentinel.SentinelConfig;
import com.cyclonecommerce.monitoring.sentinel.SystemTrackedObject;
import com.cyclonecommerce.monitoring.sentinel.router.processor.adapter.SentinelAdapter;
import com.cyclonecommerce.monitoring.sentinel.router.processor.builder.SentinelProcessorBuilder;
import com.cyclonecommerce.monitoring.sentinel.router.processor.filter.SentinelFilter;
import com.cyclonecommerce.monitoring.sentinel.router.processor.sender.XFBTrkMessageUASender;
import com.cyclonecommerce.monitoring.sentinel.router.processor.util.SentinelConnector;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Custom builder that will add a custom new sentinel processor.
 *
 * The builder should be added under: conf/sentinel/sentinelProcessorsGroups.xml and a group element has to be defined for it.
 *
 * Example:
 * <SentinelProcessorGroups>
 *
 *     ....
 *
 * 		<SentinelProcessorGroup name="MyCustomGroup">
 * 			<SentinelProcessor builderClass="examples.sentinel.SentinelCustomProcessor"/>
 * 		</SentinelProcessorGroup>
 *
 * <SentinelProcessorGroups>
 *
 * Then in the custom code, for using the processor, a call can be made to:
 * HashMap<String, String> myData = ....
 * SentinelConnectorManager.getInstance().process("MyCustomGroup", myData);
 *
 * The SentinelProcessorGroup element can host multiple SentinelProcessor(s) elements.
 * If sending with the first defined SentinelProcessor in the group fails, then the defined following one gets invoked.
 *
 * @author ssmogos
 */
public class SentinelCustomProcessor
	extends SentinelProcessorBuilder<HashMap<String, String>, TrkMessageUA>
{
	private final static Logger logger = LogManager.getLogger(SentinelCustomProcessor.class);

	private Properties additionalProperties;

	public SentinelCustomProcessor(SentinelConfig sentinelConfig)
	{
		super(sentinelConfig);

		try(FileInputStream inputStream = new FileInputStream("../conf/sentinel/customSentinelConnection.properties") )
		{
			additionalProperties = new Properties();
			additionalProperties.load(inputStream);
		}
		catch (IOException e)
		{
			logger.error("Could not find properties file for custom sentinel processor builder");
		}
	}

	@Override
	public void configure()
	{
		filterWith(new SentinelFilter<HashMap<String, String>>()
		{
			@Override
			public void initialize(SentinelConfig sentinelConfig)
			{

			}

			@Override
			public boolean doesPass(HashMap<String, String> stringStringHashMap)
			{
				String direction = stringStringHashMap.get("Direction");
				return "Outbound".equals(direction);
			}
		});

		//if the interchange default defined connector is to be used:
		//final TrkApiUA bufferedSender = SentinelConnector.getInstance().getBuffered();
		//final List<TrkApiUA> directSender = SentinelConnector.getInstance().getDirect(); // for direct connections (not using overflow file)

		final TrkApiUA bufferedSender =
			SentinelConnector.getInstance().getBuffered(
				additionalProperties.getProperty("host"),
				Integer.parseInt(additionalProperties.getProperty("port")),
				additionalProperties.getProperty("backupHost"),
				Integer.parseInt(additionalProperties.getProperty("backupPort")));

		//if wanting to use the interchange standard adapter, use MapToTrkMessageUAAdapter
		adaptWith(new SentinelAdapter<HashMap<String, String>, TrkMessageUA>()
		{

			@Override
			public void initialize(SentinelConfig sentinelConfig)
			{

			}

			@Override
			public List<TrkMessageUA> buildMessage(HashMap<String, String> eventDetails)
			{
				List<TrkMessageUA> messages = new LinkedList<>();

				String currentTrackedObject = eventDetails.get(SystemTrackedObject.TRACKED_OBJECT_NAME);
				String currentTrackedObjectVersion = eventDetails.get(SystemTrackedObject.TRACKED_OBJECT_VERSION);

				TrkMessageUAEvent trkMessageUA = new TrkMessageUAEvent(bufferedSender, currentTrackedObject, currentTrackedObjectVersion);
				for (Map.Entry<String, String> eventDetail : eventDetails.entrySet())
				{
					if (eventDetail.getValue() != null)
						trkMessageUA.setAttribute(eventDetail.getKey(), eventDetail.getValue());
				}
				messages.add(trkMessageUA);

				// a way to generate links
				String parentTrackedObject = eventDetails.get("ParentTrackedObjectName");
				if (parentTrackedObject != null)
				{
					String parentCycleId = eventDetails.get("ParentCycleId");
					String currentCycleId = eventDetails.get(SystemTrackedObject.CYCLE_ID);
					TrkMessageUALink trkMessageUALink = new TrkMessageUALink(bufferedSender,
																			 parentTrackedObject,
																			 parentCycleId,
																			 currentTrackedObject,
																			 currentCycleId);
					messages.add(trkMessageUALink);
				}

				return messages;
			}
		});

		// sends the created TrkMessageUA messages to the specified sentinel connector
		sendWith(new XFBTrkMessageUASender(bufferedSender));

	}
}
