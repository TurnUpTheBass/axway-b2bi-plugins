// Copyright Axway Software, All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package examples.sentinel;

import com.cyclonecommerce.api.inlineprocessing.Message;
import com.cyclonecommerce.api.inlineprocessing.MessageProcessor;
import com.cyclonecommerce.monitoring.sentinel.SystemTrackedObject;
import com.cyclonecommerce.monitoring.sentinel.router.SentinelConnectorManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;

/**
 * Inline processor that can be used to send to sentinel using the Interchange default sentinel configuration.
 *
 * @author ssmogos
 */
public class SentinelInlineProcessorExample implements MessageProcessor
{
	private final static Logger logger = LogManager.getLogger(SentinelInlineProcessorExample.class);

	private String trackedObjectName;
	private String trackedObjectVersion;

	@Override
	public void setParameters(String parameters)
	{
		trackedObjectName = "SampleAction";
		trackedObjectVersion = "1.0";
	}

	@Override
	public void process(Message message)
	{
		if (logger.isDebugEnabled())
			logMessageAttributes(message);

		HashMap<String, String> eventDetails = new HashMap<>();
		eventDetails.put(SystemTrackedObject.TRACKED_OBJECT_NAME, trackedObjectName);
		eventDetails.put(SystemTrackedObject.TRACKED_OBJECT_VERSION, trackedObjectVersion);

		eventDetails.put(SystemTrackedObject.CYCLE_ID, message.getMetadata("CoreId"));
		eventDetails.put("DocumentType", message.getMetadata("ContentMimeType"));
		eventDetails.put("MyFixedString10", message.getMetadata("Direction"));
		eventDetails.put("MyVariableString250", "MyCustomProcessor");
		eventDetails.put("Direction", "Outbound");

// 		- interchange default initialized groups can be used - sentinel has to be enabled in interchange config
//		SentinelConnectorManager.getInstance().process(SentinelConnectorManager.PROCESSOR_TYPES.SEND_BUFFERED.name(), eventDetails);
//		SentinelConnectorManager.getInstance().process(SentinelConnectorManager.PROCESSOR_TYPES.SEND_DIRECT.name(), eventDetails);

		// or a custom group can be used. See SentinelCustomProcessor example
		SentinelConnectorManager.getInstance().process("MyCustomGroup", eventDetails);
	}

	private void logMessageAttributes(Message message)
	{
		for (Map.Entry<String, String> messageMetadata : message.getMetadata().entrySet())
			logger.debug("key=value: " + messageMetadata.getKey() + "=" + messageMetadata.getValue());
	}
}
