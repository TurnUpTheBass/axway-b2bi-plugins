// Copyright (c) 1996-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.startup;

import com.cyclonecommerce.clustercontroller.StartupService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * Performs a one-time task at startup that prints "Hello World" to log4j output.  This approach can be used to
 * spawn background threads or perform one-time initialization.  For example, loading a properties file into memory.  This
 * example simply prints Hello World to the log file once when the node is started.
 * <br>
 * <p>All Startup Service implementations must implement the StartupService interface.
 *
 * <p>To configure OneTimeHello as a Startup Service, edit conf/startup.xml.  You will find directions for configuring
 * Startup Services there.  You will need the name of this class (examples.startup.OneTimeHello).  This example does
 * not require a parameter.
 *
 * <p>To get you started, here's an example configuration snippet:
 * <pre>
 &ltTE&gt
	 &ltService class="examples.startup.OneTimeHello" /&gt
 &lt/TE&gt
 * </pre>
 *
 * <p>Using log4j2
 * <ul>
 * <li>You can use log4j2 to log error, warning, informational, and debug messages.
 * <li>Placing the following in conf/log4j2.xml will activate logging for all examples (no need to restart):  <code><Logger name="examples" level="DEBUG" /></code>
 * <li>You can also turn logging on/off for a particular subpackage.  Refer to conf/log4j2.xml for more information how to configure the logging
 * <li>The control node and the trading engine node may both potentially instantiate your client, so you should
 * look for log messages in both <machine_name>_cn.log and <machine_name>_te<n>.log.
 * </ul>
 * <br>
 *
 */
public class OneTimeHello implements StartupService {

	/** this is how you get the log4J logger instance for this class */
	private static Logger logger = LogManager.getLogger(OneTimeHello.class);

	/**
	 * Default constructor - the only constructor used by Interchange
	 */
	public OneTimeHello() {
		// prints a debug message to the log4j log file
		logger.debug("created");
	}

	/**
	 * Accepts the string parameter passed from the <code>startup.xml</code> configuration file.  This class does not
	 * expect a parameter.  This method implementation is required to satisfy the interface.
	 */
	public void init(String param) throws Exception {
		// prints a debug message to the log4j log file
		logger.debug("initializing");
	}

	/**
	 * Prints a one-time, friendly info message to the log4j log file.  This method is called by Cyclone
	 * Interchange during startup.
	 */
	public void start() throws Exception {
		// received signal to start
		logger.info("Hello World!!!  I'll stop by again if the node is restarted.");
	}

	/**
	 * Prints a debug message to the log4j log file.  This method will only be called durign controlled stops of a node.
	 */
	public void stop() throws Exception {
		// received signal to stop
		logger.debug("received signal to stop");
	}

}
