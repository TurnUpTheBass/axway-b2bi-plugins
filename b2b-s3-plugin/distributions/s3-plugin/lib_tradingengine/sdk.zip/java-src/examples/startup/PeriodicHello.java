// Copyright (c) 1996-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.startup;

import com.cyclonecommerce.clustercontroller.StartupService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * Creates a background thread that wakes up periodically to print hello world to the log4j log file.  This approach
 * can be used to spawn background threads or perform one-time initialization.  For example, loading a properties file
 * into memory then periodically checking to see if it has been changed.  If so, it could be dynamically reloaded instead
 * of requiring a restart of Interchange.
 *
 * <p>All Startup Service implementations must implement the StartupService interface.
 *
 * <p>To configure PeriodicHello as a Startup Service, edit conf/startup.xml.  You will find directions for configuring
 * Startup Services there.  You will need the name of this class (examples.startup.PeriodicHello).  The parameter specifies
 * the interval (in milliseconds) that the background thread should wake up to say hello.
 *
 * <p>To get you started, here's an example configuration snippet that configures this class to run every 10 seconds:
 * <pre>
 &ltTE&gt
	 &ltService class="examples.startup.PeriodicHello" param="10000" /&gt
 &lt/TE&gt
 * </pre>
 *
 * <p>Using log4j2
 * <ul>
 * <li>You can use log4j2 to log error, warning, informational, and debug messages.
 * <li>Placing the following in conf/log4j2.xml will activate logging for all examples (no need to restart):  <code><Logger name="examples" level="DEBUG" /></code>
 * <li>You can also turn logging on/off for a particular subpackage.  Refer to conf/log4j2.xml for more information how to configure the logging
 * <li>The control node and the trading engine node may both potentially instantiate your client, so you should
 * look for log messages in both <machine_name>_cn.log and <machine_name>_te<n>.log.
 * </ul>
 * <br>
 *
 *
 */
public class PeriodicHello implements StartupService {

	/** this is how you get the log4J logger instance for this class */
	private static Logger logger = LogManager.getLogger(PeriodicHello.class);

	/** this is the background thread */
	private StartupRunner runner = null;

	/**
	 * Default constructor - the only constructor used by Interchange
	 */
	public PeriodicHello() {
		logger.debug("created");
	}

	/**
	 *
	 * @param intervalInSeconds the number of seconds to wait between Hellos
	 */
	public void init(String intervalInSeconds) throws Exception {
		logger.debug("initializing");
		long interval = 5000;
		// if the parameter was provided, then parse it and set it.
		if ( intervalInSeconds == null || intervalInSeconds.trim().length()==0) {
			logger.debug("interval not specified, using default interval of (milliseconds) "+ interval);
		} else {
			try {
				interval = Long.parseLong(intervalInSeconds) * 1000;
				logger.debug("created with interval of (milliseconds) "+ interval);

			} catch(NumberFormatException nfe) {
				logger.debug("interval specified in parameter is not a well-formed number, using default interval of (milliseconds) "+ interval);
			}
		}

        runner = new StartupRunner(interval);
	}

	public void start() throws Exception {
		logger.debug("received signal to start");
		runner.start();
	}

	/**
	 * This method is called by CI whenever the specific node hosting this startup class is stopped.  This method is NOT called
	 * when the CI server is shutdown.
	 */
	public void stop() throws Exception {
		logger.debug("received signal to stop");
		runner.shutdown();
	}


	/**
	 *
	 */
	class StartupRunner extends Thread {
		// indicates whether this thread should continue to run or not
		private boolean shutdown = false;

		// specifies how long to wait between Hellos
		private long interval;

		// public constructor takes the param from the configuration file
		public StartupRunner(long interval) {
			// store the interval
			this.interval = interval;
		}

		public void shutdown() {
			shutdown = true;
		}

		public void run() {
			while(!shutdown) {
				logger.info("Hello World!!!");
				try  {Thread.sleep(interval); } catch(Exception e) {}
			}
		}

	}

}
