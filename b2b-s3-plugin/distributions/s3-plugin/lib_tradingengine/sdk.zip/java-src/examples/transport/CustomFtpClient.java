// Copyright (c) 2006-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package examples.transport;

import com.cyclonecommerce.tradingengine.transport.*;
import com.cyclonecommerce.tradingengine.transport.ftp.FtpMessage;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTP;
import com.cyclonecommerce.tradingengine.transport.ftp.FtpClientSettings;
import com.cyclonecommerce.util.VirtualData;

import java.io.IOException;

/*   This is a sample implementation of a custom FTP client for
 *   Interchange. For simplicity this class acts as an interface
 *   between Interchange and the Jakarta commons FTP client.
 *   Please address any questions you may have to Axway support,
 *   but be aware that questions regarding your specific
 *   implementation of a custom FTP client, Java, or the FTP
 *   client interface are beyond the scope of product support
 *   and you may be referred to professional services for such
 *   issues.
 *
 *   While this class has been tested and is functional, it is not
 *   meant for production use.  
 */

/*   In order to install a custom FTP client within Interchange
 *   you must place your package / file / jar within the bin
 *   directory and modify the server startup script such that
 *   the trading engine JVM invocation contains a reference to
 *   the class in question...
 *
 *   set TE_NODE_OPTIONS="-Xms256m -Xmx256m -Dcom.cyclonecommerce.ftp.client=com.sample.me.CustomFtpClient"
 */

public class CustomFtpClient
extends com.cyclonecommerce.tradingengine.transport.ftp.FtpClient
{
    protected FTPClient ftpClient = new FTPClient();

    /*   FTPClientSettings contains information from Interchange
     *   for the FTP client regarding its expected behavior.
     *
     *   some examples of these settings follow...
     *
     *   getHost - the host to which we should connect
     *   getControlPort - the port on which we should connect
     *   getPickupDir - the directory for file consumption/production
     *   getInboxDir - temp directory for writing files
     *   getPassive  - passive or active FTP?
     *   getUser - username
     *   getPassword - password
     */
    public CustomFtpClient(FtpClientSettings settings)
    throws TransportException
    {
        super(settings);
    }

    public void disconnect() throws UnableToDisconnectException
    {
        try
        {
            ftpClient.disconnect();
        }
        catch ( IOException e )
        {
            throw new UnableToDisconnectException(e);
        }
    }

    public void connect() throws UnableToConnectException
    {
        FtpClientSettings settings = getSettings();

        try
        {
            ftpClient.connect( settings.getHost(), settings.getControlPort() );
        }
        catch ( IOException e )
        {
            throw new UnableToConnectException(e);
        }
    }

    public void authenticate() throws UnableToAuthenticateException
    {
        FtpClientSettings settings = getSettings();

        try
        {
            ftpClient.login( settings.getUser(), settings.getPassword() );
        }
        catch ( IOException e )
        {
            throw new UnableToAuthenticateException(e);
        }
    }

    public String getWorkingDir() throws TransportException
    {
        try
        {
            return ftpClient.printWorkingDirectory();
        }
        catch ( IOException e )
        {
            throw new TransportException(e);
        }
    }

    /*
     *  returns a list of files within the pickup directory
     *  should try to avoid returning folder names...
     */
    public String[] list() throws UnableToConsumeException
    {
        try
        {
            ftpClient.changeWorkingDirectory(getSettings().getPickupDir());

            String[] files =  ftpClient.listNames();

            if(files == null)
            {
                files = new String[0];
            }

            return files;
        }
        catch ( IOException e )
        {
            throw new UnableToConsumeException(e);
        }
    }

    /*
     *  uploads a file directly to the pickup directory
     */
    public void send(FtpMessage ftpMessage) throws UnableToProduceException
    {
         try
        {
            ftpClient.setFileType( FTP.BINARY_FILE_TYPE );

            ftpClient.changeWorkingDirectory(getSettings().getPickupDir());

            ftpMessage.getData().writeTo( ftpClient.storeFileStream( ftpMessage.getFilename() ) );
        }
        catch ( IOException e )
        {
            throw new UnableToProduceException(e);
        }
    }

    /*
     *  downloads a file from the pickup directory
     */
    public FtpMessage receive(String string) throws UnableToConsumeException, FileNotFoundException
    {
        try
        {
            ftpClient.changeWorkingDirectory(getSettings().getPickupDir());

            FtpMessage message = new FtpMessage();
            message.setFilename( string );
            message.setData( new VirtualData( ftpClient.retrieveFileStream( string ) ) );

            return message;
        }
        catch ( IOException e )
        {
            throw new UnableToConsumeException(e);
        }
    }

    /*
     *  deletes a file from the pickup directory
     */
    public void delete(String string) throws UnableToDeleteException, FileNotFoundException
    {
        try
        {
            ftpClient.changeWorkingDirectory(getSettings().getPickupDir());

            ftpClient.deleteFile( string );

        }
        catch ( IOException e )
        {
            throw new UnableToDeleteException(e);
        }
    }
}
