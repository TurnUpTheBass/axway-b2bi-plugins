// Copyright (c) 1996-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.transport;

import com.cyclonecommerce.collaboration.MetadataDictionary;
import com.cyclonecommerce.jdbc.InterchangeDataSource;
import com.cyclonecommerce.tradingengine.transport.FileNotFoundException;
import com.cyclonecommerce.tradingengine.transport.TransportInitializationException;
import com.cyclonecommerce.tradingengine.transport.TransportTestException;
import com.cyclonecommerce.tradingengine.transport.UnableToAuthenticateException;
import com.cyclonecommerce.tradingengine.transport.UnableToConnectException;
import com.cyclonecommerce.tradingengine.transport.UnableToConsumeException;
import com.cyclonecommerce.tradingengine.transport.UnableToDeleteException;
import com.cyclonecommerce.tradingengine.transport.UnableToDisconnectException;
import com.cyclonecommerce.tradingengine.transport.UnableToProduceException;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableClient;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableException;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableMessage;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableSettings;
import com.cyclonecommerce.util.VirtualData;
import com.cyclonecommerce.webservices.collaboration.ebxml.EbxmlMetadataDictionary;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * A pluggable transport client for Cyclone Interchange which consumes ebXML messages from the database.  It is assumed
 * that some back-end process is placing outbound messages in the database to be picked up and processed by Cyclone.
 *
 * <p>All pluggable transport client implementations must implement the PluggableClient interface.
 *
 * <p>Here's roughly the schema in use:
 *<pre>
CREATE TABLE INTEGRATION_Msg_Outbound(
	   MessageID Number(12) NOT NULL  PRIMARY KEY,
	   protocol VARCHAR(10) DEFAULT 'ebXML',
	   protocolVersion VARCHAR(5) DEFAULT '2.0',
	   Msg_From VARCHAR(30) NOT NULL,
	   FromRole VARCHAR(30) NOT NULL,
	   Msg_To VARCHAR(30) NOT NULL,
	   ToRole VARCHAR(30) NOT NULL,
	   Service VARCHAR(30) NOT NULL,
	   Action VARCHAR(30) NOT NULL,
	   CPAId VARCHAR(30) NOT NULL,
	   POLLED NUMBER(1) DEFAULT 1
);

CREATE TABLE INTEGRATION_Msg_Payloads(
	   PayloadId	Number (12) NOT NULL,
	   MessageId	Number (12) NOT NULL,
	   MimeContentId VARCHAR(30) NOT NULL,
	   MimeContentType VARCHAR(30) NOT NULL,
	   CONSTRAINT PK_MSG_Payloads PRIMARY KEY(PayloadId,MessageId)
);

CREATE TABLE INTEGRATION_Msg_Location(
	   LocationId Number(12) NOT NULL,
	   Location_Type VARCHAR(30) NOT NULL,
	   Path VARCHAR(70)
);

commit;
</pre>
 *
 * <p>Here's an example pluggable transports XML configuration element:
 * <pre>
 &ltTransportDefinition name="Outbound from DB via JDBC" description="Consumes outbound messages from a database." available="true"&gt
	 &ltClass&gtcom.cyclonecommerce.tmobile.integration.DBIntegrationClient&lt/Class&gt
	 &ltUsages&gt
		 &ltConsume&gt
			 &ltIntegration/&gt
		 &lt/Consume&gt
	 &lt/Usages&gt
	 &ltSettingDefinitions&gt
		 &ltSettingDefinition name="Instance Name" description="Describe the instance from which messages will be consumed." type="string" required="true" encrypt="false" mask="false"/&gt
	 &lt/SettingDefinitions&gt
	 &ltConstantSettings&gt
		 &ltConstantSetting name="Sender routing id type" value="string" description="The type qualifier for the Sender's routing id"/&gt
		 &ltConstantSetting name="Receiver routing id type" value="string" description="The type qualifier for the Receiver's routing id"/&gt
		 &ltConstantSetting name="Service type" value="string" description="The type qualifier of the Service"/&gt
	 &lt/ConstantSettings&gt
 &lt/TransportDefinition&gt
 </pre>
 *
 * <p>Using log4j2
 * <ul>
 * <li>You can use log4j2 to log error, warning, informational, and debug messages.
 * <li>Placing the following in conf/log4j2.xml will activate logging for all examples (no need to restart):  <code><Logger name="examples" level="DEBUG" /></code>
 * <li>You can also turn logging on/off for a particular subpackage.  Refer to conf/log4j2.xml for more information how to configure the logging
 * <li>The control node and the trading engine node may both potentially instantiate your client, so you should
 * look for log messages in both <machine_name>_cn.log and <machine_name>_te<n>.log.
 * </ul>
 * <br>
 *
 */



public class DBIntegrationClient implements PluggableClient {


	/** the log4j logger for this class **/
	private static Logger logger = LogManager.getLogger(DBIntegrationClient.class);

	/** the primary table name to read transactions from **/
	private static final String MSG_TABLE_NAME = "INTEGRATION_Msg_Outbound";
	/** the payload table name to read transactions from **/
	private static final String MSG_PAYLOAD_TABLE_NAME = "INTEGRATION_Msg_Payloads";
	/** the file location table name to read transactions from **/
	private static final String MSG_LOCATION_TABLE_NAME = "INTEGRATION_Msg_Location";

	/** MessageID database column **/
	public static final String DB_MSG_ID = "MessageID";
	/** polled database column **/
	public static final String DB_POLLED = "polled";
	/** Msg_From database column **/
	public static final String DB_FROM = "Msg_From";
	/** FromRole database column **/
	public static final String DB_FROM_ROLE = "FromRole";
	/** Msg_To database column **/
	public static final String DB_TO = "Msg_To";
	/** ToRole database column **/
	public static final String DB_TO_ROLE = "ToRole";
	/** Service database column **/
	public static final String DB_SERVICE = "Service";
	/** ebXMLAction database column **/
	public static final String DB_ACTION = "ebXMLAction";
	/** CPAId database column **/
	public static final String DB_CPAID = "CPAId";
	/** payloadid database column **/
	public static final String DB_PAYLOAD_ID = "payloadid";
	/** mimecontentid database column **/
	public static final String DB_MIME_CONTENT_ID = "mimecontentid";
	/** mimecontenttype database column **/
	public static final String DB_MIME_CONTENT_TYPE = "mimecontenttype";
	/** locationid database column **/
	public static final String DB_LOCATION_ID = "locationid";
	/** location_type database column **/
	public static final String DB_LOCATION_TYPE = "location_type";
	/** path database column **/
	public static final String DB_PATH = "path";

	/** SQL to select messages not previously polled from the database */
	private static final String SQL_SELECT_IDS = "SELECT "+DB_MSG_ID+" FROM "+ MSG_TABLE_NAME + " WHERE "+DB_POLLED+" = 0";
	/** SQL to mark-for-delete messages thath have been received */
	private static final String SQL_DELETE_MSG = "UPDATE "+ MSG_TABLE_NAME+" SET "+DB_POLLED+" = 1 WHERE "+DB_MSG_ID+" = ?";
	/** SQL to select a particular messages from the database */
	private static final String SQL_SELECT_MSG = "SELECT * FROM "+ MSG_TABLE_NAME+" where "+DB_MSG_ID+" = ?";
	/** SQL to select payload information from the database */
	private static final String SQL_SELECT_PAYLOAD = "SELECT * FROM "+MSG_PAYLOAD_TABLE_NAME+" P INNER JOIN "+MSG_LOCATION_TABLE_NAME+" L ON P."+DB_PAYLOAD_ID+" = L."+DB_PAYLOAD_ID+" WHERE (P."+DB_MSG_ID+" = ?)";

    /** the connection to the DB.  This is obtained in connect and released in disconnect */
	private Connection _connection = null;

	// these are used to retrieve and store the user and constant settings from the configuration
	/** user defined setting for the instance name */
	private static final String SETTING_INSTANCE_NAME = "Instance Name";
	/** user defined setting for the sender's routing id type (usually "string") */
	private static final String SETTING_SENDER_ID_TYPE = "Sender routing id type";
	/** user defined setting for the receiver's routing id type (usually "string") */
	private static final String SETTING_RECEIVER_ID_TYPE = "Receiver routing id type";
	/** user defined setting for the service type (usually "string") */
	private static final String SETTING_SERVICE_TYPE = "Service type";

	/** storage for the configured instance name */
	private String _instanceName = null;
	/** storage for the configured sender id type */
	private String _senderIdType = null;
	/** storage for the configured receiver id type */
	private String _receiverIdType = null;
	/** storage for the configured service type */
	private String _serviceType = null;


	/**
	 * Default constructor - the only constructor used by Interchange
	 */
	public DBIntegrationClient() {
		/// do nothing
	}

	/**
	 * Initialize our pluggable client instance.  Retrieve the pluggable settings here
	 *
	 * @param pluggableSettings the settings provided by conf/pluggabletransports.xml and the UI
	 */
	public void init(PluggableSettings pluggableSettings) throws TransportInitializationException {

		// retrieve and store user settings
		try {
			_instanceName = pluggableSettings.getSetting(SETTING_INSTANCE_NAME);
		} catch (PluggableException e) {
			throw new TransportInitializationException("Error retrieving user setting for pluggable transport", e);
		}

		// retrieve and store constant settings
		try {
			_senderIdType = pluggableSettings.getConstantSetting(SETTING_SENDER_ID_TYPE);
			_receiverIdType = pluggableSettings.getConstantSetting(SETTING_RECEIVER_ID_TYPE);
			_serviceType = pluggableSettings.getConstantSetting(SETTING_SERVICE_TYPE);
		} catch (PluggableException e) {
			throw new TransportInitializationException("Error retrieving constant setting for pluggable transport", e);
		}

	}

	/**
	 * Get a db connection
	 */
	public void connect() throws UnableToConnectException {
//		logger.debug("Connecting to DB Client for instance:" + _instanceName);

		// this gets a database connection from db pool managed by Interchange
		try {
			// NOTE: THIS APPROACH IS NOT SUPPORTED BY CYCLONE AND MAY CHANGE AT ANY TIME!!!
			// PLEASE DO NOT USE THIS TO OBTAIN A DB CONNECTION.  DO IT YOUR OWN WAY.
			_connection = InterchangeDataSource.getInstance().getConnection();
			_connection.setAutoCommit(true);
		} catch (SQLException e) {
			throw new UnableToConnectException("unable to obtain db connection from pool", e);
		}
	}

	/**
	 * Our client doesn't need to do anything at all in the authenticate method..
	 */
	public void authenticate() throws UnableToAuthenticateException {
//		logger.debug("Authenticating DB client....nothing to do");
	}

	/**
	 * Our db based client is pollable because we can return a list of files waiting in the table.
	 * Since we return true from here, the trading engine will know it can call our list method.
	 */
	public boolean isPollable() {
		return true;
	}

	/**
	 * Return a list of messages waiting in the database consumption table.  The trading engine will subsequently call
	 * consume() once for each entry in the list.  Since we could be running in a cluster of multiple trading
	 * engine nodes, we cannot say for sure whether consume() will be called on the same machine as list() was.
	 * Be sure not to keep anything in memory needed to consume the message.
	 */
	public String[] list() throws UnableToConsumeException {
//		logger.debug("Listing entries for instance: " +  _instanceName);

		// perform the query to obtain the list of message ids waiting to be consumed
		PreparedStatement stmt = null;
		ResultSet results = null;
		List ids = new ArrayList();
		try {
			stmt = _connection.prepareStatement(SQL_SELECT_IDS);
			results = stmt.executeQuery();
			// for each row returned, put the message id in the list
			while(results.next()) {
				int id = results.getInt(1);
				logger.debug("poller found item#"+ id);
				ids.add(String.valueOf(id));
			}
		} catch (SQLException e) {
			throw new UnableToConsumeException("unable to poll instance:"+ _instanceName, e);
		} finally {
			// always clean up db resources
			try  {stmt.close();} catch(Exception e2){};
			try  {results.close();} catch(Exception e2){};
		}

		// convert the list to a String[] and return
		String[] idList = new String[ids.size()];
		ids.toArray(idList);
		logger.debug(ids.size() +" results to return:" + ids);
		return idList;
	}

	/**
	 * Produce is not used.  This is a consumer class only
	 */
	public PluggableMessage produce(PluggableMessage message, PluggableMessage returnMessage) throws UnableToProduceException {
		throw new UnableToProduceException("msg production not supported");
	}

	/**
	 * Read the specified message in the consumption table and return a PluggableMessage containing it to the
	 * tradinging engine.  The nameFromList parameter will contain a messageId that we previously returned when the
	 * list method was called.
	 *
	 * @param msg the message model to populate with information about the message being consumed
	 * @param nameFromList the message reference to consume
	 * @return the consumed message
	 */
	public PluggableMessage consume(PluggableMessage msg, String nameFromList) throws UnableToConsumeException, FileNotFoundException {

		logger.debug("Receiving message# " + nameFromList + " from instance: " + _instanceName);

		// convert the string param to a number
		int msgNumber = -1;
		try {
			msgNumber = Integer.parseInt(nameFromList);
		} catch (NumberFormatException e) {
			throw new UnableToConsumeException("unable to construct message id from "+ nameFromList);
		}

		// query to select the metadata associated with this message
		PreparedStatement stmt = null;
		ResultSet results = null;
		try {
			stmt = _connection.prepareStatement(SQL_SELECT_MSG);
			stmt.setInt(1, msgNumber);
			results = stmt.executeQuery();
			if ( !results.next()) {
				// there is currently no means to reject the message.  For now, just delete and throw the error
				try {delete(nameFromList);} catch(Exception e2) {}
				throw new UnableToConsumeException("unable to load message# "+ msgNumber );
			}

			// read the query results
			String from = results.getString(DB_FROM);
			String fromRole = results.getString(DB_FROM_ROLE);
			String to = results.getString(DB_TO);
			String toRole = results.getString(DB_TO_ROLE);
			String service = results.getString(DB_SERVICE);
			String action = results.getString(DB_ACTION);

			logger.debug("consuming item#"+ msgNumber);
			logger.debug("Msg#:"+msgNumber+", From:"+from+", FromRole:"+fromRole+", to:"+to+", toRole:"+toRole+", svc:"+service+", action:"+ action);

			// set the metadata on the Cyclone message
            msg.setMetadata(MetadataDictionary.SENDER_ROUTING_ID, from);
			msg.setMetadata(MetadataDictionary.SENDER_ROUTING_ID_TYPE, _senderIdType);
			msg.setMetadata(EbxmlMetadataDictionary.EBXML_FROM_ROLE, fromRole );
			msg.setMetadata(MetadataDictionary.RECEIVER_ROUTING_ID, to);
			msg.setMetadata(MetadataDictionary.RECEIVER_ROUTING_ID_TYPE, _receiverIdType);
			msg.setMetadata(EbxmlMetadataDictionary.EBXML_TO_ROLE, toRole );
			msg.setMetadata(EbxmlMetadataDictionary.EBXML_SERVICE, service );
			msg.setMetadata(EbxmlMetadataDictionary.EBXML_SERVICE_TYPE, _serviceType );
			msg.setMetadata(EbxmlMetadataDictionary.EBXML_ACTION, action );

			// do not provide the CPA ID.  It is better to have CI look it up for you
//			msg.setMetadata(EbxmlMetadataDictionary.EBXML_CPA_ID, cpaId );

			try  {stmt.close();} catch(Exception e2){};
			try  {results.close();} catch(Exception e2){};

			// now process the payload reference.  note that CI only supports one payload per message.  However, ebXML
			// within CI supports multiple attachments.  To submit an ebXML message with multiple attachments, create
			// an MMD that references the payloads.  Use the MMD for the message payload.
			stmt = _connection.prepareStatement(SQL_SELECT_PAYLOAD);
			stmt.setInt(1, msgNumber);
			results = stmt.executeQuery();
			while(results.next()) {

                // fields: payloadid, messageid, mimecontentid, mimecontenttype, locationid, locationtype, path
				String payloadId = results.getString(DB_PAYLOAD_ID);
				String messageId = results.getString(DB_PAYLOAD_ID);
				String mimeContentId = results.getString(DB_MIME_CONTENT_ID);
				String mimeContentType = results.getString(DB_MIME_CONTENT_TYPE);
				String locationId = results.getString(DB_LOCATION_ID);
				String locationType = results.getString(DB_LOCATION_TYPE);
				String path = results.getString(DB_PATH);

				File payload  = new File(path);
				if ( !payload.exists() || !payload.isFile() ) {
					// there is currently no means to reject the message.  For now, just delete and throw the error
					try {delete(nameFromList);} catch(Exception e2) {}
					throw new UnableToConsumeException("unable to find payload file at: " + payload.getAbsolutePath() );
				}

				// create the virtual data to represent the payload and add it to the message
				try {
					VirtualData v = new VirtualData(payload, true);
					msg.setData(v);
				} catch (IOException e) {
					// there is currently no means to reject the message.  For now, just delete and throw the error
					try {delete(nameFromList);} catch(Exception e2) {}
					throw new UnableToConsumeException("unable to load virtual data for file at:"+ payload.getAbsolutePath());
				}

			}

		} catch (SQLException e) {
			// there is currently no means to reject the message.  For now, just delete and throw the error
			try {delete(nameFromList);} catch(Exception e2) {}
			throw new UnableToConsumeException("unable to poll instance:"+ _instanceName, e);
		} finally {
			// always clean up db resources
			try  {stmt.close();} catch(Exception e2){};
			try  {results.close();} catch(Exception e2){};
		}

		// return the message just consumed
		return msg;
	}

	/**
	 * Delete the specified message in the database.  The trading engine will call this method after
	 * it has successfully called consume() for this message.
	 *
	 * @param nameFromList the file reference to delete
	 */
	public void delete(String nameFromList) throws UnableToDeleteException, FileNotFoundException {
		logger.debug("Deleting message# " + nameFromList + " from instance: "+  _instanceName );

		// conver the string param to a number
		int msgNumber = -1;
		try {
			msgNumber = Integer.parseInt(nameFromList);
		} catch (NumberFormatException e) {
			throw new UnableToDeleteException("unable to construct message id from "+ nameFromList);
		}

		// issue SQL to mark the message as read (or you could just delete it)
		PreparedStatement stmt = null;
		try {
			stmt = _connection.prepareStatement(SQL_DELETE_MSG);
			stmt.setInt(1, msgNumber );
			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new UnableToDeleteException("unable delete message# "+ nameFromList + " from instance:"+ _instanceName, e);
		} finally {
			// always clean up db resources
			try  {stmt.close();} catch(Exception e2){};
		}

	}

	/**
	 * Return an information string if our client is working correctly.  Otherwise throw TransportTestException
	 * with an appropriate message.  This implementation just does a query to make sure we can get to the database
	 */
	public String test() throws TransportTestException {
		logger.debug("Testing instance: " +  _instanceName);

		// perform a select on the message table to make sure we have connectivity and that the table exists
		// you might want to do deeper diagnostics for more assurance that everything is OK but this will catch most errors
		PreparedStatement stmt = null;
		ResultSet results = null;
		try {
			stmt = _connection.prepareStatement(SQL_SELECT_MSG);
			stmt.setInt(1, -1);
			results = stmt.executeQuery();

		} catch (SQLException e) {
			throw new TransportTestException("problem querying message store for instance:"+ _instanceName, e);
		} finally {
			// always clean up db resources
			try  {stmt.close();} catch(Exception e2){};
			try  {results.close();} catch(Exception e2){};
		}

		// return the message just consumed
		return "Success";
	}

	/**
	 * Return/close the database connection
	 */
	public void disconnect() throws UnableToDisconnectException {
//		logger.debug("Disconnecting db client for instance: "+ _instanceName);

		if ( _connection != null ) {
			try {
				_connection.close();
			} catch(Exception e) {
			}
		}
	}

	/**
	 * Return a URL that the trading engine can use to uniquely identify the location which our transport
	 * is communicating with.  (See comments in interface for more information.)
	 */
	public String getUrl() {
		return "msgDB://" +  _instanceName;
	}

}
