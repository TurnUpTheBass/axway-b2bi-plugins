// Copyright (c) 1996-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.transport;

import com.cyclonecommerce.tradingengine.transport.UnableToConnectException;
import com.cyclonecommerce.tradingengine.transport.UnableToAuthenticateException;
import com.cyclonecommerce.tradingengine.transport.UnableToConsumeException;
import com.cyclonecommerce.tradingengine.transport.UnableToProduceException;
import com.cyclonecommerce.tradingengine.transport.FileNotFoundException;
import com.cyclonecommerce.tradingengine.transport.UnableToDeleteException;
import com.cyclonecommerce.tradingengine.transport.UnableToDisconnectException;
import com.cyclonecommerce.tradingengine.transport.TransportTestException;
import com.cyclonecommerce.tradingengine.transport.TransportInitializationException;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableClient;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableSettings;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableException;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableMessage;
import com.cyclonecommerce.util.VirtualData;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Iterator;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Example of a pluggable transport client which produces and consumes messages to and from the file system.  Once this
 * transport is configured, a new transport choice is offered to the application administrator.  This example Pluggable
 * Transport requires the user to configure the file system directory to operate on.
 *
 * <p>All pluggable transport client implementations must implement the PluggableClient interface.
 *
 * <p>To configure PluggableFileSysClient as a pluggable transport, edit conf/pluggabletransport.xml.  You will find
 * directions for configuring pluggable transports there.  To configure this class, you will need the following:<br>
 * <ul>
 * <li>the name of this class (examples.transport.PluggableFileSysClient)
 * <li>to declare a 'SettingDefinition' called "Directory"
 * <li>to declare a 'ConstantSetting' called "Fum3 XPath"
 * </ul>
 *
 * <p>To get you started, here's an example configuration of both a consumer and a producer:
 * <pre>
 &ltTransportDefinition name="Custom file system consumer" description="Pluggable transport which consumes messages from the file system." available="true"&gt
	 &ltClass&gtexamples.transport.PluggableFileSysClient&lt/Class&gt
	 &ltUsages&gt
		 &ltConsume&gt
			 &ltIntegration/&gt
		 &lt/Consume&gt
	 &lt/Usages&gt
	 &ltSettingDefinitions&gt
		 &ltSettingDefinition name="Directory" description="Directory from which files will be consumed." type="string" required="true" encrypt="false" mask="false"/&gt
	 &lt/SettingDefinitions&gt
	 &ltConstantSettings&gt
		 &ltConstantSetting name="Fum3 XPath" value="/foo/fum[3]"/&gt
	 &lt/ConstantSettings&gt
 &lt/TransportDefinition&gt
 &ltTransportDefinition name="Custom file system producer" description="Pluggable transport which produces messages to the file system." available="true"&gt
	 &ltClass&gtexamples.transport.PluggableFileSysClient&lt/Class&gt
	 &ltUsages&gt
		 &ltProduce&gt
			 &ltIntegration/&gt
		 &lt/Produce&gt
	 &lt/Usages&gt
	 &ltSettingDefinitions&gt
		 &ltSettingDefinition name="Directory" description="Directory where files will be produced." type="string" required="true" encrypt="false" mask="false"/&gt
	 &lt/SettingDefinitions&gt
 &lt/TransportDefinition&gt
</pre>
 *
 * <p>Using log4j2
 * <ul>
 * <li>You can use log4j2 to log error, warning, informational, and debug messages.
 * <li>Placing the following in conf/log4j2.xml will activate logging for all examples (no need to restart):  <code><Logger name="examples" level="DEBUG" /></code>
 * <li>You can also turn logging on/off for a particular subpackage.  Refer to conf/log4j2.xml for more information how to configure the logging
 * <li>The control node and the trading engine node may both potentially instantiate your client, so you should
 * look for log messages in both <machine_name>_cn.log and <machine_name>_te<n>.log.
 * </ul>
 * <br>
 */
public class PluggableFileSysClient implements PluggableClient {
	/** a constant used to retrieve Directory Setting from the configuration **/
	private static final String SETTING_DIRECTORY = "Directory";

	/** the log4j logger for this class **/
	private static Logger logger = LogManager.getLogger(PluggableFileSysClient.class);

	/** stores the directory to consume and produce files to **/
	private File directory;

	/** a Map containing temporary Message metadata **/
	private Map metadata = null;


	/**
	 * Default constructor - the only constructor used by Interchange
	 */
	public PluggableFileSysClient() {
		/// do nothing
	}

	/**
	 * Initialize the pluggable client instance.
	 *
	 * @param pluggableSettings the settings provided by conf/pluggabletransports.xml and the UI
	 */
	public void init(PluggableSettings pluggableSettings) throws TransportInitializationException {
		try {
			// Assign the value of the "Directory" item in the settings map to our "directory" member variable.
			String dir = pluggableSettings.getSetting(SETTING_DIRECTORY);
			directory = new File(dir);
			logger.debug("Setting " + SETTING_DIRECTORY + "=" + directory.getAbsolutePath());

			// get all constant settings and store them in the local metadata map for later use
			metadata = new HashMap(pluggableSettings.getConstantSettings());
			if (metadata != null && !metadata.isEmpty()) {
				Iterator i = metadata.keySet().iterator();
				while (i.hasNext()) {
					String key = (String) i.next();
					logger.debug("Constant setting " + key + "=" + metadata.get(key));
				}
			}
		} catch (PluggableException e) {
			throw new TransportInitializationException("Error getting setting: " + e.toString(), e);
		}
	}

	/**
	 * Our example client implementation of connect simply gets the directory from the settings map and creates
	 * it if it does not exist.
	 */
	public void connect() throws UnableToConnectException {
		logger.debug("Connecting to pluggable client");

		// create the dir if it doesn't exist
		if (!directory.exists()) {
			logger.debug("Creating directory: " + directory.getAbsolutePath());
			directory.mkdirs();
		}
	}

	/**
	 * Our file system-based client doesn't need to do anything special in the authenticate method..
	 */
	public void authenticate() throws UnableToAuthenticateException {
		logger.debug("Authenticating pluggable client");
	}

	/**
	 * Our file system-based client is pollable because we can return a list of files waiting in
	 * our inbound directory.  Since we return true from here, the trading engine will know it can
	 * call our list method.
	 */
	public boolean isPollable() {
		boolean isPollable = true;
		logger.debug("isPollable returning: " + isPollable);
		return isPollable;
	}

	/**
	 * Return a list of files waiting in our consumption directory.  The trading engine will subsequently call
	 * consume once for each file in the list.  Since we could be running in a cluster of multiple trading
	 * engine nodes, we cannot say for sure whether consume will be called on the same machine as list was.
	 * Thus, the files need to be on a shared directory accessible from all the nodes in the cluster.
	 */
	public String[] list() throws UnableToConsumeException {
		logger.debug("Listing files in consumption directory: " + directory.getAbsolutePath());
		return directory.list();
	}

	/**
	 * Write the contents of the specified message to a file in the production directory.
	 *
	 * @param message the message being processed by CI
	 * @param returnMessage not used in this example
	 * @return always null
	 * @throws UnableToProduceException if there was a problem producing the message
	 */
	public PluggableMessage produce(PluggableMessage message, PluggableMessage returnMessage) throws UnableToProduceException {
		String filename = message.getFilename().trim();
		logger.debug("Producing file " + filename + " to directory: " + directory.getAbsolutePath());

		logger.debug(metadataToString(message.getMetadata(), "Message metadata in produce()"));

		if (filename == null || filename.equals(""))
			throw new UnableToProduceException("Pluggable client could not produce file because filename is empty");

		// create the output file handle
		File outputFile = new File(directory, filename);

		// create the output file stream
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(outputFile);
		} catch (java.io.FileNotFoundException e) {
			String msg = "Pluggable client: Unable to produce file " + outputFile.getAbsolutePath() + "; " + e.toString();
			throw new UnableToProduceException(msg, e);
		}

		// write the file data to the new output file
		VirtualData data = message.getData();
		try {
			data.writeTo(fos);
		} catch (IOException e) {
			String msg = "Pluggable client: Unable to produce file " + outputFile.getAbsolutePath() + "; " + e.toString();
			throw new UnableToProduceException(msg, e);
		}

		return null;
	}

	/**
	 * Read the specified file in the consumption directory and return a PluggableMessage containing it to the
	 * tradinging engine.  The nameFromList parameter will contain a name that we previously returned when our
	 * list method was called.
	 */
	public PluggableMessage consume(PluggableMessage message, String nameFromList) throws UnableToConsumeException, FileNotFoundException {
		logger.debug("Receiving file " + nameFromList + " from directory: " + directory.getAbsolutePath());

		// set the name of the file we will produce
		message.setFilename(nameFromList);

		// add all the constant settings defined for this transport to the message metadata
		if ( metadata!=null && !metadata.isEmpty()) {
			Iterator i = metadata.keySet().iterator();
			while(i.hasNext()) {
				String key = (String)i.next();
				message.setMetadata(key, (String)(metadata.get(key)));
			}
		}

		// create a virtual data object and add the new file to it
		VirtualData data = new VirtualData();
		File inputFile = new File(directory, nameFromList);

		try {
			data.readFrom(inputFile);
		} catch (IOException e) {
			String msg = "Pluggable client: Unable to consume file " + inputFile.getAbsolutePath() + "; " + e.toString();
			throw new UnableToConsumeException(msg, e);
		}

		// set the new virtual data as the new content
		message.setData(data);

		logger.debug(metadataToString(message.getMetadata(), "Message metadata in consume()"));

		return message;
	}

	/**
	 * Delete the specified file in the consumption directory.  The trading engine will call this method after
	 * it has successfully called our consume method for this file.
	 *
	 * @param nameFromList the file reference to delete
	 */
	public void delete(String nameFromList) throws UnableToDeleteException, FileNotFoundException {
		logger.debug("Deleting file " + nameFromList + " from directory " + directory);

		File file = new File(directory, nameFromList);

		if (!file.exists()) {
			logger.warn("Delete called for file which does not exist: " + file.getAbsolutePath());
			return;
		}

		file.delete();
	}

	/**
	 * Return an information string if our client is working correctly.  Otherwise throw TransportTestException
	 * with an appropriate message.  This implementation simply checks to make sure the directory exists.
	 */
	public String test() throws TransportTestException {
		if (!directory.exists())
			throw new TransportTestException("Directory does not exist: " + directory);

		return "Pluggable file transport functioning properly";
	}

	/**
	 * Our file system-based client doesn't need to do anything special here.
	 */
	public void disconnect() throws UnableToDisconnectException {
		logger.debug("Disconnecting from pluggable client");
	}

	/**
	 * Return a URL that the trading engine can use to uniquely identify the location which our transport
	 * is communicating with.  (See comments in interface for more information.)
	 */
	public String getUrl() {
		return "filetrans://" + directory.getAbsolutePath();
	}

	/**
	 * This is an internal method that shows all the metadata values in the returned string
	 * @param description - displayed as the first line of result
	 * @return a string containing the metadata keys and values
	 */
	private String metadataToString(Map m, String description) {
		StringBuffer sb = new StringBuffer(description);
		if ( description == null ) {
			sb.append("Metadata");
		}
		if ( m == null | m.isEmpty() ) {
			sb.append("\tEMPTY");
		} else {
			Iterator i = m.keySet().iterator();
			while(i.hasNext()) {
				String key = (String)i.next();
				sb.append("\n\t").append(key).append(" = ").append(m.get(key));
			}
		}
		sb.append("\n");
		return sb.toString();
	}
}
