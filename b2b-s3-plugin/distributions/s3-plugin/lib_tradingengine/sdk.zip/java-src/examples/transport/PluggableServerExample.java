// Copyright (c) 2009-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.transport;

import com.axway.cluster.extensions.thread.EventedThread;
import com.cyclonecommerce.tradingengine.transport.pluggable.PluggableMessageImpl;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableMessage;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableServer;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableServerAPI;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.PluggableException;
import com.cyclonecommerce.tradingengine.transport.pluggable.api.SystemThrottleEngagedException;
import com.cyclonecommerce.util.VirtualData;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

/**
 * Example of a Pluggable Server implmentation that will consume files from the file system.  This
 * example shows how to launch a seperate thread to consume files and dispatch the messages into
 * the trading engine.
 * <br>
 * This example assumes that two parameters are passed in to the pluggable server incicating
 * the polling interval and the directory to check for files from.
 * <br>
 * Note: this is only an example of a pluggable server implementation and not a concrete implementation
 * of consuming files from a file system.
 * <p/>
 * <p>Using log4j2
 * <ul>
 * <li>You can use log4j2 to log error, warning, informational, and debug messages.
 * <li>Placing the following in conf/log4j2.xml will activate logging for all examples (no need to restart):  <code><Logger name="examples" level="DEBUG" /></code>
 * <li>You can also turn logging on/off for a particular subpackage.  Refer to conf/log4j2.xml for more information how to configure the logging
 * <li>The control node and the trading engine node may both potentially instantiate your client, so you should
 * look for log messages in both <machine_name>_cn.log and <machine_name>_te<n>.log.
 * </ul>
 * <br>
 */
public class PluggableServerExample
	implements PluggableServer
{
	private final static Logger logger = LogManager.getLogger(PluggableServerExample.class);

	private static final String FILE_DIR_NAME = "File_Dir_Name";
	private static final String DIR_POLL_INTERVAL = "Dir_Poll_Interval";

	private String serverName;
	private DirectoryPoller pollingThread;

	public boolean init(String serverName, Properties settings, long serverIdentifier)
	{
		this.serverName = serverName;

		// Get and validate the polling dir
		String dir = settings.getProperty(FILE_DIR_NAME);
		if (dir == null)
		{
			logger.error("The Pluggable Server implmentation requires the " + FILE_DIR_NAME + " configuration setting");
			return false;
		}
		File pollDir = new File(dir);
		if (!pollDir.isDirectory())
		{
			logger.error("An invalid directory has been passed in to pluggable server name: " + serverName);
			return false;
		}

		// Get the poll Interval
		long pollInterval;
		try
		{
			pollInterval = Long.parseLong(settings.getProperty(DIR_POLL_INTERVAL));
		}
		catch (NumberFormatException nfe)
		{
			logger.error("An invalid poll interval has been passed in to pluggable server name: " + serverName);
			return false;
		}

		// Create the polling Thread
		pollingThread = new DirectoryPoller(pollInterval, pollDir, serverIdentifier);
		pollingThread.setName(serverName);

		logger.debug("Pluggable Server: " + serverName + " has been initialized");

		return true;
	}

	public void start()
	{
		pollingThread.start();
		logger.info("Pluggable Server: " + serverName + " has been started");
	}

	public void stop()
	{
		pollingThread.setStopped(true);
		pollingThread.interrupt();
		logger.info("Pluggable Server: " + serverName + " has been stopped");
	}

	public void systemThrottleEngaged()
	{
		logger.info("Pluggable Server: " + serverName + " system throttle engaged has been called");
		pollingThread.setPaused(true);
	}

	public void systemThrottleDisengaged()
	{
		logger.info("Pluggable Server: " + serverName + " system throttle disengaged has been called");
		pollingThread.setPaused(false);
	}

	private class DirectoryPoller
		extends EventedThread
	{
		long pollInterval;
		File pollDirectory;
		long serverIdentifier;
		boolean isPaused;
		boolean isStopped;

		public DirectoryPoller(long pollInterval, File pollDirectory, long serverIdentfier)
		{
			super();
			this.pollInterval = pollInterval;
			this.pollDirectory = pollDirectory;
			this.serverIdentifier = serverIdentfier;
		}

		public void setPaused(boolean paused)
		{
			isPaused = paused;
		}

		public void setStopped(boolean stopped)
		{
			isStopped = stopped;
		}

		@Override
		protected void primRun()
		{
			while (!isStopped)
			{
				// Check if the system throttle is engaged
				while (isPaused)
				{
					logger.debug("Pluggable Server is paused");
					try
					{
						sleep(5000);
					}
					catch (InterruptedException e)
					{
						// we were interrupted, check if we should keep running
						if (isStopped)
							return;
					}
				}

				// Get all the files in the directory and send them into the trading engine
				try
				{
					logger.debug("Starting polling of file system directory: " + pollDirectory.getAbsolutePath());

					for (String fileName : getDirectoryFiles())
					{
						File foundFile = new File(pollDirectory, fileName);
						logger.debug("Pluggable Server found file: " + foundFile.getName());
						PluggableMessage message = buildPluggableMessage(foundFile);

						try
						{
							// Send the message into the trading engine
							PluggableServerAPI.dispatchMessage(message, serverIdentifier);
							deleteFile(foundFile);
						}
						catch (SystemThrottleEngagedException e)
						{
							// Message has been dispatched, but throttle is engaged, stop polling
							deleteFile(foundFile);
							break;
						}
					}
				}
				catch (IOException e)
				{
					logger.error("Error reading file from disk", e);
				}
				catch (PluggableException e)
				{
					logger.error("Error dispatching message into trading engine", e);
				}

				// Now pause until the next poll interval
				try
				{
					logger.debug("Poll complete, waiting for next poll interval");
					sleep(pollInterval);
				}
				catch (InterruptedException e)
				{
					logger.debug("Interrupted while waiting for next poll interval");
				}
			}
			logger.debug("Pluggable Server exiting.");
		}

		private void deleteFile(File file)
		{
			boolean deleted = file.delete();
			if (!deleted)
				logger.warn("Can not deleted consumed file: " + file.getName());
		}

		private String[] getDirectoryFiles()
		{
			return pollDirectory.list();
		}

		private PluggableMessage buildPluggableMessage(File file)
			throws IOException
		{
			PluggableMessage pluggableMessage = new PluggableMessageImpl();
			pluggableMessage.setFilename(file.getName());
			VirtualData data = new VirtualData();
			data.readFrom(file);
			pluggableMessage.setData(data);
			return pluggableMessage;
		}
	}
}
