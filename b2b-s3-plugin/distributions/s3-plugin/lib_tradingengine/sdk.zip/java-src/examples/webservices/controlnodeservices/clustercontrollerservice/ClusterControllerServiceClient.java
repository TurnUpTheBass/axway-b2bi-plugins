// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.webservices.controlnodeservices.clustercontrollerservice;

import com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub;
import com.cyclonecommerce.cyclone.services.ClusterControllerService.ClusterControllerServiceSoapBindingStub;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

public class ClusterControllerServiceClient
{
	private static final String SESSION_SERVICE_PATH = "/cyclone/services/SessionService";
	private static final String CLUSTER_CONTROLLER_SERVICE_PATH = "/cyclone/services/ClusterControllerService";
	private static final String CLUSTER_INFO_SERVICE_PATH = "/cyclone/services/ClusterInfoService";
	private static final String RUNNING = "running";

	private byte[] sessionCookie;
	private URL url;
	private String username;
	private String password;

	 public ClusterControllerServiceClient(String url, String username, String password)
	{
        if (isNullEmptyOrBlank(url))
            throw new IllegalArgumentException(("Illegal null or empty value for url argument"));
        else
        {
            try
            {
                this.url = new URL(url);
            }
            catch (MalformedURLException e)
            {
                throw new IllegalArgumentException("Invalid server URL.", e);
            }
        }
		if (isNullEmptyOrBlank(username))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.username = username;

        if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;
	}

    public void startNode(String nodeName)
	{
        try
        {
            createSession();
		    ClusterControllerServiceSoapBindingStub clusterControllerService =
                new ClusterControllerServiceSoapBindingStub(new URL(url, CLUSTER_CONTROLLER_SERVICE_PATH), null);
		    clusterControllerService.startNode(sessionCookie, nodeName);
		    System.out.println("Starting node: " + nodeName);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
	}

    public void startNodes()
	{
        try
        {
            createSession();
		    ClusterControllerServiceSoapBindingStub clusterControllerService =
                new ClusterControllerServiceSoapBindingStub(new URL(url, CLUSTER_CONTROLLER_SERVICE_PATH), null);
		    clusterControllerService.startNodes(sessionCookie);
		    System.out.println("Starting nodes");
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
	}

    public void stopNode(String nodeName)
	{
        try
        {
            createSession();
		    ClusterControllerServiceSoapBindingStub clusterControllerService =
                new ClusterControllerServiceSoapBindingStub(new URL(url, CLUSTER_CONTROLLER_SERVICE_PATH), null);
		    clusterControllerService.stopNode(sessionCookie, nodeName);
		    System.out.println("Stopping node: " + nodeName);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
	}

    public void stopNodes()
	{
        try
        {
            createSession();
		    ClusterControllerServiceSoapBindingStub clusterControllerService =
                new ClusterControllerServiceSoapBindingStub(new URL(url, CLUSTER_CONTROLLER_SERVICE_PATH), null);
		    clusterControllerService.stopNodes(sessionCookie);
		    System.out.println("Stopping nodes");
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
	}

    public void removeNode(String nodeName)
	{
        try
        {
            createSession();
		    ClusterControllerServiceSoapBindingStub clusterControllerService =
                new ClusterControllerServiceSoapBindingStub(new URL(url, CLUSTER_CONTROLLER_SERVICE_PATH), null);
		    clusterControllerService.removeNode(sessionCookie, nodeName);
		    System.out.println("Removing node: " + nodeName);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
	}

    public void addNode(String nodeName, String nodeType)
	{
        try
        {
            createSession();
		    ClusterControllerServiceSoapBindingStub clusterControllerService =
                new ClusterControllerServiceSoapBindingStub(new URL(url, CLUSTER_CONTROLLER_SERVICE_PATH), null);
		    clusterControllerService.addNode(sessionCookie, nodeName, nodeType);
		    System.out.println("Adding node: " + nodeName + ": node type: " + nodeType);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
	}

    public void restartNode(String nodeName)
	{
        try
        {
            createSession();
		    ClusterControllerServiceSoapBindingStub clusterControllerService =
                new ClusterControllerServiceSoapBindingStub(new URL(url, CLUSTER_CONTROLLER_SERVICE_PATH), null);
		    clusterControllerService.restartNode(sessionCookie, nodeName);
		    System.out.println("ReStarting node: " + nodeName);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
	}

    public void restartNodes()
	{
        try
        {
            createSession();
		    ClusterControllerServiceSoapBindingStub clusterControllerService =
                new ClusterControllerServiceSoapBindingStub(new URL(url, CLUSTER_CONTROLLER_SERVICE_PATH), null);
		    clusterControllerService.restartNodes(sessionCookie);
		    System.out.println("ReStarting nodes");
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
	}

    public void restartCluster()
       {
           try
           {
               createSession();
               ClusterControllerServiceSoapBindingStub clusterControllerService =
                   new ClusterControllerServiceSoapBindingStub(new URL(url, CLUSTER_CONTROLLER_SERVICE_PATH), null);
               clusterControllerService.restartCluster(sessionCookie);
               System.out.println("ReStarting cluster");
           }
           catch (Exception e)
           {
               StringBuilder sb = formatErrorMessage(e);
               System.out.println(sb);
           }
           finally
           {
               closeTheSession();
           }
       }

    public void stopCluster()
    {
        try
        {
            createSession();
            ClusterControllerServiceSoapBindingStub clusterControllerService =
               new ClusterControllerServiceSoapBindingStub(new URL(url, CLUSTER_CONTROLLER_SERVICE_PATH), null);
            clusterControllerService.restartNodes(sessionCookie);
            clusterControllerService.stopCluster(sessionCookie);
            System.out.println("Stopping cluster");
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
        {
            closeTheSession();
        }
    }

    private void createSession() throws RemoteException, MalformedURLException
	{
		SessionServiceSoapBindingStub sessionService = new SessionServiceSoapBindingStub(new URL(url, SESSION_SERVICE_PATH), null);
		sessionCookie = sessionService.login(username, password);
	}

    private void closeTheSession()
    {
        try
        {
            closeSession();
        }
		catch (Exception e)
        {
            System.out.println("Error closing session: " + e.getMessage());
        }
    }

	private void closeSession() throws RemoteException, MalformedURLException
	{
		if (sessionCookie == null)
			return;

		try
		{
			SessionServiceSoapBindingStub sessionService = new SessionServiceSoapBindingStub(new URL(url, SESSION_SERVICE_PATH), null);
			sessionService.logout(sessionCookie);
		}
		catch (RuntimeException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			// ignore exceptions on close
		}
		finally
		{
			sessionCookie = null;
		}
	}

    private StringBuilder formatErrorMessage(Exception e)
    {
        StringBuilder sb = new StringBuilder("\nError: " + e.getMessage() + "\n");
        StackTraceElement[] stackTrace = e.getStackTrace();
		for (StackTraceElement aStackTrace : stackTrace)
		    sb.append(aStackTrace.toString()).append("\n");
		sb.append("\n");
        return sb;
    }

    private static boolean isNullEmptyOrBlank(String string)
	{
		return string == null || string.trim().length() == 0;
	}

    public static void main(String[] args)
    {
        // Change the parameter values below to suit your environment.
        String url = "http://localhost:6080/cyclone/services/ClusterControllerService";
        String userId = "admin";
        String password = "Secret1";
        String nodeName = "yourNodeName";

        ClusterControllerServiceClient clusterControllerServiceClient = new ClusterControllerServiceClient(url, userId, password);
        clusterControllerServiceClient.startNode(nodeName);
    }
}
