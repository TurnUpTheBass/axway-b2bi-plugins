// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.webservices.controlnodeservices.clusternodeservice;

import com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ClusterInfoServiceSoapBindingStub;
import com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.ConfiguredNode;
import com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.NodeStatus;
import com.cyclonecommerce.cyclone.services.ClusterInfoNodeService.Status;
import com.cyclonecommerce.cyclone.services.sessionService.InvalidSessionException;
import com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub;
import org.apache.axis.AxisFault;

import java.lang.Exception;
import java.lang.String;
import java.lang.StringBuilder;
import java.lang.System;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.Calendar;

public class ClusterInfoNodeClient
{
	private static final String SESSION_SERVICE_PATH = "/cyclone/services/SessionService";
	private static final String CLUSTER_INFO_SERVICE_PATH = "/cyclone/services/ClusterInfoService";

	private byte[] sessionCookie;
	private URL url;
	private String username;
	private String password;

    public ClusterInfoNodeClient(String url, String username, String password)
	{
        if (isNullEmptyOrBlank(url))
            throw new IllegalArgumentException(("Illegal null or empty value for url argument"));
        else
        {
            try
            {
                this.url = new URL(url);
            }
            catch (MalformedURLException e)
            {
                throw new IllegalArgumentException("Invalid server URL.", e);
            }
        }
		if (isNullEmptyOrBlank(username))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.username = username;

        if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;
	}

    public String[] getControlNodeNames()
    {
        String[] controlNodeNames = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            controlNodeNames = clusterInfoStub.getControlNodeNames(sessionCookie);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return controlNodeNames;
    }

    public String[] getConfiguredNodeNames()
    {
        String[] configuredNodeNames = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            configuredNodeNames = clusterInfoStub.getConfiguredNodeNames(sessionCookie);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return configuredNodeNames;
    }

    public String[] getControlNodeMachineNames()
    {
        String[] controlNodeMachineNames = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            controlNodeMachineNames = clusterInfoStub.getControlNodeHostNames(sessionCookie);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return controlNodeMachineNames;
    }

    public Status getClusterStatus()
    {
        Status status = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            status = clusterInfoStub.getClusterStatus(sessionCookie);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return status;
    }

    public NodeStatus[] getNodeStatuses()
    {
        NodeStatus[] nodeStatuses = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            nodeStatuses = clusterInfoStub.getNodeStatuses(sessionCookie);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return nodeStatuses;
    }

    public String[] getActiveServiceNodeNames()
    {
        String[] activeServiceNodeNames = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            activeServiceNodeNames = clusterInfoStub.getActiveServiceNodeNames(sessionCookie);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return activeServiceNodeNames;
    }

    public ConfiguredNode[] getConfiguredNodes()
    {
        ConfiguredNode[] configuredNodes = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            configuredNodes = clusterInfoStub.getConfiguredNodes(sessionCookie);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return configuredNodes;
    }

    public String[] getMachineNames()
    {
       String[] machineNames = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            machineNames = clusterInfoStub.getMachineNames(sessionCookie);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return machineNames;
    }

    public String getNodeType(String nodeName)
    {
       String nodeType = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            nodeType = clusterInfoStub.getNodeType(sessionCookie, nodeName);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return nodeType;
    }

    public String[] getConfigurationNodeNamesForMachine(String machineName)
    {
       String[] nodeNames = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            nodeNames = clusterInfoStub.getConfiguredNodeNamesForMachine(sessionCookie, machineName);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return nodeNames;
    }

    public Calendar getNodeStartDate(String nodeName)
    {
        Calendar startDate = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            startDate = clusterInfoStub.getNodeStartDate(sessionCookie, nodeName);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return startDate;
    }

    public Status getNodeStatus(String nodeName)
    {
        Status status = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            status = clusterInfoStub.getNodeStatus(sessionCookie, nodeName);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return status;
    }

    public Status getMachineStatus(String machineName)
    {
        Status machineStatus = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            machineStatus = clusterInfoStub.getMachineStatus(sessionCookie, machineName);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return machineStatus;
    }

    public ConfiguredNode[] getConfigurationForType(String nodeType)
    {
        ConfiguredNode[] configuredNodes = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            configuredNodes = clusterInfoStub.getConfiguredNodesForType(sessionCookie, nodeType);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return configuredNodes;
    }

    public ConfiguredNode getConfiguredNode(String nodeName)
    {
        ConfiguredNode configuredNode = null;
        try
        {
            createSession();
            ClusterInfoServiceSoapBindingStub clusterInfoStub = new ClusterInfoServiceSoapBindingStub(new URL(url, CLUSTER_INFO_SERVICE_PATH), null);
            configuredNode = clusterInfoStub.getConfiguredNode(sessionCookie, nodeName);
        }
        catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
        finally
		{
            closeTheSession();
		}
        return configuredNode;
    }

    private void createSession() throws RemoteException, MalformedURLException
	{
		SessionServiceSoapBindingStub sessionService = new SessionServiceSoapBindingStub(new URL(url, SESSION_SERVICE_PATH), null);
		sessionCookie = sessionService.login(username, password);
	}

    private void closeTheSession()
    {
        try
        {
            closeSession();
        }
		catch (Exception e)
        {
            StringBuilder sb = formatErrorMessage(e);
            System.out.println(sb);
        }
    }

	private void closeSession() throws RemoteException, MalformedURLException
	{
		if (sessionCookie == null)
			return;
		try
		{
			SessionServiceSoapBindingStub sessionService = new SessionServiceSoapBindingStub(new URL(url, SESSION_SERVICE_PATH), null);
			sessionService.logout(sessionCookie);
		}
		finally
		{
			sessionCookie = null;
		}
	}

    private StringBuilder formatErrorMessage(Exception e)
    {
        StringBuilder sb = new StringBuilder("\nError: " + e.getMessage() + "\n");
        StackTraceElement[] stackTrace = e.getStackTrace();
		for (StackTraceElement aStackTrace : stackTrace)
		    sb.append(aStackTrace.toString()).append("\n");
		sb.append("\n");
        return sb;
    }

    private static boolean isNullEmptyOrBlank(String string)
	{
		return string == null || string.trim().length() == 0;
	}

    public static void main(String[] args)
    {
        // Change the parameter values below to suit your environment.
        String url = "http://localhost:6080/cyclone/services/ClusterInfoService";
        String userId = "admin";
        String password = "Secret1";

        ClusterInfoNodeClient clusterInfoNodeClient = new ClusterInfoNodeClient(url, userId, password);
        String[] controlNodeNames = clusterInfoNodeClient.getControlNodeNames();
        System.out.println("Control Node names: " + Arrays.toString(controlNodeNames));
    }
}