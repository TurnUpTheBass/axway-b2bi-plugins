// Copyright (c) 2006-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package examples.webservices.controlnodeservices.cpaapiservice;

import com.cyclonecommerce.tradingengine.profile.cpaapi.webservice.types.common.CPAApiInvocationException;

import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;

import org.w3c.dom.Element;

import java.io.*;
import java.lang.String;

import org.apache.axis.encoding.Base64;
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;

/**
 * Implements the CPA API WebService Client
 */
public class TestClient
{
    /**
	 * TestCLient
	 * @param args
	 * args[0]: hostname
	 * args[1]: port
	 * args[2]: username
	 * args[3]: password
	 * args[4]: action (import or remove)
	 * args[5]: item (CPA file  or CPA ID)
	 */
	public static void main(String [] args)
	{
    	if (args.length != 6)
    	{
    		usage();
    		System.exit(0);
    	}

    	try {
			String server = args[0];
			String port	= args[1];
			System.out.println("Client");
			String endpoint = "http://" + server + ":" + port + "/cyclone/services/CPAAPI";

     		Service  service = new Service();
     		Call     call    = (Call) service.createCall();

			call.setTargetEndpointAddress( new java.net.URL(endpoint) );
			call.setTimeout(600000);

			String action = args[4];

			String username = args[2];
			String password = args[3];

			if (action.equals("import"))
			{

				call.setOperationName(new QName("http://soapinterop.org/", "importCPA") );

	       		byte[] cpa = readCPA(args[5]);
				call.addParameter("cpa_stream", XMLType.XSD_HEXBIN, ParameterMode.IN);
				call.addParameter("username", XMLType.XSD_STRING, ParameterMode.IN);
				call.addParameter("password", XMLType.XSD_STRING, ParameterMode.IN);

	       		System.out.println("Invoking call.");
				call.invoke( new Object[] { cpa, username, password } );

			}
			else if (action.equals("remove"))
			{

				call.setOperationName(new QName("http://soapinterop.org/", "removeCPA") );
				String cpaID = args[5];

				call.addParameter("cpa_id", XMLType.XSD_STRING, ParameterMode.IN);
				call.addParameter("username", XMLType.XSD_STRING, ParameterMode.IN);
				call.addParameter("password", XMLType.XSD_STRING, ParameterMode.IN);

				System.out.println("Invoking call.");
				call.invoke( new Object[] { cpaID, username, password } );
			}
	   		else
	   		{
	   			System.out.println("usage: TestClient [import cpa-file|remove cpa-id]");
	   		}

			System.out.println("Success.");

       }
       catch (CPAApiInvocationException e)
       {
		   System.out.println(e.toString());
		   System.out.println("-----------");
		   System.out.println("Fault String: " + e.getFaultString());
		   System.out.println("Fault Code: " + e.getFaultCode());
		   System.out.println("Fault SubCodes: " + e.getFaultSubCodes());
		   System.out.println("Fault Reason: " + e.getFaultReason());
		   System.out.println("Fault Details: # of details: " + e.getFaultDetails().length);
		   System.out.println("Fault message: " + e.getMessage());

		   Element[] details = e.getFaultDetails();

		   for (int times = 0; times < details.length ; times++)
		   {
			   String element = details[times].getNodeName();
			   System.out.println("Element: " + element + details[times].toString());
		   }

       }
       catch (Exception e)
       {
	   		System.out.println("Non CPAApiInvocationException Exception: " + e.toString());
       }

	}

	/**
	 * Reads a CPA of a file and encodes the String notiation in 64Base.
	 * @param pathFile the path to the file and the file name.
	 * @return byte array representing the 64Base encoded CPA.
	 */
	private static byte[] readCPA(String pathFile)
	{
		String cpa_encoded_string = "";

        try
        {
            File cpaFile = new File(pathFile);
            byte[] cpaByteArray = new byte[(int) cpaFile.length()];
            FileInputStream inputStream = new FileInputStream(cpaFile);
            inputStream.read(cpaByteArray);
            inputStream.close();
            cpa_encoded_string = Base64.encode(cpaByteArray);
        }
        catch (Exception e)
        {
            System.out.println("Exception: " + e.toString());
            System.out.println("Error parsing XML file. Exitting.");
            System.exit(0);
        }

        return cpa_encoded_string.getBytes();
    }

	/**
	 * Usage method which shows the parameters for the main method.
	 */
	public static void usage(){
		System.out.println("TestClient <hostname> <port> <username> <password> [import <CPA file>|remove <CPA ID>]");
		System.out.println("");
	}

}
