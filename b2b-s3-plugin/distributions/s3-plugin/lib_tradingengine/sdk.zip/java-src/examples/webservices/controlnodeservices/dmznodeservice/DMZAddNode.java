// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package examples.webservices.controlnodeservices.dmznodeservice;

import com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceServiceLocator;
import com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceSoapBindingStub;
import com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub;
import com.cyclonecommerce.cyclone.services.sessionService.SessionServiceServiceLocator;
import com.cyclonecommerce.cyclone.services.DMZNodeService.ConfiguredDmzNode;

import java.rmi.RemoteException;

public class DMZAddNode
{
	private String userId;
    private String password;
    private byte[] cookie;
    private String hostName = null;
    private int port = 0;
    private int minRangePort = 0;
    private int maxRangePort = 0;
    private int controlPort = 0;
    private int nbDataConnections = 0;
    private String dmzZoneName = null;
    private DmzNodeServiceSoapBindingStub binding = null;
	private SessionServiceSoapBindingStub sessionBinding = null;

    public DMZAddNode(String userId, String password, String hostName, String port, String minRangePort, String maxRangePort,
                      String controlPort, String nbDataConnections, String dmzZoneName)
    {
		if (isNullEmptyOrBlank(userId))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.userId = userId;

		if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;

        if (isNullEmptyOrBlank(hostName))
            throw new IllegalArgumentException(("Illegal null or empty value for hostName argument"));
        else
            this.hostName = hostName;

        if (isNullEmptyOrBlank(port))
            throw new IllegalArgumentException(("Illegal null or empty value for port argument"));
        else
            this.port = convertToInt(port);

        if (isNullEmptyOrBlank(minRangePort))
            throw new IllegalArgumentException(("Illegal null or empty value for minRangePort argument"));
        else
            this.minRangePort = convertToInt(minRangePort);

        if (isNullEmptyOrBlank(maxRangePort))
            throw new IllegalArgumentException(("Illegal null or empty value for maxRangePort argument"));
        else
            this.maxRangePort = convertToInt(maxRangePort);

        if (isNullEmptyOrBlank(controlPort))
            throw new IllegalArgumentException(("Illegal null or empty value for controlPort argument"));
        else
            this.controlPort = convertToInt(controlPort);

        if (isNullEmptyOrBlank(nbDataConnections))
            throw new IllegalArgumentException(("Illegal null or empty value for nbDataConnections argument"));
        else
            this.nbDataConnections = convertToInt(nbDataConnections);

        if (isNullEmptyOrBlank(dmzZoneName))
            throw new IllegalArgumentException(("Illegal null or empty value for dmzZoneName argument"));
        else
            this.dmzZoneName = dmzZoneName;
    }

    public void addDMZNode()
    {
        System.out.println("DMZAddNode starting...");
        try
        {
            validateDMZUrl();
            loginToDMZNodeService();
            addNode();
        }
        catch (Exception e)
        {
            System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
        }
    }

    private void validateDMZUrl() throws Exception
    {
        javax.xml.rpc.ServiceFactory serviceFactory = javax.xml.rpc.ServiceFactory.newInstance();
        java.net.URL url = new java.net.URL(new DmzNodeServiceServiceLocator().getDmzNodeServiceAddress() + "?WSDL");
        javax.xml.rpc.Service service = serviceFactory.createService(url, new DmzNodeServiceServiceLocator().getServiceName());
        if(service == null)
		{
            System.out.println("Unable to find DMZ Node Service");
            throw new Exception("Unable to find DMZ Node Service");
		}
    }

    private void loginToDMZNodeService() throws Exception
    {
        try
        {
            binding = (DmzNodeServiceSoapBindingStub)new DmzNodeServiceServiceLocator().getDmzNodeService();
			sessionBinding = (SessionServiceSoapBindingStub)new SessionServiceServiceLocator().getSessionService();
        }
        catch (javax.xml.rpc.ServiceException jre)
        {
            if(jre.getLinkedCause()!=null)
                jre.getLinkedCause().printStackTrace();
            System.out.println("JAX-RPC ServiceException caught: " + jre.getMessage());
            throw new Exception(jre);
        }
		if (sessionBinding == null || binding == null)
		{
			System.out.println("Unable to find the soap binding to the web service");
			return;
		}
		binding.setTimeout(60000);
        cookie = sessionBinding.login(userId, password);
        // Verify login session
        try
		{
            Boolean value = binding.keyExists(cookie);
			if (!value)
			{
                System.out.println("Host unable to validate login session");
            }
            else
                System.out.println("Successfully logged into DMZ Node Service");
        }
        catch (RemoteException e)
        {
            System.out.println("RemoteException: " + e.getMessage());
            throw e;
        }
    }

    private void addNode() throws RemoteException
    {
        try
        {
            String result = binding.addNode(cookie, hostName, port, minRangePort, maxRangePort, controlPort, nbDataConnections, dmzZoneName);
            System.out.println("Result: " + result);
            ConfiguredDmzNode[] dmzNodes = binding.getConfiguredDmzNodes(cookie);
            boolean foundDMZNode = false;
			for (ConfiguredDmzNode dmzNode : dmzNodes)
			{
                if (dmzNode.getHostName().equalsIgnoreCase(hostName))
                {
				    System.out.println("--------------------------");
				    System.out.println("Node Name " + dmzNode.getHostName());
				    System.out.println("Port " + dmzNode.getPort());
				    System.out.println("Min Port " + dmzNode.getMinPort());
				    System.out.println("Max Port " + dmzNode.getMaxPort());
				    System.out.println("Control Port " + dmzNode.getControlPort());
				    System.out.println("Number of connections " + dmzNode.getNbDataConnection());
				    System.out.println("Zone Name " + dmzNode.getZone());
				    System.out.println("--------------------------");
                    foundDMZNode = true;
                    break;
                }
			}
            if (!foundDMZNode)
                System.out.println("Error:  DMZNode " + hostName + " not found in host");
        }
        catch (RemoteException e)
        {
            System.out.println("RemoteException: " + e.getMessage());
            throw e;
        }
    }

    private static boolean isNullEmptyOrBlank(String string)
	{
		return string == null || string.trim().length() == 0;
	}

    private int convertToInt(String value) throws NumberFormatException
    {
        try
		{
			return Integer.parseInt(value);
		}
		catch (NumberFormatException e)
		{
            System.out.println("NumberFormatException when converting " + value + " to integer");
            throw e;
		}
    }

    public static void main(String[] args)
    {
        // Change the parameter values below to suit your environment.
        String userId = "admin";
        String password = "Secret1";
        String hostName = "localhost";
        String port = "6810";
        String minRangePort = "6811";
        String maxRangePort = "6820";
        String controlPort = "6821";
        String nbDataConnections = "1";
        String dmzZoneName = "TestZone1";

        DMZAddNode dmzAddNode = new DMZAddNode(userId, password, hostName, port, minRangePort, maxRangePort, controlPort,
                nbDataConnections, dmzZoneName);
        dmzAddNode.addDMZNode();
    }
}
