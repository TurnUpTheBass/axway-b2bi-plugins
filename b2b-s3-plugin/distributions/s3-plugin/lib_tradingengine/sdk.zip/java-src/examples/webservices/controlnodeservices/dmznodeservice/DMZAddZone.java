// Copyright (c) 2011 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package examples.webservices.controlnodeservices.dmznodeservice;

import com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceServiceLocator;
import com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceSoapBindingStub;
import com.cyclonecommerce.cyclone.services.sessionService.SessionServiceServiceLocator;
import com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub;

import java.rmi.RemoteException;

public class DMZAddZone
{
	private String userId;
    private String password;
    private byte[] cookie;
    private String dmzZoneName = null;
    private String dmzZoneDescription = null;
    private DmzNodeServiceSoapBindingStub binding = null;

    public DMZAddZone(String userId, String password, String zoneName, String zoneDescription)
    {
		if (isNullEmptyOrBlank(userId))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.userId = userId;

		if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;

        if (isNullEmptyOrBlank(zoneName))
            throw new IllegalArgumentException(("Illegal null or empty value for zoneName argument"));
        else
            this.dmzZoneName = zoneName;

        if (isNullEmptyOrBlank(zoneDescription))
            throw new IllegalArgumentException(("Illegal null or empty value for zoneDescription argument"));
        else
            this.dmzZoneDescription = zoneDescription;
    }

    public void addDMZZone()
    {
        System.out.println("DMZAddNode starting...");
        try
        {
            validateDMZUrl();
            loginToDMZNodeService();
            addZone();
        }
        catch (Exception e)
        {
            System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
        }
    }

    private void validateDMZUrl() throws Exception
    {
        javax.xml.rpc.ServiceFactory serviceFactory = javax.xml.rpc.ServiceFactory.newInstance();
        java.net.URL url = new java.net.URL(new DmzNodeServiceServiceLocator().getDmzNodeServiceAddress() + "?WSDL");
        javax.xml.rpc.Service service = serviceFactory.createService(url, new DmzNodeServiceServiceLocator().getServiceName());
        if(service == null)
		{
            System.out.println("Unable to find DMZ Node Service");
            throw new Exception("Unable to find DMZ Node Service");
		}
    }

    private void loginToDMZNodeService() throws Exception
    {
        SessionServiceSoapBindingStub sessionBinding;
        try
        {
            binding = (DmzNodeServiceSoapBindingStub)new DmzNodeServiceServiceLocator().getDmzNodeService();
			sessionBinding = (SessionServiceSoapBindingStub)new SessionServiceServiceLocator().getSessionService();
        }
        catch (javax.xml.rpc.ServiceException jre)
        {
            if(jre.getLinkedCause()!=null)
                jre.getLinkedCause().printStackTrace();
            System.out.println("JAX-RPC ServiceException caught: " + jre.getMessage());
            throw new Exception(jre);
        }
		if (sessionBinding == null || binding == null)
		{
			System.out.println("Unable to find the soap binding to the web service");
			return;
		}
		binding.setTimeout(60000);
        cookie = sessionBinding.login(userId, password);
        // Verify login session
        try
		{
            Boolean value = binding.keyExists(cookie);
			if (!value)
			{
                System.out.println("Host unable to validate login session");
            }
            else
                System.out.println("Successfully logged into DMZ Node Service");
        }
        catch (RemoteException e)
        {
            System.out.println("RemoteException: " + e.getMessage());
            throw e;
        }
    }

    private void addZone() throws RemoteException
    {
        try
        {
            String result = binding.addZone(cookie, dmzZoneName, dmzZoneDescription);
            System.out.println("Result: " + result);
            String[] zoneNames = binding.getZoneNames(cookie);
            boolean foundDMZZoneName = false;
			for (String zoneName : zoneNames)
			{
                if (zoneName.equalsIgnoreCase(dmzZoneName))
                {
				    System.out.println("Zone Name : " + zoneName);
                    foundDMZZoneName = true;
                    break;
                }
			}
            if (!foundDMZZoneName)
                System.out.println("Error: Zone Name " + dmzZoneName + " not found in host.");
        }
        catch (RemoteException e)
        {
            System.out.println("RemoteException: " + e.getMessage());
            throw e;
        }
    }

    private static boolean isNullEmptyOrBlank(String string)
	{
		return string == null || string.trim().length() == 0;
	}

    public static void main(String[] args)
    {
        // Change the parameter values below to suit your environment.
        String userId = "admin";
        String password = "Secret1";
        String zoneName = "TestZone1";
        String zoneDescription = "Test Zone Description";

        DMZAddZone dmzAddZone = new DMZAddZone(userId, password, zoneName, zoneDescription);
        dmzAddZone.addDMZZone();
    }
}