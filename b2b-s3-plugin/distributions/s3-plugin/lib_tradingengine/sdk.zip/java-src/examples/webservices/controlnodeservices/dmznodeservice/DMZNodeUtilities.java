// Copyright (c) $smartDate Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.webservices.controlnodeservices.dmznodeservice;

import com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceServiceLocator;
import com.cyclonecommerce.cyclone.services.DMZNodeService.DmzNodeServiceSoapBindingStub;
import com.cyclonecommerce.cyclone.services.DMZNodeService.Status;
import com.cyclonecommerce.cyclone.services.sessionService.SessionServiceServiceLocator;
import com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub;
import org.apache.axis.attachments.AttachmentPart;

import javax.activation.DataHandler;
import javax.xml.soap.SOAPException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.rmi.RemoteException;

public class DMZNodeUtilities
{
    private String userId;
    private String password;
    private byte[] cookie;
    private DmzNodeServiceSoapBindingStub binding = null;

    public DMZNodeUtilities(String userId, String password)
    {
		if (isNullEmptyOrBlank(userId))
            throw new IllegalArgumentException(("Illegal null or empty value for userId argument"));
        else
            this.userId = userId;

		if (isNullEmptyOrBlank(password))
            throw new IllegalArgumentException(("Illegal null or empty value for password argument"));
        else
            this.password = password;
    }

    public void getDMZNodeStatus(String hostName)
    {
        System.out.println("getDMZNodeStatus for hostName " + hostName);
        try
        {
            validateDMZUrl();
            loginToDMZNodeService();
            getNodeStatus(hostName);
        }
        catch (Exception e)
        {
            System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
        }
    }

    public void setDMZPassword(String newPassword)
    {
        System.out.println("setDMZPassword");
        try
        {
            validateDMZUrl();
            loginToDMZNodeService();
            setPassword(newPassword);
        }
        catch (Exception e)
        {
            System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
        }
    }

    public void exportDMZAgent(String hostName)
    {
        System.out.println("exportDMZAgent for hostName " + hostName);
        try
        {
            validateDMZUrl();
            loginToDMZNodeService();
            exportAgent(hostName);
        }
        catch (Exception e)
        {
            System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
        }
    }

    private void validateDMZUrl() throws Exception
    {
        javax.xml.rpc.ServiceFactory serviceFactory = javax.xml.rpc.ServiceFactory.newInstance();
        java.net.URL url = new java.net.URL(new DmzNodeServiceServiceLocator().getDmzNodeServiceAddress() + "?WSDL");
        javax.xml.rpc.Service service = serviceFactory.createService(url, new DmzNodeServiceServiceLocator().getServiceName());
        if(service == null)
		{
            System.out.println("Unable to find DMZ Node Service");
            throw new Exception("Unable to find DMZ Node Service");
		}
    }

    private void loginToDMZNodeService() throws Exception
    {
        SessionServiceSoapBindingStub sessionBinding;
        try
        {
            binding = (DmzNodeServiceSoapBindingStub)new DmzNodeServiceServiceLocator().getDmzNodeService();
			sessionBinding = (SessionServiceSoapBindingStub)new SessionServiceServiceLocator().getSessionService();
        }
        catch (javax.xml.rpc.ServiceException jre)
        {
            if(jre.getLinkedCause()!=null)
                jre.getLinkedCause().printStackTrace();
            System.out.println("JAX-RPC ServiceException caught: " + jre.getMessage());
            throw new Exception(jre);
        }
		if (sessionBinding == null || binding == null)
		{
			System.out.println("Unable to find the soap binding to the web service");
			return;
		}
		binding.setTimeout(60000);
        cookie = sessionBinding.login(userId, password);
        // Verify login session
        try
		{
            Boolean value = binding.keyExists(cookie);
			if (!value)
			{
                System.out.println("Host unable to validate login session");
            }
            else
                System.out.println("Successfully logged into DMZ Node Service");
        }
        catch (RemoteException e)
        {
            System.out.println("RemoteException: " + e.getMessage());
            throw e;
        }
    }

    private void getNodeStatus(String hostName) throws RemoteException
    {
        try
        {
            Status status = binding.getDmzNodeStatus(cookie, hostName);
            System.out.println("Status: " + status.getStatus());
		}
        catch (RemoteException e)
        {
            System.out.println("RemoteException: " + e.getMessage());
            throw e;
        }
    }

    private void setPassword(String password) throws RemoteException
    {
        try
        {
            binding.setPassword(cookie, password);
        }
        catch (RemoteException e)
        {
            System.out.println("RemoteException: " + e.getMessage());
            throw e;
        }
    }

    private void exportAgent(String hostName) throws SOAPException, IOException
    {
        String dmzAgentFileName;
        try
        {
            dmzAgentFileName = binding.exportAgent(cookie, hostName);
        }
        catch (RemoteException e)
        {
            System.out.println("RemoteException exporting Agent " + e.getMessage());
            throw e;
        }
		Object[] attachments = binding.getAttachments();
		if (attachments != null && attachments.length > 0)
		{
            for (Object attachment : attachments)
            {
                AttachmentPart attachPart = (AttachmentPart) attachment;
                System.out.println("ContentId: " + attachPart.getContentId());
                System.out.println("ContentIdRef: " + attachPart.getContentIdRef());
                System.out.println("ContentType: " + attachPart.getContentType());
                System.out.println("ContentLocation: " + attachPart.getContentLocation());
                DataHandler handler;
                try
                {
                    System.out.println("Content: " + attachPart.getContent());
                    handler = attachPart.getDataHandler();
                }
                catch (SOAPException e)
                {
                    System.out.println("SOAPException: " + e.getMessage());
                    throw e;
                }
                File dmzNodeAgentFile = new File(dmzAgentFileName);
                FileOutputStream dmzNodeAgentFOS = null;
                try
                {
                    dmzNodeAgentFOS = new FileOutputStream(dmzNodeAgentFile);
                    handler.writeTo(dmzNodeAgentFOS);
                }
                catch (FileNotFoundException e)
                {
                    System.out.println("FileNotFoundException: " + e.getMessage());
                    throw e;
                }
                catch (IOException e)
                {
                    System.out.println("IOException writing dmzNodeAgentFOS: " + e.getMessage());
                    throw e;
                }
                finally
                {
                    try
                    {
                        if (dmzNodeAgentFOS != null)
                            dmzNodeAgentFOS.close();
                    }
                    catch (IOException e)
                    {
                        System.out.println("IOException closing dmzNodeAgentFOS: " + e.getMessage());
                        throw e;
                    }
                }
            }
		}
		binding.clearAttachments();
    }

    private static boolean isNullEmptyOrBlank(String string)
	{
		return string == null || string.trim().length() == 0;
	}

    public static void main(String[] args)
    {
        // Change the parameter values below to suit your environment.
        String userId = "admin";
        String password = "Secret1";
        String hostName ="localhost";

        DMZNodeUtilities dmzNodeUtilities = new DMZNodeUtilities(userId, password);
        dmzNodeUtilities.getDMZNodeStatus(hostName);
    }
}
