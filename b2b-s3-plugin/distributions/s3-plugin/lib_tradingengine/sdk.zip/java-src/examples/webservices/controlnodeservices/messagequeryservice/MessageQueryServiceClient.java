// Copyright (c) 2006-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package examples.webservices.controlnodeservices.messagequeryservice;

import com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryInfo;
import com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryRequest;
import com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryResponse;
import com.cyclonecommerce.cyclone.services.messageQueryService.MessageQueryServiceSoapBindingStub;
import com.cyclonecommerce.cyclone.services.messageQueryService.MetadataAttribute;
import com.cyclonecommerce.cyclone.services.messageQueryService.RemoteMessage;
import com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

/**
 * Simple SOAP Client for the Interchange MessageQueryService WebService. Demonstrates how to create a user session,
 * query Interchange for some messages, and clean up the session.
 */
public class MessageQueryServiceClient
{
	private static final String SESSION_SERVICE_PATH = "/cyclone/services/SessionService";
	private static final String MESSAGE_QUERY_SERVICE_PATH = "/cyclone/services/MessageQueryService";

	// Message Status
	private final static Integer IN_PROCESS = new Integer(0);
	private final static Integer FAILED = new Integer(1);
	private final static Integer DELIVERED = new Integer(2);
	private final static Integer DELIVERED_NEGATIVE_RESPONSE = new Integer(3);
	private final static Integer WAITING_FOR_ACK = new Integer(4);
	private final static Integer RESUBMITTED = new Integer(5);
	private final static Integer RESUBMITTING = new Integer(6);
	private final static Integer IGNORED = new Integer(7);
	private final static Integer ALL_EXCEPT_IGNORED = new Integer(8);

	// Sorting Options
	private final static Integer SORT_DELIVERED_DATE = new Integer(0);
	private final static Integer SORT_ORIGINATION_DATE = new Integer(1);
	private final static Integer SORT_PROCESSING_STATUS = new Integer(2);
	private final static Integer SORT_DOCUMENT_ID = new Integer(3);

	// Message Direction
	private final static Integer INBOUND = new Integer(0);
	private final static Integer OUTBOUND = new Integer(1);
	private final static Integer INTERNAL = new Integer(2);
	private final static Integer EXTERNAL = new Integer(3);

	// Message Type
	private final static Integer REQUEST =  new Integer(1);
	private final static Integer RECEIPT = new Integer(2);


	private URL url;
	private String username;
	private String password;
	private byte[] sessionCookie;

	/**
	 * Constructor
	 * @param url - URL to the Interchange UI port - should not include path part of deployed webservices
	 * @param username
	 * @param password
	 */
	public MessageQueryServiceClient(URL url, String username, String password)
	{
		if (url == null) throw new IllegalArgumentException("url cannot be null");
		if (username == null || username.length() == 0) throw new IllegalArgumentException("username cannot be null");
		if (password == null || password.length() == 0) throw new IllegalArgumentException("password cannot be null");

		this.url = url;
		this.username = username;
		this.password = password;
	}

	/**
	 * Opens a session in Interchange. Note that the session must be closed when resubmit operations are completed.
	 * Otherwise the session will remain open until the default session timeout (30 minutes) closes the session.
	 */
	public void createSession()
		throws RemoteException, MalformedURLException
	{
		SessionServiceSoapBindingStub sessionService = new SessionServiceSoapBindingStub(new URL(url, SESSION_SERVICE_PATH), null);
		sessionCookie = sessionService.login(username, password);
	}

	/**
	 * Close the session in Interchange.
	 */
	public void closeSession()
		throws RemoteException, MalformedURLException
	{
		if (sessionCookie == null)
			return;

		try
		{
			SessionServiceSoapBindingStub sessionService = new SessionServiceSoapBindingStub(new URL(url, SESSION_SERVICE_PATH), null);
			sessionService.logout(sessionCookie);
		}
		finally
		{
			sessionCookie = null;
		}
	}

	/**
	 * Invokes the message query service to return messages which match the specified message ID. Prints metadata
	 * from each message to the console.
	 */
	public void getMessagesByMessageId(String messageId)
		throws MalformedURLException, RemoteException
	{
		MessageQueryInfo queryInfo = new MessageQueryInfo();
		queryInfo.setMessageId(messageId);
		doQuery(queryInfo);
	}

	/**
	 * Invokes the message query service to return messages which are in the Rejected state. Prints metadata
	 * from each message to the console.
	 */
	public void getRejectedMessages()
		throws MalformedURLException, RemoteException
	{
		MessageQueryInfo queryInfo = new MessageQueryInfo();
		queryInfo.setMessageStatusType(FAILED);
		queryInfo.setExcludeMessageType(RECEIPT); // Exclude receipts.
		doQuery(queryInfo);
	}

	/**
	 * Invokes the message query service to return messages which are in the Delivered state. Prints metadata
	 * from each message to the console.
	 */
	public void getDeliveredMessages()
		throws MalformedURLException, RemoteException
	{
		MessageQueryInfo queryInfo = new MessageQueryInfo();
		queryInfo.setMessageStatusType(DELIVERED);
		queryInfo.setExcludeMessageType(RECEIPT); // Exclude receipts.
		doQuery(queryInfo);
	}

	/**
	 * Invokes the message query service to return messages which match based on the criteria in MessageQueryInfo.
	 * Prints metadata from each message to the console.
	 */
	public void doQuery(MessageQueryInfo queryInfo)
		throws MalformedURLException, RemoteException
	{
		MessageQueryServiceSoapBindingStub soapStub = new MessageQueryServiceSoapBindingStub(new URL(url, MESSAGE_QUERY_SERVICE_PATH), null);
		MessageQueryRequest request = new MessageQueryRequest();
		int maxResults = 10;
		int serverMaxResults = soapStub.getMaxPageSize(sessionCookie);
		if (maxResults > serverMaxResults)
			maxResults = serverMaxResults;

		int page = 1;
		request.setFromPage(page);
		request.setMaxResults(maxResults);
		request.setQueryInfo(queryInfo);

		MessageQueryResponse response = soapStub.getMessages(sessionCookie, request);
		int pageCount = response.getPageCount();
		int totalNumberOfMessages = 0;
		while (page <= pageCount)
		{
			RemoteMessage[] messages = response.getMessages();
			int numMessages = messages.length;
			totalNumberOfMessages += numMessages;
			for (int i = 0; i < numMessages; i++)
				printMessageInfo(messages[i]);

			page++;
			if (page <= pageCount)
			{
				request.setFromPage(page);
				response = soapStub.getMessages(sessionCookie, request);
			}
		}

		System.out.println("#################################");
		System.out.println("Total number of messages retrieved = " + totalNumberOfMessages);
	}

	public void printMessageInfo(RemoteMessage message)
	{
		System.out.println("#################################");
		System.out.println("CoreId: " + message.getCoreId());
		System.out.println("MessageId: " + message.getMessageId());
		System.out.println("ContentMimeType: " + message.getContentMimeType());
		System.out.println("ReceiverRoutingId: " + message.getReceiverRoutingId());
		System.out.println("SenderRoutingId: " + message.getSenderRoutingId());
		MetadataAttribute[] metadata = message.getMetaDataAttributes();
		int attributeCount = metadata.length;
		for (int i = 0; i < attributeCount; i ++)
			System.out.println(metadata[i].getName() + " = " + metadata[i].getValue());
	}

	public static void main(String[] args)
	{
		if (args.length != 4)
			printUsageAndExit();

		try
		{
			URL baseUrl = new URL(args[0]);
			String username = args[1];
			String password = args[2];
			MessageQueryServiceClient messageQueryServiceClient = new MessageQueryServiceClient(baseUrl, username, password);

			try
			{
				messageQueryServiceClient.createSession();
				if (args[3].equalsIgnoreCase("-rejected"))
					messageQueryServiceClient.getRejectedMessages();
				else if (args[3].equalsIgnoreCase("-delivered"))
					messageQueryServiceClient.getDeliveredMessages();
				else
					messageQueryServiceClient.getMessagesByMessageId(args[3]);
			}
			finally
			{
				// An open session should always be closed!
				messageQueryServiceClient.closeSession();
			}
		}
		catch (MalformedURLException e)
		{
			e.printStackTrace();
			System.exit(-1);
		}
		catch (RemoteException e)
		{
			e.printStackTrace();
			System.exit(-1);
		}
	}

	private static void printUsageAndExit()
	{
		System.out.println("usage: MessageQueryServiceClient base-url username password [-rejected|-delivered|messageID]");
		System.exit(0);
	}
}
