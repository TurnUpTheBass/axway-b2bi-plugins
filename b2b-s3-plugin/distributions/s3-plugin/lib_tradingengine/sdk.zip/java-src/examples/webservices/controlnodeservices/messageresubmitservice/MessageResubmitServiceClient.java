// Copyright (c) 2006-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.webservices.controlnodeservices.messageresubmitservice;

import com.cyclonecommerce.cyclone.services.messageResubmitService.MessageResubmitServiceSoapBindingStub;
import com.cyclonecommerce.cyclone.services.sessionService.SessionServiceSoapBindingStub;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

/**
 * Simple SOAP Client for the Interchange ResubmitService WebService. Demonstrates how to create a user session,
 * resubmit one or more messages, and clean up the session.
 */
public class MessageResubmitServiceClient
{
	private static final String SESSION_SERVICE_PATH = "/cyclone/services/SessionService";
	private static final String RESUBMIT_SERVICE_PATH = "/cyclone/services/MessageResubmitService";

	private URL url;
	private String username;
	private String password;
	private byte[] sessionCookie;

	/**
	 * Constructor
	 * @param url - URL to the Interchange UI port - should not include path part of deployed webservices
	 * @param username
	 * @param password
	 */
	public MessageResubmitServiceClient(URL url, String username, String password)
	{
		if (url == null) throw new IllegalArgumentException("url cannot be null");
		if (username == null || username.length() == 0) throw new IllegalArgumentException("username cannot be null");
		if (password == null || password.length() == 0) throw new IllegalArgumentException("password cannot be null");

		this.url = url;
		this.username = username;
		this.password = password;
	}

	/**
	 * Opens a session in Interchange. Note that the session must be closed when resubmit operations are completed.
	 * Otherwise the session will remain open until the default session timeout (30 minutes) closes the session.
	 */
	public void createSession()
		throws RemoteException, MalformedURLException
	{
		SessionServiceSoapBindingStub sessionService = new SessionServiceSoapBindingStub(new URL(url, SESSION_SERVICE_PATH), null);
		sessionCookie = sessionService.login(username, password);
	}

	/**
	 * Close the session in Interchange.
	 */
	public void closeSession()
		throws RemoteException, MalformedURLException
	{
		if (sessionCookie == null)
			return;

		try
		{
			SessionServiceSoapBindingStub sessionService = new SessionServiceSoapBindingStub(new URL(url, SESSION_SERVICE_PATH), null);
			sessionService.logout(sessionCookie);
		}
		finally
		{
			sessionCookie = null;
		}
	}

	/**
	 * Calls the Interchange Resubmit Webservice to resubmit Messages identified by the passed in core IDs.
	 */
	public void resubmit(String[] coreIds)
		throws MalformedURLException, RemoteException
	{
		MessageResubmitServiceSoapBindingStub soapStub = new MessageResubmitServiceSoapBindingStub(new URL(url, RESUBMIT_SERVICE_PATH), null);
		if (coreIds.length == 1)
			soapStub.resubmitMessage(sessionCookie, coreIds[0]);
		else
			soapStub.resubmitMultipleMessages(sessionCookie, coreIds);
	}

	public static void main(String[] args)
	{
		if (args.length < 4)
			printUsageAndExit();

		try
		{
			URL baseUrl = new URL(args[0]);
			String username = args[1];
			String password = args[2];
			MessageResubmitServiceClient messageResubmitServiceClient = new MessageResubmitServiceClient(baseUrl, username, password);

			try
			{
				messageResubmitServiceClient.createSession();
				messageResubmitServiceClient.resubmit(getCoreIds(args));
			}
			finally
			{
				// An open session should always be closed!
				messageResubmitServiceClient.closeSession();
			}
		}
		catch (MalformedURLException e)
		{
			e.printStackTrace();
			System.exit(-1);
		}
		catch (RemoteException e)
		{
			e.printStackTrace();
			System.exit(-1);
		}
	}

	/**
	 * Parse the core IDs out of the argument array.
	 */
	private static String[] getCoreIds(String[] args)
	{
		String[] coreIds = new String[args.length - 3];
		for (int i = 0; i < args.length - 3; i++)
			coreIds[i] = args[i + 3];
		return coreIds;
	}

	private static void printUsageAndExit()
	{
		System.out.println("usage: MessageResubmitServiceClient base-url username password coreID(s)");
		System.exit(0);
	}
}
