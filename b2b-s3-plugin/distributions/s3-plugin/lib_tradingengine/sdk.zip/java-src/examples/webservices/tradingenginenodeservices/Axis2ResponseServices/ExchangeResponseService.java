// Copyright (c) 2007-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.webservices.tradingenginenodeservices.Axis2ResponseServices;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.util.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * This service defines a method that builds a response and returns that to Interchange for further processing 
 */
public class ExchangeResponseService
{
	private final static Logger logger =
			LogManager.getLogger("examples.webservices.tradingenginenodeservices.Axis2ResponseServices.ExchangeResponseService");

	public OMElement responseMessage(OMElement element)
	{  	   
        OMFactory fac = OMAbstractFactory.getOMFactory();
        OMNamespace ns = fac.createOMNamespace("urn://fakenamespace", "ns");
        OMElement response, elem;

        response = fac.createOMElement("response", ns);

        elem = fac.createOMElement("data", ns);
        elem.setText("This is a response");
        response.addChild(elem);
        return response;
	}
}
