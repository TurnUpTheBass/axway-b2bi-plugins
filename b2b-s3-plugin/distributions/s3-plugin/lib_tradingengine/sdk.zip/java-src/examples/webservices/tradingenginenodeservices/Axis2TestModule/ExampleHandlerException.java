// Copyright (c) 2007-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.webservices.tradingenginenodeservices.Axis2TestModule;

public class ExampleHandlerException
	extends Exception
{
	public ExampleHandlerException()
	{
	}

	public ExampleHandlerException(String message)
	{
		super(message);
	}

	public ExampleHandlerException(String string, Throwable throwable)
	{
		super(string, throwable);
	}

	public ExampleHandlerException(Throwable throwable)
	{
		super(throwable);
	}
}
