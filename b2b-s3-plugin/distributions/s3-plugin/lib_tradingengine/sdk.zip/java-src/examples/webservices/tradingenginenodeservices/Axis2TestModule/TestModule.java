// Copyright (c) 2007-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.

package examples.webservices.tradingenginenodeservices.Axis2TestModule;

import org.apache.axis2.modules.Module;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.description.AxisModule;
import org.apache.axis2.description.AxisDescription;
import org.apache.axis2.AxisFault;
import org.apache.neethi.Assertion;
import org.apache.neethi.Policy;

/**
 * The TestModule is used for tasks such as initializing the module and shutdown the module. In this, nothing else is needed other than 
 * the implemented interface methods from the Module interface having blank bodies.
 */
public class TestModule
	implements Module
{
	public void init(ConfigurationContext configurationContext, AxisModule axisModule) throws AxisFault
	{
	}

	public void engageNotify(AxisDescription axisDescription) throws AxisFault
	{
	}

	public boolean canSupportAssertion(Assertion assertion)
	{
		return false;
	}

	public void applyPolicy(Policy policy, AxisDescription axisDescription) throws AxisFault
	{
	}

	public void shutdown(ConfigurationContext configurationContext) throws AxisFault
	{
	}
}
