// Copyright (c) 2007-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.webservices.tradingenginenodeservices.Axis2TestModule;

import org.apache.axis2.AxisFault;
import org.apache.axis2.context.MessageContext;
import org.apache.axis2.handlers.AbstractHandler;
import com.cyclonecommerce.webservices.protocols.ws.security.WSSConstants;
import com.cyclonecommerce.collaboration.Message;

import org.apache.axiom.soap.SOAPEnvelope;

import org.apache.axiom.soap.SOAPHeader;

import org.apache.axiom.soap.SOAPHeaderBlock;
import java.util.Iterator;

/**
 * TestReceiverHandler is the Axis2 handler which handles the message coming in and process it accordingly. In this example, the handler is 
 * extracting the value from a header from the incoming SOAP message and assigns it to the message's metadata. The user can edit this file and process 
 * the message differently for e.g. rejecting the message if it is not sent from a particular sender. If the user writes a separate handler then it 
 * should be associated with the defined module inside module.xml.   
 */
public class TestReceiverHandler
	extends AbstractHandler
{
	public InvocationResponse invoke(MessageContext msgContext)
		throws AxisFault
	{
		Message ciMsg = (com.cyclonecommerce.collaboration.Message)msgContext.getProperty(WSSConstants.CI_MESSAGE);
		
		// Retreive the SOAP Envelope from the messageContext
		
		SOAPEnvelope envelope = msgContext.getEnvelope();
		SOAPHeader header = envelope.getHeader();
		Iterator iterator = header.getHeadersToProcess(null, "http://example.com/");
		while (iterator.hasNext()) 
		{
    	    SOAPHeaderBlock soapHeaderBlock = (SOAPHeaderBlock)iterator.next();

			String integrationId = soapHeaderBlock.getText();
			ciMsg.setMetadata("IntegrationId", integrationId);
		}		
		return InvocationResponse.CONTINUE;
	}
}