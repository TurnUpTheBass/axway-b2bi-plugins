// Copyright (c) 2007-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.webservices.tradingenginenodeservices.Axis2TestModule;

import org.apache.axis2.AxisFault;
import org.apache.axis2.context.MessageContext;
import org.apache.axis2.handlers.AbstractHandler;
import com.cyclonecommerce.webservices.protocols.ws.security.WSSConstants;

import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.axiom.soap.SOAPFactory;
import org.apache.axiom.soap.SOAPHeader;


import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.soap.SOAPHeaderBlock;


/**
 * TestSenderHandler is the Axis2 handler which handles the message going out and process it accordingly. In this example, the handler is getting the value
 * from a metadata and inserts the metadata into the soap header as an element with its corresponding value. The user can edit this file and process the message differently for e.g.
 * rejecting the message if it is not sent from a particular sender. If the user writes a separate handler, then it should be associated with the defined module inside module.xml.   
 */
public class TestSenderHandler	extends AbstractHandler
{
	public InvocationResponse invoke(MessageContext msgContext)
		throws AxisFault
	{
		com.cyclonecommerce.collaboration.Message ciMsg	= (com.cyclonecommerce.collaboration.Message)msgContext.getProperty(WSSConstants.CI_MESSAGE);
		SOAPEnvelope envelope = msgContext.getEnvelope();
		SOAPFactory factory = (SOAPFactory)envelope.getOMFactory();
		try
		{
			// Add the IntegrationId metadata item to the SOAP Header
			String integrationId = ciMsg.getMetadata("IntegrationId");
			if (integrationId == null || integrationId.trim().equals(""))
				return InvocationResponse.CONTINUE;

			SOAPHeader header = envelope.getHeader();
			
			OMNamespace addressingNamespaceObject = header.declareNamespace("http://example.com/", "example");
			SOAPHeaderBlock soapHeaderBlock = header.addHeaderBlock("IntegrationId", addressingNamespaceObject);
			soapHeaderBlock.addChild(factory.createOMText(integrationId));			
		}
		catch (Exception e)
		{
			throw AxisFault.makeFault(e);
		}
		
		return InvocationResponse.CONTINUE;
	}
}