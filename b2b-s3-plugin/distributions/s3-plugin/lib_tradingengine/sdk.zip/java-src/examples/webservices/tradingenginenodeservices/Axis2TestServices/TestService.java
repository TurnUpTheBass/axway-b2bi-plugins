// Copyright (c) 2007-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.webservices.tradingenginenodeservices.Axis2TestServices;

import org.apache.axiom.om.OMElement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * TestService defines different services which it provides. The service is registered in the services.xml, where it specifies the module it is
 * associated with. In this case, we have handleMessage service, which is registerd in the services.xml. The user can add as many service as he 
 * wants but should make sure to associate it with the right module in the services.xml.
 */
public class TestService
{
	private final static Logger logger = LogManager.getLogger("examples.webservices.tradingenginenodeservices.Axis2TestServices.TestService");

	public void handleMessage(OMElement element)
	{
		logger.debug("handleMessage invoked.");
	}
}
