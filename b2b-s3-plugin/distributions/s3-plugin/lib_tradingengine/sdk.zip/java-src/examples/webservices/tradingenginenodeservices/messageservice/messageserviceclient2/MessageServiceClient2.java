// Copyright (c) 1996-2021 Axway Inc. All Rights Reserved.
// Please refer to the file "LICENSE" for further important copyright
// and licensing information.  Please also refer to the documentation
// for additional copyright notices.
package examples.webservices.tradingenginenodeservices.messageservice.messageserviceclient2;

// JDK import(s)
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

// Cyclone TradingEngine import(s)
import com.cyclonecommerce.tradingengine.transport.api.webservice.MessageServiceSoapBindingStub;
import com.cyclonecommerce.tradingengine.transport.api.webservice.types.MessageDeliveryStatus;
import com.cyclonecommerce.tradingengine.transport.api.webservice.types.MessageId;
import com.cyclonecommerce.tradingengine.transport.api.webservice.types.Payload;

// Axis import(s)
import org.apache.axis.AxisFault;


public class MessageServiceClient2 extends MessageServiceSoapBindingStub
{
    /**
     *
     * @throws org.apache.axis.AxisFault
     */
    public MessageServiceClient2()
            throws org.apache.axis.AxisFault
    {
        super();
    }


    /**
     *
     * @param endpointURL
     * @param service
     * @throws org.apache.axis.AxisFault
     */
    public MessageServiceClient2(java.net.URL endpointURL, javax.xml.rpc.Service service)
            throws org.apache.axis.AxisFault
    {
        super(endpointURL, service);
    }


    /**
     *
     * @param service
     * @throws org.apache.axis.AxisFault
     */
    public MessageServiceClient2(javax.xml.rpc.Service service)
            throws org.apache.axis.AxisFault
    {
        super(service);
    }


    protected static MessageDeliveryStatus getMessageDeliveryStatus(String url, String messageId)
        throws MalformedURLException, RemoteException, AxisFault
    {
        MessageServiceClient2 client = new MessageServiceClient2(new URL(url), null);
        return client.getSubmittedMessageStatus(new MessageId(messageId));
    }


    protected static Payload createPayload(String payloadUrl, boolean sendUrl)
        throws MalformedURLException,
            AxisFault,
            IOException
    {
        Payload payload = new Payload();
        if (sendUrl)
            payload.setUrl(payloadUrl);
        else
            payload.setContent(readStream(new URL(payloadUrl).openStream()));

        return payload;
    }


    public static byte[] readStream(InputStream in)
        throws IOException
    {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int numRead = 0;
        byte buf[] = new byte[512];
		while ((numRead = in.read(buf)) > 0)
			out.write(buf, 0, numRead);
        return out.toByteArray();
    }


    public static void main(String[] args)
    {
        if (args.length < 3)
        {
            System.out.println("Usage: MessageServiceClient [submit | send | status] endpointURL [MessageId] sendPayloadURL[true/false]");
            System.exit(0);
        }
        try
        {
            String command = args[0];
            if (command.equalsIgnoreCase("status"))
            {
                System.out.println("Getting MessageDeliveryStatus for Message: " + args[2]);
                MessageDeliveryStatus status = getMessageDeliveryStatus(args[1], args[2]);
                System.out.println("MessageId = "+ status.getMessageId().getMessageId() + " sent status = " + status.getMessageStatusDescription());
            }
            else if (command.equalsIgnoreCase("submit") || command.equalsIgnoreCase("send"))
            {
                Payload payload = createPayload(args[2], Boolean.valueOf(args[3]).booleanValue());
                MessageServiceClient2 client = new MessageServiceClient2(new URL(args[1]), null);
                if (command.equalsIgnoreCase("submit"))
                {
                    System.out.println("Submitting Message...");
                    MessageId messageId = client.submitPayload(payload);
                    System.out.println("Payload " + messageId.getMessageId() + " submitted to trading engine");
                }
                else
                {
                    System.out.println("Sending Message...");
                    MessageDeliveryStatus status = client.sendPayload(payload);
                    System.out.println("MessageId = "+ status.getMessageId().getMessageId() + " sent status = " + status.getMessageStatusDescription());
                }
            }
            else
            {
                System.out.println("Unrecoginized command: " + command);
                System.exit(-1);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.exit(-1);
        }
    }
}
